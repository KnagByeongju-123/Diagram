/* sync_origin.py 가 만든 파일 — 직접 고치지 마세요 */
window.ORIGIN_MANIFEST={
 "generated_at": "2026-09-25T18:09:27+09:00",
 "repos": {
  "mm_main": {
   "upstream": "https://github.com/KnagByeongju-123/mm_main",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/mm_main/main/",
   "branch": "main",
   "commit": "0d451b11c497b38be9b1da0b86c63e5441670dd4",
   "commit_date": "2026-08-26T19:18:49+09:00",
   "synced_at": "2026-09-20T23:36:04+09:00",
   "files": 34,
   "bytes": 1688789
  },
  "smtec_main2": {
   "upstream": "https://github.com/KnagByeongju-123/smtec_main2",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/smtec_main2/main/",
   "branch": "main",
   "commit": "24a818b39c4bcc69adf59ba6db4b47c6e27b7aa3",
   "commit_date": "2026-09-20T21:16:03+09:00",
   "synced_at": "2026-09-20T23:36:04+09:00",
   "files": 104,
   "bytes": 8050410
  },
  "Gyeongil": {
   "upstream": "https://github.com/KnagByeongju-123/Gyeongil",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/Gyeongil/main/",
   "branch": "main",
   "commit": "a5bd18357228acd6e90eb4500d3d3884d022ad8a",
   "commit_date": "2026-09-03T10:41:19+09:00",
   "synced_at": "2026-09-20T23:36:04+09:00",
   "files": 98,
   "bytes": 1277197
  },
  "iptk_1": {
   "upstream": "https://github.com/KnagByeongju-123/iptk_1",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/iptk_1/main/",
   "branch": "main",
   "commit": "main@2026-09-25 (raw, v170)",
   "commit_date": "2026-09-25T18:09:27+09:00",
   "synced_at": "2026-09-25T18:09:27+09:00",
   "files": 155,
   "bytes": 3335365
  },
  "GF": {
   "upstream": "https://github.com/KnagByeongju-123/GF",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/GF/main/",
   "branch": "main",
   "commit": "ecbe4447ba699b2fbe00d2da591002aa28ef2a73",
   "commit_date": "2026-09-15T09:51:57+09:00",
   "synced_at": "2026-09-20T23:36:04+09:00",
   "files": 6,
   "bytes": 823970
  },
  "TaeJin_ESG": {
   "upstream": "https://github.com/KnagByeongju-123/TaeJin_ESG",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/TaeJin_ESG/main/",
   "branch": "main",
   "commit": "d34b38899cba2523d673d7df484491e9b35b78c4",
   "commit_date": "2026-09-20T21:19:55+09:00",
   "synced_at": "2026-09-20T23:36:04+09:00",
   "files": 22,
   "bytes": 2059532
  },
  "stock_ledger": {
   "upstream": "https://github.com/KnagByeongju-123/stock_ledger",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/stock_ledger/main/",
   "branch": "main",
   "commit": "8255554302d39051a6e4bfb5ad5dfd62da0dad33",
   "commit_date": "2026-09-18T17:56:45+09:00",
   "synced_at": "2026-09-21T00:16:05+09:00",
   "files": 2,
   "bytes": 875128
  }
 }
};
