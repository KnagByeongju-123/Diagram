function myModules(){try{return JSON.parse(localStorage.getItem(LIB_LS)||'[]')}catch(e){return []}}
function setMy(list){try{localStorage.setItem(LIB_LS,JSON.stringify(list))}catch(e){}}
let LIBALL=[];                                   /* 화면에 뿌린 내 모듈 (로컬 + ☁) */
function libAnchorText(){
 const a=sel&&sel.node?N(sel.node):null,el=$('lb_anchor');if(!el)return;
 if(!a){el.innerHTML='선택한 블록이 없어도 <b>기존 대분류/중분류/화면을 후보로 자동 판단</b>합니다. 후보가 비슷하면 선택창이 뜹니다.';return}
 const next=a.type==='module'?'중분류 또는 화면':a.type==='section'?'화면':a.type==='screen'?'테이블':'자동 연결 없음 (FK는 직접 지정)';
 el.innerHTML=`현재 선택: <b>${esc(a.name)}</b> (${TYPE[a.type].name}) → 삽입 모듈의 <b>${next}</b>를 자동 연결합니다.`;
}
function openLib(){
 libDlg.classList.add('on');
 if($('lb_msg'))$('lb_msg').textContent='구성은 전체 시스템 뼈대, 모듈은 재사용할 작은 기능 묶음입니다.';
 if($('lb_name'))$('lb_name').value='';
 if($('lb_q'))$('lb_q').value='';
 if($('lb_scope'))$('lb_scope').value='all';
 if($('lb_cat')){$('lb_cat').innerHTML='<option value="all">전체 업무</option>'+PROCS.map(p=>`<option value="${p.k}">${String(procNo(p.k)).replace(/&/g,'&amp;')} ${esc(p.n)}</option>`).join('');$('lb_cat').value='all'}
 libAnchorText();renderLib();
 if(SB.url&&SB.key&&!(typeof isOfflineMode==='function'&&isOfflineMode()))loadCloudModules();
}
/* ═══ 기본 모듈 수정·삭제(숨김) — 브라우저에 오버레이로 저장 ═══ */
const BI_HIDE_LS='design.bihide', BI_OVR_LS='design.biovr';
function biHide(){try{return JSON.parse(localStorage.getItem(BI_HIDE_LS)||'[]')}catch(e){return[]}}
function setBiHide(a){try{localStorage.setItem(BI_HIDE_LS,JSON.stringify(a))}catch(e){}}
function biOvr(){try{return JSON.parse(localStorage.getItem(BI_OVR_LS)||'{}')}catch(e){return{}}}
function setBiOvr(o){try{localStorage.setItem(BI_OVR_LS,JSON.stringify(o))}catch(e){}}
function builtinAt(i){const m=BUILTIN[i];const o=biOvr()[m.name];
 return o&&o.data?{...m,desc:o.desc||m.desc,data:o.data,ovr:true}:m}
function editBuiltin(i){const m=builtinAt(i);
 insertModule(m.data,m.name,{auto:false});$('lb_name').value=m.name;libDlg.classList.add('on');
 $('lb_msg').textContent=`'${m.name}' 를 캔버스에 넣었습니다. 고친 뒤 블록을 고르고 [＋ 모듈로 저장](또는 블록 패널의 📦)에서 같은 이름으로 저장하면 이 기본 모듈이 업데이트됩니다.`;}
function hideBuiltin(i){const m=builtinAt(i);
 if(!confirm(`기본 모듈 '${m.name}' 을 목록에서 삭제할까요?\n(코드 원본은 남아 있으며, 구분 제목의 [↺ 복원]으로 되돌릴 수 있습니다)`))return;
 setBiHide([...new Set([...biHide(),m.name])]);renderLib();}
/* ═══ 공정별 분류 — 원본 구분(cat)은 꼬리표로 남기고, 보관함은 일반적인 업무 프로세스 순서로 묶는다 ═══ */
const PROCS=[
 {k:'full', n:'전체 시스템 뼈대 (메뉴체계 한 벌)'},
 {k:'base', n:'기준정보 · 사용자 · 권한'},
 {k:'sales',n:'영업 · 수주 · 계약'},
 {k:'dsgn', n:'설계 · 기술'},
 {k:'buy',  n:'구매 · 발주 · 외주'},
 {k:'logi', n:'자재 · 입출고 · 재고 · 물류'},
 {k:'prod', n:'생산 · 공정 · 실적'},
 {k:'qual', n:'품질 · 검사'},
 {k:'eqp',  n:'설비 · 금형 보전'},
 {k:'cost', n:'원가 · 정산'},
 {k:'ehs',  n:'환경 · 안전'},
 {k:'hr',   n:'인사 · 근태'},
 {k:'work', n:'공통 업무 (결재 · 게시판 · 협업)'},
 {k:'etc',  n:'기타'}];
const PROC_OF={
 /* 전체 뼈대 */
 'mm MES 화면배치도 (전체 메뉴체계)':'full','GI MES 화면배치도 (전체 메뉴체계)':'full',
 /* 기준정보 */
 '통합 사용자 · 권한 · 조직 · 결재':'base','공통 기준정보 (통합 마스터)':'base','거래처 · 품목':'base','PIN 사용자관리 (현장형)':'base',
 '금형 기준정보':'base','공장 마스터 관리':'base','무역 기준정보':'base','mm 금형마스터':'base','mm PIN 보안 · 접속이력':'base',
 'GI 기준정보 (생산 · 외주)':'base','GI 시스템 · 사용자 권한':'base',
 /* 영업 */
 '수주 · 출하':'sales','금형 수주 · 제번':'sales','수입계약 · 오더':'sales','국내판매 · 출하':'sales',
 /* 설계 */
 '금형 설계 · PARTLIST':'dsgn',
 /* 구매 */
 '금형 구매 · 외주발주':'buy','외주가공 발주 (공정 파이프라인)':'buy','금형부품 발주 · 외주가공':'buy','mm 구매의뢰 · 발주(외주)':'buy',
 /* 자재·물류 */
 '재고 · 입출고':'logi','선적 · 통관':'logi','입고 · 재고 (코일/시트)':'logi','출하 · 이동이력':'logi',
 'mm 금형부품 재고 (공장별)':'logi','GI 물류 LOT 추적 · 외주 · QR':'logi',
 /* 생산 */
 '생산실적':'prod','금형 가공 · 공정이력':'prod','금형 조립 · 검사':'prod','MES 가동 모니터링':'prod','트윈팩토리 3D':'prod',
 'mm 생산일보 · 설비 카운터':'prod','GI 트윈팩토리 (공장 · 구역 · 설비)':'prod',
 /* 품질 */
 '검사 · 부적합':'qual','금형 SQ 품질':'qual','소재 수입검사 · 입고 (IQC)':'qual','검사기 · 측정기 점검':'qual',
 '치수관리 · 잔량혼입방지':'qual','불량관리 · 안돈':'qual','측정 도구 (도면마킹 · 3D)':'qual','mm Tryout · 개선활동 (IATF)':'qual',
 /* 설비·금형 보전 */
 '설비 · 금형 일상점검':'eqp','금형부품 관리':'eqp','검사기 카메라 모니터링':'eqp','mm 금형수리 (의뢰 → 진행 → 보고서)':'eqp',
 'GI 금형 점검계획 · 연마교체':'eqp','GI 금형 점검등록 (일상 · 정기 · 세척)':'eqp','GI 금형평가 · 타발수 · 금형대장':'eqp','GI 점검기준':'eqp',
 /* 원가 */
 '금형 원가 · 경비':'cost','정산 · 원가 · 여신':'cost',
 /* 환경·안전 */
 '환경 모니터링':'ehs','소방 · 세척기 점검':'ehs','GI 온습도 모니터링':'ehs',
 /* 인사 */
 '근태관리 (연차 · 특근)':'hr',
 /* 공통 업무 */
 '전자결재 (범용)':'work','보고서 결재 · 게시판':'work','회의록 · 개선활동':'work','협업 도구 (표준 · 순회 · 화상)':'work',
 '체크시트 공통 (템플릿형)':'work','mm 인원별 업무현황':'work','mm 수정요청 게시판':'work'};
/* 이름표에 없는 모듈(내 모듈 · 새로 넣은 기본 모듈)은 이름·설명 낱말로 공정을 추정한다 */
const PROC_RULES=[
 ['full',/화면배치도|전체 메뉴체계/],
 ['work',/결재|게시판|회의|협업|공지|업무현황|체크시트 공통/],
 ['hr',/근태|연차|특근|인사|교육|자격|급여/],
 ['ehs',/환경|소방|안전|에너지|온습도|폐기물/],
 ['cost',/원가|정산|경비|회계|여신|미수|매입|매출/],
 ['qual',/품질|검사|부적합|불량|IQC|SQ|측정|계측|치수|시정|클레임|성적서|Tryout/i],
 ['eqp',/설비|보전|점검|금형부품 관리|정비|수리|연마|타발|카메라/],
 ['logi',/재고|입출고|입고|출고|수불|물류|선적|통관|이동|창고|LOT/i],
 ['buy',/구매|발주|외주|협력/],
 ['prod',/생산|공정|가공|조립|작업지시|실적|가동|모니터링|트윈/],
 ['dsgn',/설계|도면|PARTLIST|BOM|기술/i],
 ['sales',/영업|수주|판매|출하|견적|계약|오더/],
 ['base',/기준정보|마스터|사용자|권한|거래처|품목|코드/]];
function procOf(m){if(m.proc)return m.proc;if(PROC_OF[m.name])return PROC_OF[m.name];
 const t=(m.name||'')+' '+(m.desc||'');for(const[k,re]of PROC_RULES)if(re.test(t))return k;return 'etc'}
const procIdx=k=>{const i=PROCS.findIndex(p=>p.k===k);return i<0?PROCS.length:i};
const procName=k=>(PROCS.find(p=>p.k===k)||{n:k}).n;
const procNo=k=>String(procIdx(k)).padStart(2,'0');
/* 원본 꼬리표 */
const SRC_SHORT={'공통 기본':'공통','금형제작':'금형제작','ESG 스마트팩토리':'ESG','철강 수입무역':'철강무역','mm 통합 MES':'mm','GI MES (경일)':'GI'};
const SRC_CLS={'공통 기본':'s0','금형제작':'s1','ESG 스마트팩토리':'s2','철강 수입무역':'s3','mm 통합 MES':'s4','GI MES (경일)':'s5'};
function srcTag(m){const c=m.cat||'공통 기본';const sys=(/\(([^()]*)\)\s*$/.exec(m.desc||'')||[])[1];
 const t=SRC_SHORT[c]||c;return `<span class="srctag ${SRC_CLS[c]||'s9'}" title="원본: ${esc(c)}${sys?' · '+esc(sys):''}">${esc(t)}${sys&&/^(IPTK|smtec)$/i.test(sys)?' · '+esc(sys):''}</span>`}
const procTag=m=>`<span class="srctag s9">${procNo(procOf(m))} ${esc(procName(procOf(m)))}</span>`;
const LIBVIEW_LS='design.libview',LIBFOLD_LS='design.libfold';
function libView(){try{return localStorage.getItem(LIBVIEW_LS)||'proc'}catch(e){return 'proc'}}
function setLibView(v){try{localStorage.setItem(LIBVIEW_LS,v)}catch(e){}renderLib()}
function libFold(){try{return new Set(JSON.parse(localStorage.getItem(LIBFOLD_LS)||'[]'))}catch(e){return new Set()}}
function toggleLibFold(key){const f=libFold();f.has(key)?f.delete(key):f.add(key);
 try{localStorage.setItem(LIBFOLD_LS,JSON.stringify([...f]))}catch(e){}renderLib()}
const libKey=m=>libView()==='src'?(m.cat||'공통 기본'):procOf(m);
function libQ(){return (($('lb_q')||{}).value||'').trim().toLowerCase()}
function libMatch(m){const q=libQ();if(!q)return true;
 return [m.name,m.desc,m.cat,procName(procOf(m))].some(v=>String(v||'').toLowerCase().includes(q))}
function restoreGroup(key){
 const names=BUILTIN.map((m,i)=>builtinAt(i)).filter(m=>libKey(m)===key).map(m=>m.name);
 setBiHide(biHide().filter(n=>!names.includes(n)));renderLib();}
function restoreBuiltins(cat){
 const names=BUILTIN.filter(m=>(m.cat||'공통 기본')===cat).map(m=>m.name);
 setBiHide(biHide().filter(n=>!names.includes(n)));renderLib();}
function resetBuiltin(i){const m=BUILTIN[i];
 if(!confirm(`'${m.name}' 을 원본 기본 모듈 내용으로 되돌릴까요?`))return;
 const o=biOvr();delete o[m.name];setBiOvr(o);renderLib();}
let LIB_ACTIVE='';
function libStats(data){
 const ns=data?.nodes||[],es=data?.edges||[];
 const kind=e=>Array.isArray(e)?e[2]:e.kind;
 return{m:ns.filter(n=>n.type==='module').length,s:ns.filter(n=>n.type==='section').length,c:ns.filter(n=>n.type==='screen').length,t:ns.filter(n=>n.type==='table').length,
  flow:es.filter(e=>kind(e)==='flow').length,ref:es.filter(e=>kind(e)==='ref').length,edges:es.length,nodes:ns.length};
}
function libMineSync(){
 const local=myModules().map(m=>({...m,where:'local'}));
 const cloudOnly=LIBALL.filter(m=>m.where==='cloud'&&!local.some(l=>l.name===m.name));
 LIBALL=[...local,...cloudOnly];
}
function libRowsAll(){
 libMineSync();const hide=new Set(biHide());
 const built=BUILTIN.map((m,i)=>({kind:'builtin',i,m:builtinAt(i)})).filter(x=>!hide.has(x.m.name)).map(x=>({key:'builtin:'+x.i,kind:'builtin',i:x.i,name:x.m.name,desc:x.m.desc||'',cat:x.m.cat||'공통 기본',proc:procOf(x.m),data:x.m.data,ovr:!!x.m.ovr,icon:'📦'}));
 const mine=LIBALL.map(m=>{const root=(m.data?.nodes||[]).find(n=>n.type==='module')||(m.data?.nodes||[]).find(n=>n.type==='section')||{};return{key:'mine:'+encodeURIComponent(m.name),kind:'mine',name:m.name,desc:m.desc||root.meta?.desc||'내가 저장한 재사용 모듈',cat:m.where==='cloud'?'☁ 공유 모듈':'내 모듈',proc:procOf(m),data:m.data,where:m.where,at:m.at||m.updated_at||0,icon:m.where==='cloud'?'☁':'⭐'}});
 return[...built,...mine];
}
function libResolve(key){return libRowsAll().find(r=>r.key===key)||null}
function libFilterRows(){
 const scope=$('lb_scope')?.value||'all',cat=$('lb_cat')?.value||'all',q=(($('lb_q')?.value||'')+'').trim().toLowerCase();
 return libRowsAll().filter(r=>(scope==='all'||r.kind===scope)&&(cat==='all'||r.proc===cat)&&(!q||[r.name,r.desc,r.cat,procName(r.proc),...(r.data?.nodes||[]).map(n=>n.name)].join(' ').toLowerCase().includes(q)));
}
function libCardHtml(r){
 const st=libStats(r.data),active=r.key===LIB_ACTIVE?' on':'',tag=r.kind==='builtin'?`<span class="scope-tag builtin">기본</span>`:`<span class="scope-tag ${r.where==='cloud'?'cloud':'mine'}">${r.where==='cloud'?'☁ 공유':'내 모듈'}</span>`;
 const src=r.kind==='builtin'?srcTag({...r,cat:r.cat}):`<span class="srctag s9">${procNo(r.proc)} ${esc(procName(r.proc))}</span>`;
 const when=r.kind==='mine'&&r.at?` · ${new Date(r.at).toLocaleDateString('ko-KR')}`:'';
 return `<div class="config-card${active}" onclick="showLibDetail('${r.key}')"><div class="module-card-top"><span style="font-size:18px">${r.icon||'📦'}</span><b>${esc(r.name)}</b>${tag}</div><div class="module-card-desc">${esc(r.desc||'')}</div><div class="module-card-src">${src}${r.ovr?'<span class="srctag" style="background:#fff2d7;color:#9a6200">● 수정됨</span>':''}</div><span class="config-count">중분류 ${st.s} · 화면 ${st.c} · 테이블 ${st.t} · 연결 ${st.edges}${when}</span><div class="acts"><button class="btn" onclick="event.stopPropagation();showLibDetail('${r.key}')">구성보기</button><button class="btn primary" onclick="event.stopPropagation();applyLibItem('${r.key}','replace')">새 설계로 적용</button><button class="btn" onclick="event.stopPropagation();applyLibItem('${r.key}','append')">현재 설계에 추가</button></div></div>`;
}
function renderLib(){
 const rows=libFilterRows();
 if(!rows.some(r=>r.key===LIB_ACTIVE))LIB_ACTIVE=rows[0]?.key||'';
 const list=$('lb_list');if(list)list.innerHTML=rows.length?rows.map(libCardHtml).join(''):'<div class="config-empty">조건에 맞는 모듈이 없습니다.</div>';
 if(LIB_ACTIVE)showLibDetail(LIB_ACTIVE,true);else if($('lb_detail'))$('lb_detail').innerHTML='<div class="config-empty">모듈을 선택하세요.</div>';
}
function showLibDetail(key,fromRender){
 const r=libResolve(key);if(!r)return;LIB_ACTIVE=key;
 if(!fromRender){const rows=libFilterRows();const list=$('lb_list');if(list)list.innerHTML=rows.length?rows.map(libCardHtml).join(''):'<div class="config-empty">조건에 맞는 모듈이 없습니다.</div>'}
 const st=libStats(r.data),detail=$('lb_detail');if(!detail)return;
 const mine=r.kind==='mine';
 const tools=mine
  ?`<button class="btn" onclick="editModule(decodeURIComponent('${encodeURIComponent(r.name)}'))">✎ 편집</button><button class="btn" onclick="renameModule(decodeURIComponent('${encodeURIComponent(r.name)}'))">이름 변경</button><button class="btn" onclick="overwriteModule(decodeURIComponent('${encodeURIComponent(r.name)}'))">선택 블록으로 덮어쓰기</button><button class="btn danger" onclick="delModule(decodeURIComponent('${encodeURIComponent(r.name)}'))">삭제</button>`
  :`<button class="btn" onclick="editBuiltin(${r.i})">✎ 기본 모듈 수정</button>${r.ovr?`<button class="btn" onclick="resetBuiltin(${r.i})">↺ 원본 복원</button>`:''}<button class="btn danger" onclick="hideBuiltin(${r.i})">목록에서 숨김</button>`;
 const source=mine?(r.where==='cloud'?'☁ Supabase 공유 모듈':'이 브라우저에 저장한 내 모듈'):`원본: ${esc(r.cat)} · 업무분류: ${esc(procName(r.proc))}`;
 detail.innerHTML=`<div class="module-head"><div class="ico">${r.icon||'📦'}</div><div class="mh-main"><h3>${esc(r.name)}</h3><p>${esc(r.desc||'')}</p><div class="config-count">${source}</div></div></div>
  <div class="module-statbar"><span class="module-stat">블록 ${st.nodes}</span><span class="module-stat">중분류 ${st.s}</span><span class="module-stat">화면 ${st.c}</span><span class="module-stat">테이블 ${st.t}</span><span class="module-stat">FK ${st.ref}</span><span class="module-stat">흐름 ${st.flow}</span></div>
  <div class="module-actions"><button class="btn primary" onclick="applyLibItem('${r.key}','replace')">새 설계로 적용</button><button class="btn" onclick="applyLibItem('${r.key}','append')">현재 설계에 추가</button>${tools}</div>
  ${libTreeHtml(r)}
  <div class="module-subtitle">🔗 자동 연결 <small>현재 설계에 추가할 때 적용</small></div><div class="manual-note" id="lb_anchor_view">${$('lb_anchor')?.innerHTML||'선택한 블록이 없어도 기존 설계에서 적절한 상위 분류를 자동 판단합니다.'}</div>`;
}
function libEdgeParts(e){return Array.isArray(e)?{a:e[0],b:e[1],k:e[2],lab:e[3]||'',card:e[4]||''}:{a:e.from,b:e.to,k:e.kind,lab:e.label||'',card:e.card||''}}
function libChildren(data,i,type){return(data.edges||[]).map(libEdgeParts).filter(e=>e.a===i&&e.k==='contains').map(e=>e.b).filter(j=>!type||data.nodes?.[j]?.type===type)}
function libUses(data,i){return(data.edges||[]).map(libEdgeParts).filter(e=>e.a===i&&e.k==='uses').map(e=>e.b).filter(j=>data.nodes?.[j]?.type==='table')}
function libScreenLines(data,idxs){return idxs.map(i=>{const n=data.nodes[i],tabs=libUses(data,i).map(j=>data.nodes[j]?.name).filter(Boolean);return `<span class="module-screen-line">└ ${esc(n.name)}${tabs.length?` <em>· ${tabs.map(esc).join(' · ')}</em>`:''}</span>`}).join('')||'<span class="module-screen-line" style="color:#9aa4b2">화면 없음</span>'}
function libTreeHtml(r){
 const data=r.data||{nodes:[],edges:[]},ns=data.nodes||[],parts=(data.edges||[]).map(libEdgeParts),hasParent=new Set(parts.filter(e=>e.k==='contains').map(e=>e.b));
 const modules=ns.map((n,i)=>({n,i})).filter(x=>x.n.type==='module'&&!hasParent.has(x.i));
 const sections=ns.map((n,i)=>({n,i})).filter(x=>x.n.type==='section'&&!hasParent.has(x.i));
 const screens=ns.map((n,i)=>({n,i})).filter(x=>x.n.type==='screen'&&!hasParent.has(x.i));
 const secBox=(si)=>{const sec=ns[si],sc=libChildren(data,si,'screen');return `<div class="module-sec"><div class="module-sechead"><b>└ ${esc(sec.name)}</b><button class="module-part-btn" onclick="applyLibPart('${r.key}',${si})">＋ 이 기능만 추가</button></div><div class="module-screens">${libScreenLines(data,sc)}</div></div>`};
 let tree='';
 if(modules.length)tree=modules.map(({n,i})=>{const ss=libChildren(data,i,'section'),direct=libChildren(data,i,'screen');return `<div class="module-treebox"><div class="module-treehead"><span>${esc(n.meta?.icon||'▣')} ${esc(n.name)}</span></div>${ss.map(secBox).join('')}${direct.length?`<div class="module-sec"><div class="module-sechead"><b>└ 직접 연결 화면</b></div><div class="module-screens">${libScreenLines(data,direct)}</div></div>`:''}</div>`}).join('');
 else if(sections.length)tree=sections.map(({i})=>`<div class="module-treebox">${secBox(i)}</div>`).join('');
 else if(screens.length)tree=`<div class="module-treebox"><div class="module-treehead"><span>🖥 화면 묶음</span></div><div class="module-sec"><div class="module-screens">${libScreenLines(data,screens.map(x=>x.i))}</div></div></div>`;
 else tree='<div class="module-warn">메뉴·화면 블록 없이 테이블만 포함된 모듈입니다.</div>';
 const tables=ns.map((n,i)=>({n,i})).filter(x=>x.n.type==='table');
 const tableHtml=tables.length?`<div class="module-subtitle">▤ 포함 테이블 <small>${tables.length}개</small></div><div class="module-tablechips">${tables.map(({n})=>`<span class="module-tablechip"><b>${esc(n.name)}</b>${n.meta?.cols?.length?` · 칼럼 ${n.meta.cols.length}`:''}</span>`).join('')}</div>`:'';
 return `<div class="module-subtitle">📑 포함 구조 <small>중분류의 [이 기능만 추가]로 부분 삽입 가능</small></div><div class="module-tree">${tree}</div>${tableHtml}`;
}
function libSubData(data,root){
 const ns=data?.nodes||[],es=(data?.edges||[]).map(libEdgeParts);if(!ns[root])return null;const ids=new Set([root]),q=[root];
 while(q.length){const cur=q.shift();for(const e of es){let o=null;if(e.a===cur&&(e.k==='contains'||e.k==='uses'))o=e.b;else if(e.k==='ref'&&(e.a===cur||e.b===cur)&&ns[e.a]?.type==='table'&&ns[e.b]?.type==='table')o=e.a===cur?e.b:e.a;if(o!=null&&!ids.has(o)&&ns[o]){ids.add(o);q.push(o)}}}
 const arr=[...ids],map=new Map(arr.map((x,i)=>[x,i]));return{nodes:arr.map(i=>JSON.parse(JSON.stringify(ns[i]))),edges:es.filter(e=>map.has(e.a)&&map.has(e.b)).map(e=>e.card?[map.get(e.a),map.get(e.b),e.k,e.lab,e.card]:[map.get(e.a),map.get(e.b),e.k,e.lab])};
}
function applyLibPart(key,root){const r=libResolve(key);if(!r)return;const sub=libSubData(r.data,root),n=r.data?.nodes?.[root];if(!sub||!n)return;insertModule(sub,`${r.name} · ${n.name}`);save();render();$('stat').textContent=`모듈 '${r.name}'에서 '${n.name}' 기능을 현재 설계에 추가했습니다.`}
function applyLibItem(key,mode){
 const r=libResolve(key);if(!r||!r.data)return;
 if(mode==='replace'){
  if(D.nodes.length&&!confirm(`현재 설계를 지우고 '${r.name}' 모듈로 새 설계를 시작할까요?\nCtrl+Z 또는 REV 백업으로 이전 상태를 복원할 수 있습니다.`))return;
  clearDeleteUndo();D={nodes:[],edges:[]};curName='';try{localStorage.removeItem('sysdesign.name')}catch(e){}updateTitle();
  insertModule(r.data,r.name,{auto:false});autoLayout();save();render();fitAll();$('stat').textContent=`📦 '${r.name}' 모듈로 새 설계를 시작했습니다.`;
 }else{insertModule(r.data,r.name);save();render();$('stat').textContent=`📦 '${r.name}' 모듈을 현재 설계에 추가했습니다.`}
}
function quickSaveModule(whole){
 if(whole&&!D.nodes.length)return alert('저장할 설계가 없습니다.');
 if(!whole&&(!sel||!sel.node))return alert('모듈로 저장할 블록을 먼저 선택하세요.');
 const base=whole?(($('sysName')?.value||'현재 설계')+' 전체'):N(sel.node)?.name||'내 모듈';
 const name=(prompt(whole?'현재 설계 전체를 저장할 모듈 이름':'선택 블록과 딸린 화면·테이블을 저장할 모듈 이름',base)||'').trim();if(!name)return;
 if($('lb_name'))$('lb_name').value=name;if($('lb_deep'))$('lb_deep').checked=true;saveModule(!!whole);LIB_ACTIVE='mine:'+encodeURIComponent(name);if($('lb_scope'))$('lb_scope').value='mine';renderLib();
}
function paintMine(){renderLib()}
let LIB_CLOUD_LOADING=false;
async function loadCloudModules(){
 if(LIB_CLOUD_LOADING||!SB.url||!SB.key||(typeof isOfflineMode==='function'&&isOfflineMode()))return;LIB_CLOUD_LOADING=true;
 try{const rs=await sb('design_modules?select=name,data,updated_at&order=updated_at.desc');for(const r of rs)if(!LIBALL.some(m=>m.name===r.name))LIBALL.push({name:r.name,data:r.data,updated_at:r.updated_at,where:'cloud'});renderLib()}catch(e){}finally{LIB_CLOUD_LOADING=false}
}
const modData=name=>(LIBALL.find(m=>m.name===name)||{}).data;
/* 모듈을 캔버스로 불러와 고친 뒤 같은 이름으로 다시 저장 */
function editModule(name){
 const m=LIBALL.find(x=>x.name===name);if(!m)return;
 insertModule(m.data,name,{auto:false});
 $('lb_name').value=name;libDlg.classList.add('on');
 $('lb_msg').textContent=`'${name}' 를 캔버스에 넣었습니다. 고친 뒤 블록을 고르고 [＋ 모듈로 저장] 하면 같은 이름으로 덮어씁니다.`;
}
/* 이름만 바꾸기 */
function renameModule(name){
 const nn=(prompt('새 모듈 이름',name)||'').trim();if(!nn||nn===name)return;
 if(LIBALL.some(m=>m.name===nn))return alert('같은 이름의 모듈이 이미 있습니다.');
 const my=myModules();const i=my.findIndex(m=>m.name===name);
 const src=LIBALL.find(m=>m.name===name);if(!src)return;
 if(i>=0){my[i]={...my[i],name:nn};setMy(my)}else my.push({name:nn,data:src.data,at:Date.now()}),setMy(my);
 if(SB.url&&SB.key){
  sb('design_modules?on_conflict=name',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
   body:JSON.stringify([{name:nn,data:src.data,updated_at:new Date().toISOString()}])})
   .then(()=>sb('design_modules?name=eq.'+encodeURIComponent(name),{method:'DELETE'})).catch(()=>{});
 }
 LIBALL=LIBALL.filter(m=>m.name!==name);renderLib();$('lb_msg').textContent=`'${name}' → '${nn}' 로 바꿨습니다.`;
}
/* 지금 선택한 블록(과 연결분)으로 내용만 교체 */
function overwriteModule(name){
 if(!sel||!sel.node)return alert('덮어쓸 내용이 될 블록을 캔버스에서 먼저 클릭하세요.');
 if(!confirm(`'${name}' 모듈을 지금 선택한 블록 내용으로 덮어쓸까요?`))return;
 $('lb_name').value=name;saveModule(false,true);
}
function delModule(name){
 if(!confirm(`'${name}' 모듈을 지울까요?`))return;
 setMy(myModules().filter(m=>m.name!==name));
 LIBALL=LIBALL.filter(m=>m.name!==name);
 if(SB.url&&SB.key)sb('design_modules?name=eq.'+encodeURIComponent(name),{method:'DELETE'}).catch(()=>{});
 renderLib();$('lb_msg').textContent=`'${name}' 삭제했습니다.`;
}
/* 선택한 블록(과 연결된 블록)을 모듈로 저장 */
/* ═══ 블록 묶음 → 모듈 저장 공용 ═══
   collectModuleIds: 뿌리 블록에서 아래로만 따라간다 —
   포함(contains) 하위 화면, 화면이 사용(uses)하는 테이블, 테이블 간 FK(ref)는 양방향.
   flow(업무 흐름)나 상위 블록으로는 번지지 않아 설계 전체가 딸려오지 않는다. */
function collectModuleIds(rootId){
 const ids=new Set([rootId]);let q=[rootId];
 while(q.length){const cur=q.shift();
  for(const e of D.edges){
   let o=null;
   if(e.from===cur&&(e.kind==='contains'||e.kind==='uses'))o=e.to;
   else if(e.kind==='ref'&&(e.from===cur||e.to===cur)
     &&N(e.from)?.type==='table'&&N(e.to)?.type==='table')o=e.from===cur?e.to:e.from;
   if(o&&!ids.has(o)&&N(o)){ids.add(o);q.push(o)}
  }}
 return [...ids];
}
function packIdsAsModule(ids,name){
 ids=ids.filter(id=>N(id));
 if(!ids.length)return null;
 const idx=new Map(ids.map((id,i)=>[id,i]));
 const nodes=ids.map(id=>{const n=N(id);return{type:n.type,name:n.name,meta:JSON.parse(JSON.stringify(n.meta)),dx:n.x,dy:n.y}});
 const edges=D.edges.filter(e=>idx.has(e.from)&&idx.has(e.to)).map(e=>e.card?[idx.get(e.from),idx.get(e.to),e.kind,e.label||'',e.card]:[idx.get(e.from),idx.get(e.to),e.kind,e.label||'']);
 const mod={name,data:{nodes,edges},at:Date.now()};
 /* 이름이 기본 모듈과 같으면 → 기본 모듈 자체를 이 내용으로 업데이트(오버레이) */
 if(BUILTIN.some(b=>b.name===name)){
  if(!confirm(`'${name}' 은 기본 모듈입니다. 이 내용으로 기본 모듈을 업데이트할까요?\n(구분 목록에 ●수정됨 으로 표시되고 [↺ 원본]으로 되돌릴 수 있습니다)`))return null;
  const o=biOvr();o[name]={data:mod.data,at:Date.now()};setBiOvr(o);renderLib();
  return{nodes:nodes.length,edges:edges.length};
 }
 const my=myModules();const at=my.findIndex(m=>m.name===name);
 if(at>=0){if(!confirm(`'${name}' 모듈이 이미 있습니다. 덮어쓸까요?`))return null;my[at]=mod}else my.push(mod);
 LIBALL=LIBALL.filter(m=>m.name!==name);
 setMy(my);
 if(SB.url&&SB.key)sb('design_modules?on_conflict=name',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
  body:JSON.stringify([{name,data:mod.data,updated_at:new Date().toISOString()}])}).catch(()=>{});
 return{nodes:nodes.length,edges:edges.length};
}
/* 블록 패널 [📦 모듈로 저장] — 선택 블록 + 부속 화면·테이블을 한 모듈로 */
function saveNodeAsModule(id){
 const n=N(id);if(!n)return;
 const ids=collectModuleIds(id);
 const tCnt=ids.filter(x=>N(x)?.type==='table').length,sCnt=ids.filter(x=>N(x)?.type==='screen').length;
 const name=(prompt(`모듈 이름 (화면 ${sCnt} · 테이블 ${tCnt} · 블록 ${ids.length}개 저장)`,n.name)||'').trim();
 if(!name)return;
 const r=packIdsAsModule(ids,name);
 if(r)$('stat').textContent=`'${name}' 모듈 저장 — 블록 ${r.nodes} · 연결 ${r.edges}. [📦 모듈 보관함]의 내 모듈에서 꺼내 쓸 수 있습니다.`;
}
/* 웹 가져오기 결과 → 모듈 저장 */
let LAST_IMPORT=[],LAST_IMPORT_NAME='';
function updateImpBtn(){const b=$('c_savemod');if(!b)return;
 const alive=LAST_IMPORT.filter(id=>N(id));
 b.disabled=!alive.length;
 b.textContent=alive.length?`📦 가져온 화면·DB를 모듈로 저장 (블록 ${alive.length})`:'📦 가져온 화면·DB를 모듈로 저장';
}
function saveImportAsModule(){
 const ids=LAST_IMPORT.filter(id=>N(id));
 if(!ids.length)return $('c_msg').textContent='먼저 위에서 가져오기를 실행하세요.';
 const tCnt=ids.filter(x=>N(x).type==='table').length,sCnt=ids.filter(x=>N(x).type==='screen').length;
 const name=(prompt(`모듈 이름 (화면 ${sCnt} · 테이블 ${tCnt} · 블록 ${ids.length}개 저장)`,LAST_IMPORT_NAME||'가져온 모듈')||'').trim();
 if(!name)return;
 const r=packIdsAsModule(ids,name);
 if(r){$('c_msg').textContent=`'${name}' 모듈 저장 완료 — 블록 ${r.nodes} · 연결 ${r.edges}`;
  clog(`📦 모듈 저장: '${name}' (블록 ${r.nodes} · 연결 ${r.edges}) — 모듈 보관함 › 내 모듈`);}
}
function saveModule(whole,force){
 const name=($('lb_name').value||'').trim();
 if(!name)return $('lb_msg').textContent='모듈 이름을 입력하세요.';
 let ids;
 if(whole)ids=D.nodes.map(n=>n.id);
 else{
  if(!sel||!sel.node)return $('lb_msg').textContent='저장할 블록을 먼저 클릭하세요.';
  ids=$('lb_deep').checked?collectModuleIds(sel.node):[sel.node];
 }
 const idx=new Map(ids.map((id,i)=>[id,i]));
 const nodes=ids.map(id=>{const n=N(id);return{type:n.type,name:n.name,meta:JSON.parse(JSON.stringify(n.meta)),dx:n.x,dy:n.y}});
 const edges=D.edges.filter(e=>idx.has(e.from)&&idx.has(e.to)).map(e=>e.card?[idx.get(e.from),idx.get(e.to),e.kind,e.label||'',e.card]:[idx.get(e.from),idx.get(e.to),e.kind,e.label||'']);
 const mod={name,data:{nodes,edges},at:Date.now()};
 /* 기본 모듈과 같은 이름이면 기본 모듈을 업데이트(오버레이) */
 if(BUILTIN.some(b=>b.name===name)){
  if(!force&&!confirm(`'${name}' 은 기본 모듈입니다. 이 내용으로 기본 모듈을 업데이트할까요?`))return;
  const o=biOvr();o[name]={data:mod.data,at:Date.now()};setBiOvr(o);renderLib();
  $('lb_msg').textContent=`기본 모듈 '${name}' 업데이트됨 (블록 ${nodes.length} · 연결 ${edges.length}) — [↺ 원본]으로 복원 가능`;
  return;
 }
 const my=myModules();const at=my.findIndex(m=>m.name===name);
 if(at>=0){if(!force&&!confirm(`'${name}' 모듈을 덮어쓸까요?`))return;my[at]=mod}else my.push(mod);
 LIBALL=LIBALL.filter(m=>m.name!==name);
 setMy(my);renderLib();$('lb_msg').textContent=`'${name}' 저장됨 (블록 ${nodes.length} · 연결 ${edges.length})`;
 if(SB.url&&SB.key)sb('design_modules?on_conflict=name',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
  body:JSON.stringify([{name,data:mod.data,updated_at:new Date().toISOString()}])}).catch(()=>{});
}
/* 삽입 모듈의 "외부 진입점"을 찾아 현재 선택 블록과 안전하게 연결한다.
   - 대메뉴 선택 + 중분류 묶음 → 대메뉴→중분류
   - 대메뉴/중분류 선택 + 화면 묶음 → →화면
   - 화면 선택 + 테이블 묶음 → 화면→대표 테이블
   모듈 안에 이미 상위 계층이 들어 있으면 그 내부 구조를 존중하고 억지로 재부모화하지 않는다. */
function autoAttachModule(anchor,made,data){
 if(!anchor||!made.length)return{count:0,skipped:0,names:[]};
 const dn=data.nodes||[],de=data.edges||[];
 const has=t=>dn.some(n=>n.type===t),incomingContains=i=>de.some(e=>e[1]===i&&e[2]==='contains');
 let idx=[];
 if(anchor.type==='module'&&!has('module')){
  idx=dn.map((n,i)=>({n,i})).filter(x=>x.n.type==='section'&&!incomingContains(x.i)).map(x=>x.i);
  if(!idx.length&&!has('section'))idx=dn.map((n,i)=>({n,i})).filter(x=>x.n.type==='screen'&&!incomingContains(x.i)).map(x=>x.i);
 }else if(anchor.type==='section'&&!has('module')&&!has('section')){
  idx=dn.map((n,i)=>({n,i})).filter(x=>x.n.type==='screen'&&!incomingContains(x.i)).map(x=>x.i);
 }else if(anchor.type==='screen'&&!has('module')&&!has('section')&&!has('screen')){
  const first=dn.findIndex(n=>n.type==='table');if(first>=0)idx=[first];
 }
 let count=0,skipped=0,names=[];
 for(const i of idx){const child=made[i],k=contextKind(anchor,child);if(!child||!k||child.id===anchor.id)continue;
  /* 메뉴 자식은 기본적으로 한 부모만 갖게 한다. 이미 다른 부모가 있으면 자동연결은 건너뛴다. */
  if(k==='contains'&&D.edges.some(e=>e.kind==='contains'&&e.to===child.id&&e.from!==anchor.id)){skipped++;continue}
  if(!hasEdge(anchor.id,child.id,k)){D.edges.push({id:uid(),from:anchor.id,to:child.id,kind:k,label:''});count++;names.push(child.name)}
 }
 return{count,skipped,names};
}
function moduleExternalRoots(made,data){
 const dn=data.nodes||[],de=data.edges||[];if(dn.some(n=>n.type==='module'))return[];
 const incoming=(i,k)=>de.some(e=>e[1]===i&&e[2]===k);
 let idx=dn.map((n,i)=>({n,i})).filter(x=>x.n.type==='section'&&!incoming(x.i,'contains')).map(x=>x.i);
 if(idx.length)return idx.map(i=>made[i]).filter(Boolean);
 idx=dn.map((n,i)=>({n,i})).filter(x=>x.n.type==='screen'&&!incoming(x.i,'contains')).map(x=>x.i);
 if(idx.length)return idx.map(i=>made[i]).filter(Boolean);
 const first=dn.findIndex(n=>n.type==='table');return first>=0&&made[first]?[made[first]]:[];
}
function autoAttachModuleSmart(made,data,label,contextNode){
 const roots=moduleExternalRoots(made,data);if(!roots.length)return{count:0,skipped:0,names:[],status:'none'};
 const cands=rankParentCandidates(roots[0],contextNode||null);if(!cands.length)return{count:0,skipped:0,names:[],status:'none'};
 const best=clearParentDecision(cands);
 if(best){const r=attachToParent(best.node,roots);return{...r,skipped:0,status:r.count?'attached':'none',parent:best.node}}
 openParentChoice(roots,cands,`모듈 '${label||''}' 상위 분류 선택`,(p,r)=>{
  if(p&&r.count)$('stat').textContent=`모듈 '${label||''}' · ${p.name} 아래 ${r.count}개 자동 연결`;
  else if(!p)$('stat').textContent=`모듈 '${label||''}' 삽입 · 상위 분류 연결은 보류됨`;
 });
 return{count:0,skipped:0,names:[],status:'pending'};
}
/* 모듈을 현재 설계에 넣는다. 테이블·같은 대메뉴는 재사용하고,
   중분류/화면은 같은 부모 아래에 있을 때만 재사용하여 엉뚱한 메뉴와 합쳐지는 것을 막는다. */
function insertModule(data,label,opts){
 opts=opts||{};if(!data||!data.nodes)return;
 const autoOn=opts.auto!==false;  /* 일반 모듈 삽입은 항상 자동 연결. 편집용 내부 호출만 auto:false 허용 */
 const contextNode=autoOn&&sel&&sel.node?N(sel.node):null;
 const dn0=data.nodes||[],de0=data.edges||[];
 const has0=t=>dn0.some(n=>n.type===t),inc0=(i,k)=>de0.some(e=>e[1]===i&&e[2]===k);
 let rootType=null;
 if(!has0('module')){const si=dn0.findIndex((n,i)=>n.type==='section'&&!inc0(i,'contains')),ci=dn0.findIndex((n,i)=>n.type==='screen'&&!inc0(i,'contains'));rootType=si>=0?'section':ci>=0?'screen':dn0.some(n=>n.type==='table')?'table':null}
 const anchor=contextNode&&rootType&&contextKind(contextNode,{type:rootType})?contextNode:null;
 const r=svg.getBoundingClientRect();
 let ox=Math.round(((r.width/2-view.x)/view.k-140)/8)*8, oy=Math.round(((60-view.y)/view.k)/8)*8;
 while(D.nodes.some(n=>Math.abs(n.x-ox)<30&&Math.abs(n.y-oy)<30))oy+=40;
 const made=[];
 const parentIdx=i=>{const e=(data.edges||[]).find(e=>e[1]===i&&e[2]==='contains');return e?e[0]:-1};
 const uniqueName=(type,base)=>{let nm=base,n=2;while(D.nodes.some(x=>x.type===type&&x.name===nm))nm=`${base} (${n++})`;return nm};
 const uniqueFile=file=>{if(!file)return file;const clean=String(file).split('?')[0],q=String(file).slice(clean.length),m=clean.match(/^(.*?)(\.html?)$/i);
  let stem=m?m[1]:clean,ext=m?m[2]:'.html',out=clean,n=2;
  /* REV17: 같은 원본 파일을 ?mode= 로 나눠 쓰는 화면(design_result_inquiry.html?mode=design / ?mode=assembly)은 파일명을 바꾸지 않는다 — 생성기가 한 파일로 묶어 낸다 */
  const used=v=>D.nodes.some(x=>x.type==='screen'&&(q?String(x.meta.file||'').toLowerCase()===(v+q).toLowerCase():String(x.meta.file||'').split('?')[0].toLowerCase()===v.toLowerCase()));
  while(used(out))out=`${stem}_${n++}${ext}`;return out+q};
 data.nodes.forEach((n,i)=>{
  let dup=null;
  if(n.type==='table'||n.type==='module')dup=D.nodes.find(x=>x.type===n.type&&x.name===n.name);
  else if(n.type==='section'||n.type==='screen'){
   const pi=parentIdx(i),parent=pi>=0?made[pi]:null;
   const ctx=!parent&&anchor&&contextKind(anchor,{type:n.type})==='contains'?anchor:null;
   const p=parent||ctx;
   if(p)dup=D.nodes.find(x=>x.type===n.type&&x.name===n.name&&D.edges.some(e=>e.kind==='contains'&&e.from===p.id&&e.to===x.id));
  }
  if(dup){made[i]=dup;return}
  const meta=JSON.parse(JSON.stringify(n.meta||{}));let nodeName=n.name;
  /* 화면명/파일명은 생성 시스템의 전역 키이므로 다른 메뉴에 같은 화면이 있으면 안전하게 새 이름을 준다. */
  if(n.type==='screen'){nodeName=uniqueName('screen',nodeName);if(meta.file)meta.file=uniqueFile(meta.file)}
  const node={id:uid(),type:n.type,name:nodeName,meta,
   x:ox+(n.dx!=null?(n.dx-data.nodes[0].dx||0):(n.type==='table'?300:0)),
   y:oy+(n.dy!=null?(n.dy-data.nodes[0].dy||0):i*70)};
  D.nodes.push(node);made[i]=node;
 });
 let internal=0;
 for(const [a,b,kind,lab,card] of (data.edges||[]))
  if(made[a]&&made[b]&&!D.edges.some(e=>e.from===made[a].id&&e.to===made[b].id&&e.kind===kind)){
   const ex=inferredKind(made[a],made[b]);if(ex===kind){D.edges.push({id:uid(),from:made[a].id,to:made[b].id,kind,label:lab||'',...(card?{card}:{})});internal++}}
 let at={count:0,skipped:0,names:[],status:'none'};
 if(autoOn)at=anchor?{...autoAttachModule(anchor,made,data),status:'attached'}:autoAttachModuleSmart(made,data,label,contextNode);
 libDlg.classList.remove('on');
 select({node:made[0].id});
 const ext=at.count?` · 자동 연결 ${at.count}건 (${at.names.join(', ')})`:at.status==='pending'?' · 상위 분류 후보 확인 필요':autoOn?' · 자동 연결 대상 없음':'';
 const skip=at.skipped?` · 기존 부모가 있어 ${at.skipped}건 건너뜀`:'';
 $('stat').textContent=`모듈 '${label||''}' 삽입 — 블록 ${made.length}개 · 내부 연결 ${internal}건${ext}${skip}`;
}


/* 어떤 화면이 "헤더 + 명세" 인지 판단한다.
   화면이 쓰는 테이블 중 부모(P)를 고르고, P 를 1:N 으로 가리키는 자식 테이블(C)이 있으면 명세 화면. */
function detailOf(scrNode){
 if(!scrNode||scrNode.type!=='screen'||scrNode.meta.kind==='status')return null;
 const used=D.edges.filter(e=>e.from===scrNode.id&&e.kind==='uses').map(e=>N(e.to)).filter(t=>t&&t.type==='table');
 if(!used.length)return null;
 for(const parent of used){
  const ln=D.edges.find(e=>e.kind==='ref'&&e.card==='1N'&&e.to===parent.id&&N(e.from)&&N(e.from).type==='table');
  if(ln)return{parent,child:N(ln.from),edge:ln};
 }
 return null;
}
/* 자식 테이블에서 부모를 가리키는 연결 컬럼 찾기 (선 설명 'order_no → orders.order_no' 도 읽는다) */
function linkCol(parent,child,edge){
 const pk=(colsOf(parent).find(c=>c.pk)||colsOf(parent)[0]||{}).name;
 const lab=String(edge&&edge.label||'');
 const m=lab.match(/([A-Za-z_]\w*)\s*(?:→|->)/);
 if(m&&colsOf(child).some(c=>c.name===m[1]))return{child:m[1],parent:pk};
 if(colsOf(child).some(c=>c.name===pk))return{child:pk,parent:pk};
 const cand=colsOf(child).find(c=>/_no$|_key$|_id$/.test(c.name)&&!c.pk);
 return{child:cand?cand.name:pk,parent:pk};
}
