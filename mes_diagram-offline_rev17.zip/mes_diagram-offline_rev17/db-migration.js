/* ═══════════════ DB 변경문 (마이그레이션) ═══════════════
   운영 중인 DB 는 다시 만들 수 없다. 설계를 고쳤을 때 "무엇이 달라졌는지"를 비교해
   ALTER TABLE 문으로 뽑아 준다. 기준(baseline)은 "DB 에 적용 완료" 로 표시한 시점의 설계 스냅샷이다.

   · 기준 스냅샷은 시스템 이름별로 이 브라우저(localStorage)에 저장되고 .mesproj 에도 함께 들어간다.
   · 자료가 지워질 수 있는 문장(컬럼·테이블 삭제, 기본키 변경)은 주석으로만 내보낸다 — 사람이 확인하고 풀어서 실행한다. */
const DBSNAP_LS='sysdesign.dbsnap.v1';
const SQLT={text:'text',num:'numeric',date:'date',bool:'boolean'};
const qid=n=>/[^a-z0-9_]/.test(String(n))?'"'+n+'"':n;
const sq=v=>"'"+String(v).replace(/'/g,"''")+"'";
function dbSnapAll(){try{return JSON.parse(localStorage.getItem(DBSNAP_LS)||'{}')||{}}catch(e){return{}}}
function dbSnapSetAll(o){try{localStorage.setItem(DBSNAP_LS,JSON.stringify(o||{}))}catch(e){}}
function dbSnapKey(){return (($('sysName')&&$('sysName').value.trim())||curName||'(이름 없는 설계)')}
function dbSnapGet(){return dbSnapAll()[dbSnapKey()]||null}
function dbSnapPut(s){const a=dbSnapAll();a[dbSnapKey()]=s;dbSnapSetAll(a)}
function dbSnapDel(){const a=dbSnapAll();delete a[dbSnapKey()];dbSnapSetAll(a)}
/* 현재 설계 → 스냅샷 */
function dbSnapshot(){
 const cols=t=>(typeof dbColsOf==='function'?dbColsOf(t):(t.meta.cols||[]));
 const tables={};
 for(const t of D.nodes.filter(n=>n.type==='table')){
  const list=cols(t).map(c=>({name:c.name,label:c.label||'',type:c.type||'text',pk:!!c.pk,req:!!c.req,
   flow:(typeof parseFlow==='function'&&parseFlow(c))?parseFlow(c).steps.concat(parseFlow(c).ends):null}));
  tables[t.name]={label:t.meta.desc||'',cols:list,pk:list.filter(c=>c.pk).map(c=>c.name)};
 }
 return{at:new Date().toISOString(),name:dbSnapKey(),tables};
}
/* 기준 ↔ 현재 비교 */
function dbDiff(prev,cur){
 const P=(prev&&prev.tables)||{},C=(cur&&cur.tables)||{};
 const d={addTables:[],dropTables:[],renameTables:[],cols:[],pk:[],flow:[]};
 for(const [n,t] of Object.entries(C))if(!P[n])d.addTables.push(n);
 for(const n of Object.keys(P))if(!C[n])d.dropTables.push(n);
 for(const [n,t] of Object.entries(C)){
  const p=P[n];if(!p)continue;
  const pm=new Map(p.cols.map(c=>[c.name,c])),cm=new Map(t.cols.map(c=>[c.name,c]));
  const gone=p.cols.filter(c=>!cm.has(c.name)),fresh=t.cols.filter(c=>!pm.has(c.name));
  /* 라벨이 같은 컬럼이 하나씩 사라지고 생겼으면 이름 변경으로 본다 (자료 보존) */
  const renamed=new Set();
  for(const g of gone){const f=fresh.find(x=>!renamed.has(x.name)&&x.label&&g.label&&x.label===g.label);
   if(f){renamed.add(f.name);d.cols.push({t:n,kind:'rename',from:g.name,to:f.name,col:f})}}
  for(const f of fresh)if(!renamed.has(f.name))d.cols.push({t:n,kind:'add',col:f});
  for(const g of gone)if(![...renamed].some(r=>d.cols.find(x=>x.kind==='rename'&&x.from===g.name)))d.cols.push({t:n,kind:'drop',col:g});
  for(const c of t.cols){const o=pm.get(c.name);if(!o)continue;
   if((o.type||'text')!==(c.type||'text'))d.cols.push({t:n,kind:'type',col:c,from:o.type});
   if(!!o.req!==!!c.req)d.cols.push({t:n,kind:'req',col:c});
   if(JSON.stringify(o.flow||null)!==JSON.stringify(c.flow||null))d.flow.push({t:n,col:c,from:o.flow});}
  if((p.pk||[]).join(',')!==(t.pk||[]).join(','))d.pk.push({t:n,from:p.pk||[],to:t.pk||[]});
 }
 d.count=d.addTables.length+d.dropTables.length+d.cols.length+d.pk.length+d.flow.length;
 return d;
}
function dbCreateSql(t,name){
 const cols=t.cols.map(c=>`  ${qid(c.name)} ${SQLT[c.type]||'text'}${(c.req||c.pk)?' not null':''}${c.flow&&c.flow.length?` default ${sq(c.flow[0])} constraint ${qid(name+'_'+c.name+'_chk')} check (${qid(c.name)} in (${c.flow.map(sq).join(',')}))`:''}`);
 return `create table if not exists public.${qid(name)}(\n${cols.join(',\n')}${t.pk&&t.pk.length?`,\n  primary key(${t.pk.map(qid).join(',')})`:''}\n);\n`;
}
/* 변경문 만들기 */
function dbMigrationSql(prev,cur,d){
 const L=[];const add=s=>L.push(s);
 add(`-- ═══ DB 변경문 (마이그레이션) ═══`);
 add(`-- 시스템: ${cur.name}`);
 add(`-- 기준(적용 완료 시점): ${prev?new Date(prev.at).toLocaleString('ko-KR'):'없음 — 전체 생성'}`);
 add(`-- 생성: ${new Date().toLocaleString('ko-KR')}`);
 add(`-- 주의: 자료가 지워질 수 있는 문장(컬럼/테이블 삭제, 기본키 변경)은 주석으로만 들어 있습니다.`);
 add(`--       내용을 확인하고 필요한 줄만 주석을 풀어 실행하세요. 실행 전 백업을 권장합니다.`);
 add(`begin;\n`);
 if(!prev){for(const [n,t] of Object.entries(cur.tables)){add(`-- 새 테이블 ${n}${t.label?' ('+t.label+')':''}`);add(dbCreateSql(t,n))}}
 else{
  for(const n of d.addTables){const t=cur.tables[n];add(`-- ＋ 새 테이블 ${n}${t.label?' ('+t.label+')':''}`);add(dbCreateSql(t,n))}
  for(const c of d.cols.filter(x=>x.kind==='rename'))
   add(`-- ✎ 컬럼 이름 변경 (자료 유지) — ${c.t}.${c.from} → ${c.to}${c.col.label?' ('+c.col.label+')':''}\nalter table public.${qid(c.t)} rename column ${qid(c.from)} to ${qid(c.to)};\n`);
  for(const c of d.cols.filter(x=>x.kind==='add')){const t=SQLT[c.col.type]||'text';
   add(`-- ＋ 컬럼 추가 — ${c.t}.${c.col.name}${c.col.label?' ('+c.col.label+')':''}`);
   add(`alter table public.${qid(c.t)} add column if not exists ${qid(c.col.name)} ${t}${c.col.flow&&c.col.flow.length?` default ${sq(c.col.flow[0])} constraint ${qid(c.t+'_'+c.col.name+'_chk')} check (${qid(c.col.name)} in (${c.col.flow.map(sq).join(',')}))`:''};`);
   if(c.col.req)add(`--   필수 컬럼입니다. 기존 행에 값을 채운 뒤 아래 줄을 실행하세요.\n-- update public.${qid(c.t)} set ${qid(c.col.name)} = ${c.col.type==='num'?'0':c.col.type==='bool'?'false':c.col.type==='date'?'current_date':"''"} where ${qid(c.col.name)} is null;\n-- alter table public.${qid(c.t)} alter column ${qid(c.col.name)} set not null;`);
   add('');
  }
  for(const c of d.cols.filter(x=>x.kind==='type'))
   add(`-- ✎ 형 변경 — ${c.t}.${c.col.name} : ${c.from} → ${c.col.type} (값이 맞지 않으면 실패합니다)\nalter table public.${qid(c.t)} alter column ${qid(c.col.name)} type ${SQLT[c.col.type]||'text'} using ${qid(c.col.name)}::${SQLT[c.col.type]||'text'};\n`);
  for(const c of d.cols.filter(x=>x.kind==='req'))
   add(c.col.req?`-- ✎ 필수로 변경 — ${c.t}.${c.col.name}\n-- (빈 값이 있으면 실패합니다. 먼저 값을 채우세요)\nalter table public.${qid(c.t)} alter column ${qid(c.col.name)} set not null;\n`
                :`-- ✎ 필수 해제 — ${c.t}.${c.col.name}\nalter table public.${qid(c.t)} alter column ${qid(c.col.name)} drop not null;\n`);
  for(const f of d.flow){const cn=`${f.t}_${f.col.name}_chk`;
   add(`-- ✎ 상태값 목록 변경 — ${f.t}.${f.col.name} : ${(f.from||['(없음)']).join(' · ')} → ${(f.col.flow||['(없음)']).join(' · ')}`);
   add(`alter table public.${qid(f.t)} drop constraint if exists ${qid(cn)};`);
   if(f.col.flow&&f.col.flow.length){
    add(`-- 기존 자료에 목록 밖의 값이 있으면 아래 문장이 실패합니다. 먼저 확인하세요:`);
    add(`-- select distinct ${qid(f.col.name)} from public.${qid(f.t)};`);
    add(`alter table public.${qid(f.t)} add constraint ${qid(cn)} check (${qid(f.col.name)} in (${f.col.flow.map(sq).join(',')}));`);
   }
   add(`--   ※ 처음 생성된 테이블은 이름 없는 check 가 걸려 있을 수 있습니다. 그때는 제약 이름을 확인해 직접 지우세요.\n`);
  }
  for(const c of d.cols.filter(x=>x.kind==='drop'))
   add(`-- － 컬럼 삭제 — ${c.t}.${c.col.name}${c.col.label?' ('+c.col.label+')':''} : 자료가 함께 사라집니다.\n-- alter table public.${qid(c.t)} drop column ${qid(c.col.name)};\n`);
  for(const p of d.pk)
   add(`-- ⚠ 기본키 변경 — ${p.t} : (${p.from.join(',')||'없음'}) → (${p.to.join(',')||'없음'})\n-- 중복 행이 있으면 실패합니다. 제약 이름을 확인한 뒤 실행하세요.\n-- alter table public.${qid(p.t)} drop constraint ${qid(p.t+'_pkey')};\n${p.to.length?`-- alter table public.${qid(p.t)} add primary key(${p.to.map(qid).join(',')});`:''}\n`);
  for(const n of d.dropTables)
   add(`-- － 테이블 삭제 — ${n} : 자료가 모두 사라집니다.\n-- drop table public.${qid(n)};\n`);
  if(!d.count)add('-- 기준 시점 이후 바뀐 내용이 없습니다.\n');
 }
 add(`commit;`);
 return L.join('\n');
}
/* ── 화면 ── */
function dbDiffText(d,prev){
 if(!prev)return '기준이 없습니다 — 전체 생성문(create table)으로 내보냅니다. DB 에 처음 적용하는 설계라면 그대로 실행하세요.';
 if(!d.count)return '기준 시점 이후 바뀐 내용이 없습니다.';
 const p=[];
 if(d.addTables.length)p.push(`테이블 추가 ${d.addTables.length}`);
 if(d.cols.filter(x=>x.kind==='add').length)p.push(`컬럼 추가 ${d.cols.filter(x=>x.kind==='add').length}`);
 if(d.cols.filter(x=>x.kind==='rename').length)p.push(`컬럼 이름변경 ${d.cols.filter(x=>x.kind==='rename').length}`);
 if(d.cols.filter(x=>x.kind==='type').length)p.push(`형 변경 ${d.cols.filter(x=>x.kind==='type').length}`);
 if(d.cols.filter(x=>x.kind==='req').length)p.push(`필수 변경 ${d.cols.filter(x=>x.kind==='req').length}`);
 if(d.flow.length)p.push(`상태값 변경 ${d.flow.length}`);
 if(d.cols.filter(x=>x.kind==='drop').length)p.push(`컬럼 삭제 ${d.cols.filter(x=>x.kind==='drop').length}(주석)`);
 if(d.pk.length)p.push(`기본키 변경 ${d.pk.length}(주석)`);
 if(d.dropTables.length)p.push(`테이블 삭제 ${d.dropTables.length}(주석)`);
 return p.join(' · ');
}
let DBMIG_SQL='';
function openDbMigration(){
 if(!D.nodes.some(n=>n.type==='table'))return alert('테이블 블록이 없습니다. 먼저 테이블을 설계하세요.');
 const prev=dbSnapGet(),cur=dbSnapshot(),d=dbDiff(prev,cur);
 DBMIG_SQL=dbMigrationSql(prev,cur,d);
 $('mgBase').innerHTML=prev
  ? `기준: <b>${esc(new Date(prev.at).toLocaleString('ko-KR'))}</b> 적용 완료 · 테이블 ${Object.keys(prev.tables).length}개 <button class="btn" style="height:24px;padding:0 8px;font-size:11px;margin-left:6px" onclick="dbBaseClear()">기준 지우기</button>`
  : `기준 없음 — 이 설계를 DB 에 <b>처음</b> 적용합니다. 이미 DB 가 있다면 [기준 파일 불러오기] 로 적용 시점 설계를 먼저 넣으세요.`;
 $('mgSummary').textContent=dbDiffText(d,prev);
 $('mgSql').textContent=DBMIG_SQL;
 $('mgMsg').textContent='';
 mgDlg.classList.add('on');
}
function dbBaseClear(){if(!confirm('기준 스냅샷을 지울까요? 다음 변경문은 전체 생성문으로 나옵니다.'))return;dbSnapDel();openDbMigration()}
function dbMigCopy(){navigator.clipboard.writeText(DBMIG_SQL).then(()=>$('mgMsg').textContent='복사했습니다. Supabase SQL Editor 에 붙여넣어 실행하세요.',()=>$('mgMsg').textContent='복사에 실패했습니다. 아래 내용을 직접 선택해 복사하세요.')}
function dbMigDownload(){
 const name=(dbSnapKey().replace(/[\\/:*?"<>|]/g,'_'))+'_DB변경_'+new Date().toISOString().slice(0,10)+'.sql';
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([DBMIG_SQL],{type:'text/plain;charset=utf-8'}));a.download=name;a.click();
 $('mgMsg').textContent=name+' 저장했습니다.';
}
function dbMigApplied(){
 if(!confirm('이 변경문을 DB 에 실행했습니까?\n[확인] 을 누르면 지금 설계를 새 기준으로 삼습니다. 다음부터는 여기서 달라진 부분만 나옵니다.'))return;
 dbSnapPut(dbSnapshot());openDbMigration();$('mgMsg').textContent='✓ 지금 설계를 기준으로 삼았습니다.';
}
function dbBaseExport(){
 const s=dbSnapGet()||dbSnapshot();
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(s,null,1)],{type:'application/json'}));
 a.download=(dbSnapKey().replace(/[\\/:*?"<>|]/g,'_'))+'_DB기준.json';a.click();$('mgMsg').textContent='기준 파일을 저장했습니다.';
}
function dbBaseImport(f){
 const file=f&&f.target&&f.target.files&&f.target.files[0];if(!file)return;
 const r=new FileReader();
 r.onload=()=>{try{const s=JSON.parse(r.result);
  if(!s||!s.tables)throw new Error('기준 파일 형식이 아닙니다.');
  dbSnapPut(s);openDbMigration();$('mgMsg').textContent='기준 파일을 불러왔습니다.';
 }catch(e){$('mgMsg').textContent='불러오기 실패: '+e.message}};
 r.readAsText(file,'utf-8');f.target.value='';
}
/* 설계 JSON(.json/.mesproj)을 기준으로 삼기 — 예전 버전 설계 파일에서 바로 기준 만들기 */
function dbBaseFromDesign(f){
 const file=f&&f.target&&f.target.files&&f.target.files[0];if(!file)return;
 const r=new FileReader();
 r.onload=()=>{try{
  const j=JSON.parse(r.result),data=j.D||j.design||j.data||j;
  if(!data||!Array.isArray(data.nodes))throw new Error('설계 파일이 아닙니다.');
  const keep=D;D=data;let s;try{s=dbSnapshot()}finally{D=keep}
  s.at=j.at||new Date().toISOString();dbSnapPut(s);openDbMigration();
  $('mgMsg').textContent='예전 설계 파일을 기준으로 삼았습니다 — 테이블 '+Object.keys(s.tables).length+'개.';
 }catch(e){$('mgMsg').textContent='불러오기 실패: '+e.message}};
 r.readAsText(file,'utf-8');f.target.value='';
}
