/* ═══════════════════════════════════════════════════════════════════
   Offline Enhancements v1
   - 기본 오프라인 모드
   - 전체 설계 Undo / Redo
   - 자동백업 + REV 버전관리
   - .mesproj 프로젝트 통합 저장 / 열기
   ═══════════════════════════════════════════════════════════════════ */
(function(){
'use strict';

const OFFLINE_KEY='sysdesign.offlineMode.v1';
const REV_KEY='sysdesign.revisions.v1';
const REV_SEQ_KEY='sysdesign.revisions.seq.v1';
const HISTORY_LIMIT=80;
const REV_LIMIT=25;
const REV_BYTES_LIMIT=2600000;
const AUTO_REV_MS=5*60*1000;

const clone=o=>JSON.parse(JSON.stringify(o));
const nowIso=()=>new Date().toISOString();
const safeName=s=>String(s||'MES_Project').replace(/[\\/:*?"<>|]+/g,'_').replace(/\s+/g,'_').slice(0,80)||'MES_Project';
function isOfflineMode(){try{return localStorage.getItem(OFFLINE_KEY)!=='0'}catch(e){return true}}
window.isOfflineMode=isOfflineMode;
function localMessage(msg){const s=document.getElementById('stat');if(s)s.textContent=msg}
function isLocalUrl(u){
 try{const x=new URL(u,location.href);return x.protocol==='file:'||x.hostname==='localhost'||x.hostname==='127.0.0.1'||x.hostname==='::1'}catch(e){return true}
}

/* ── 완전 오프라인 UI ───────────────────────────────────────────── */
function applyOfflineUI(){
 const off=isOfflineMode(),btn=document.getElementById('offlineBtn');
 if(btn){btn.textContent=off?'● 오프라인':'◌ 온라인 허용';btn.classList.toggle('offline-on',off);btn.title=off?'외부 인터넷 접속 차단 · 로컬 파일만 사용':'Supabase·웹 가져오기 등 온라인 기능 사용 가능'}
 document.documentElement.classList.toggle('offline-mode',off);
 document.querySelectorAll('button').forEach(b=>{
  const oc=b.getAttribute('onclick')||'';
  if(/^(cloudSave\(|cloudSaveAs\(|cloudOpen\(|testConn\()/.test(oc.trim())){
   if(b.dataset&&!b.dataset.onlineTitle)b.dataset.onlineTitle=b.title||'';
   b.disabled=off;b.classList.toggle('net-disabled',off);b.title=off?'오프라인 모드에서는 사용할 수 없습니다.':(b.dataset?.onlineTitle||'');
  }
 });
 const ids=['c_url','c_depth','c_max','c_proxy','c_go'];
 ids.forEach(id=>{const e=document.getElementById(id);if(e)e.disabled=off});
 let note=document.getElementById('offlineCrawlNote');
 const src=document.querySelector('#crawlDlg .src');
 if(src&&!note){note=document.createElement('div');note.id='offlineCrawlNote';note.className='offline-note';src.prepend(note)}
 if(note){note.style.display=off?'block':'none';note.textContent='오프라인 모드: 웹 주소 가져오기는 잠겨 있습니다. 아래의 저장한 HTML/소스 파일 가져오기는 그대로 사용할 수 있습니다.'}
 if(off&&typeof GENCFG!=='undefined'&&GENCFG&&GENCFG.originMode==='upstream'){
  GENCFG.originMode='fork';try{localStorage.setItem(GENCFG_LS,JSON.stringify(GENCFG))}catch(e){}
 }
}
window.toggleOfflineMode=function(){
 const next=!isOfflineMode();try{localStorage.setItem(OFFLINE_KEY,next?'1':'0')}catch(e){}
 applyOfflineUI();
 localMessage(next?'● 오프라인 모드 ON — 외부 접속 없이 로컬 파일만 사용합니다.':'◌ 온라인 기능 허용 — Supabase·웹 가져오기를 사용할 수 있습니다.');
};

/* 온라인 함수 안전장치. Ctrl+S는 온라인/오프라인과 무관하게 로컬 현재 작업 저장으로 고정 */
window.saveCurrentWork=function(){
 try{save();historyCommit();localMessage('💾 현재 작업 저장 완료 — 설계와 시스템 이름을 이 PC 브라우저에 저장했습니다.')}catch(e){localMessage('현재 작업 저장 실패: '+(e.message||e))}
};

if(typeof cloudSave==='function'){
 const fn=cloudSave;cloudSave=function(){if(isOfflineMode()){try{save()}catch(e){}localMessage('로컬 자동저장 완료 — 인터넷 전송 없이 이 PC 브라우저에 저장했습니다.');return}return fn.apply(this,arguments)};
}
if(typeof cloudSaveAs==='function'){
 const fn=cloudSaveAs;cloudSaveAs=function(){if(isOfflineMode()){localMessage('오프라인 모드입니다. [저장 ▾ → 프로젝트(.mesproj) 저장]을 사용하세요.');return}return fn.apply(this,arguments)};
}
if(typeof cloudOpen==='function'){
 const fn=cloudOpen;cloudOpen=function(){if(isOfflineMode()){localMessage('오프라인 모드입니다. [가져오기 ▾ → 프로젝트(.mesproj) 열기]를 사용하세요.');return}return fn.apply(this,arguments)};
}
if(typeof testConn==='function'){
 const fn=testConn;testConn=function(){if(isOfflineMode()){const m=document.getElementById('setMsg');if(m)m.textContent='오프라인 모드 — 연결 확인을 생략했습니다.';return}return fn.apply(this,arguments)};
}
if(typeof fetchText==='function'){
 const fn=fetchText;fetchText=async function(url){
  if(isOfflineMode()&&/^https?:\/\//i.test(String(url))&&!isLocalUrl(url)){
   if(typeof window.resolveGithubOfflineText==='function'){
    const t=await window.resolveGithubOfflineText(url);
    if(t!==undefined)return t;
   }
   throw new Error('오프라인 모드에서 외부 주소 접속이 차단되었습니다. GitHub 구성은 먼저 [📦 오프라인 원본 저장]을 실행하세요.');
  }
  return fn.apply(this,arguments);
 };
}

/* ── 전체 Undo / Redo ───────────────────────────────────────────── */
const baseSave=typeof save==='function'?save:null;
const HIST={undo:[],redo:[],last:'',timer:null,applying:false};
function designString(){try{return JSON.stringify(D)}catch(e){return '{}'}}
function historyUpdateUI(){
 const u=document.getElementById('undoBtn'),r=document.getElementById('redoBtn');
 if(u){u.disabled=!HIST.undo.length;u.title=HIST.undo.length?`이전 설계 상태로 되돌리기 · ${HIST.undo.length}단계 (Ctrl+Z)`:'되돌릴 설계 변경이 없습니다 (Ctrl+Z)'}
 if(r){r.disabled=!HIST.redo.length;r.title=HIST.redo.length?`되돌린 변경 다시 적용 · ${HIST.redo.length}단계 (Ctrl+Y)`:'다시 적용할 변경이 없습니다 (Ctrl+Y)'}
}
function historyInit(){HIST.undo=[];HIST.redo=[];HIST.last=designString();if(HIST.timer){clearTimeout(HIST.timer);HIST.timer=null}historyUpdateUI()}
function historyCommit(){
 if(HIST.applying)return;
 if(HIST.timer){clearTimeout(HIST.timer);HIST.timer=null}
 const cur=designString();
 if(cur===HIST.last)return;
 if(HIST.last){HIST.undo.push(HIST.last);if(HIST.undo.length>HISTORY_LIMIT)HIST.undo.shift()}
 HIST.last=cur;HIST.redo=[];historyUpdateUI();maybeAutoRevision();
}
function historySchedule(){if(HIST.applying)return;if(HIST.timer)clearTimeout(HIST.timer);HIST.timer=setTimeout(historyCommit,420)}
function historyApply(s,label){
 HIST.applying=true;
 try{D=JSON.parse(s);sel=null;if(typeof renderPanel==='function')renderPanel();if(typeof render==='function')render();else if(baseSave)baseSave()}finally{HIST.applying=false}
 HIST.last=s;if(baseSave)baseSave();historyUpdateUI();localMessage(label);
}
window.undoHistory=function(){
 historyCommit();if(!HIST.undo.length){historyUpdateUI();return}
 const prev=HIST.undo.pop();HIST.redo.push(HIST.last);historyApply(prev,`↶ 실행취소 — 이전 설계 상태로 복원했습니다. (남은 실행취소 ${HIST.undo.length}단계)`);
};
window.redoHistory=function(){
 historyCommit();if(!HIST.redo.length){historyUpdateUI();return}
 const next=HIST.redo.pop();HIST.undo.push(HIST.last);historyApply(next,`↷ 다시실행 — 되돌린 변경을 다시 적용했습니다. (남은 다시실행 ${HIST.redo.length}단계)`);
};
if(baseSave){save=function(){baseSave.apply(this,arguments);historySchedule()}}
try{undoDelete=window.undoHistory;updateUndoUI=historyUpdateUI}catch(e){}
document.addEventListener('keydown',e=>{
 const typing=/INPUT|TEXTAREA|SELECT/.test((document.activeElement&&document.activeElement.tagName)||'');if(typing)return;
 const ctrl=e.ctrlKey||e.metaKey,k=String(e.key).toLowerCase();
 if(ctrl&&(k==='y'||(k==='z'&&e.shiftKey))){e.preventDefault();e.stopImmediatePropagation();redoHistory()}
},true);

/* ── REV 버전관리 / 자동백업 ───────────────────────────────────── */
function revisions(){try{const a=JSON.parse(localStorage.getItem(REV_KEY)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
function saveRevisions(a){
 a=a.slice(0,REV_LIMIT);
 while(a.length>1&&JSON.stringify(a).length>REV_BYTES_LIMIT)a.pop();
 try{localStorage.setItem(REV_KEY,JSON.stringify(a));return true}catch(e){
  while(a.length>3){a.pop();try{localStorage.setItem(REV_KEY,JSON.stringify(a));return true}catch(_){}}
  return false;
 }
}
function nextRev(){let n=0;try{n=parseInt(localStorage.getItem(REV_SEQ_KEY)||'0',10)||0;n++;localStorage.setItem(REV_SEQ_KEY,String(n))}catch(e){n=Date.now()%1000}return 'REV.'+String(n).padStart(3,'0')}
function revState(){return{D:clone(D),view:clone(view),curName:typeof curName!=='undefined'?curName:'',sysName:document.getElementById('sysName')?.value||''}}
function addRevision(auto,note){
 historyCommit();
 const a=revisions(),rev={id:nextRev(),time:nowIso(),auto:!!auto,note:String(note||''),nodes:D.nodes?.length||0,edges:D.edges?.length||0,data:revState()};
 a.unshift(rev);const ok=saveRevisions(a);if(!auto)renderRevisionList();return ok?rev:null;
}
function maybeAutoRevision(){
 const a=revisions(),last=a.find(x=>x.auto),t=last?Date.parse(last.time)||0:0;
 if(!last||Date.now()-t>=AUTO_REV_MS)addRevision(true,'자동백업');
}
window.manualRevision=function(){const note=prompt('이번 REV 메모를 입력하세요.','수동 저장');if(note===null)return;const r=addRevision(false,note);if(r)localMessage(`${r.id} 저장 완료 — 블록 ${r.nodes} · 연결 ${r.edges}`)};
function fmtTime(s){try{return new Date(s).toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})}catch(e){return s}}
window.openRevisionManager=function(){historyCommit();renderRevisionList();document.getElementById('revDlg')?.classList.add('on')};
window.closeRevisionManager=function(){document.getElementById('revDlg')?.classList.remove('on')};
window.restoreRevision=function(id){
 const r=revisions().find(x=>x.id===id);if(!r)return;
 if(!confirm(`${r.id} (${fmtTime(r.time)}) 상태로 복원하시겠습니까?\n현재 상태는 '복원 전 자동보호' REV로 먼저 저장됩니다.`))return;
 addRevision(false,'복원 전 자동보호');
 HIST.applying=true;
 try{D=clone(r.data.D||{nodes:[],edges:[]});view=clone(r.data.view||{x:40,y:40,k:1});if(typeof curName!=='undefined')curName=r.data.curName||'';try{localStorage.setItem('sysdesign.name',curName||'')}catch(e){}const sn=document.getElementById('sysName');if(sn&&r.data.sysName)sn.value=r.data.sysName;if(typeof updateTitle==='function')updateTitle();sel=null;if(typeof renderPanel==='function')renderPanel();render()}finally{HIST.applying=false}
 if(baseSave)baseSave();historyInit();renderRevisionList();localMessage(`${r.id} 복원 완료 — 블록 ${D.nodes.length} · 연결 ${D.edges.length}`);
};
window.deleteRevision=function(id){if(!confirm(id+' 버전을 삭제하시겠습니까?'))return;saveRevisions(revisions().filter(x=>x.id!==id));renderRevisionList()};
window.downloadRevision=function(id){const r=revisions().find(x=>x.id===id);if(!r)return;downloadBlob(JSON.stringify(r.data,null,2),`${safeName(r.data.curName||r.data.sysName||'design')}_${r.id}.json`,'application/json')};
function renderRevisionList(){
 const box=document.getElementById('revList');if(!box)return;const a=revisions();
 box.innerHTML=a.length?a.map(r=>`<div class="rev-row"><div class="rev-main"><b>${esc(r.id)}</b><span class="rev-kind ${r.auto?'auto':'manual'}">${r.auto?'자동':'수동'}</span><small>${esc(fmtTime(r.time))}</small><div>${esc(r.note||'메모 없음')}</div><small>블록 ${r.nodes} · 연결 ${r.edges}</small></div><div class="acts"><button class="btn" onclick="restoreRevision('${r.id}')">복원</button><button class="btn" onclick="downloadRevision('${r.id}')">JSON</button><button class="btn danger" onclick="deleteRevision('${r.id}')">삭제</button></div></div>`).join(''):'<div class="empty">저장된 REV가 없습니다.<br>[현재 상태 REV 저장]을 누르면 이 시점의 설계를 보관합니다.</div>';
 const c=document.getElementById('revCount');if(c)c.textContent=`${a.length}/${REV_LIMIT}개 · 자동백업 간격 5분`;
}

/* ── .mesproj 프로젝트 통합 저장 / 열기 ───────────────────────── */
function downloadBlob(content,name,type){const a=document.createElement('a');const b=content instanceof Blob?content:new Blob([content],{type:type||'application/octet-stream'});a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},1200)}
function projectLocalSettings(){
 const keys=['sysdesign.modules','sysdesign.configs.v1','sysdesign.githubRepos.v1','sysdesign.dbsnap.v1','design.bihide','design.biovr','design.libview','design.libfold','sysdesign.pvFrame','sysdesign.pvDev','sysdesign.sideW',OFFLINE_KEY];
 const out={};for(const k of keys){try{const v=localStorage.getItem(k);if(v!==null)out[k]=v}catch(e){}}
 try{const g=JSON.parse(localStorage.getItem('design.gencfg')||'{}');delete g.url;delete g.key;out['design.gencfg']=JSON.stringify(g)}catch(e){}
 return out;
}
window.exportProject=async function(opts){
 opts=opts||{};historyCommit();if(!opts.skipRevision)addRevision(true,'프로젝트 내보내기 시점');
 const project={format:'MESPROJ',version:1,exported_at:nowIso(),app:'시스템 설계도 Offline',design:revState(),offline_default:isOfflineMode()};
 const libs=projectLocalSettings(),revs=revisions();
 if(typeof JSZip==='undefined'){downloadBlob(JSON.stringify({project,libraries:libs,revisions:revs},null,2),safeName(project.design.curName||project.design.sysName)+'.mesproj','application/json');if(!opts.quiet)localMessage('프로젝트(.mesproj) 저장 완료 — JSON 호환 형식으로 저장했습니다.');return}
 const zip=new JSZip();zip.file('project.json',JSON.stringify(project,null,2));zip.file('libraries.json',JSON.stringify(libs,null,2));zip.file('revisions.json',JSON.stringify(revs,null,2));
 let ghCount=0;if(typeof window.ghOfflineExportToZip==='function')try{ghCount=await window.ghOfflineExportToZip(zip)}catch(e){console.warn('GitHub offline export failed',e)}
 zip.file('README.txt','MES 시스템 설계도 오프라인 프로젝트 파일\r\n- project.json: 설계도\r\n- libraries.json: 내 모듈/내 구성 및 로컬 설정(비밀번호·Supabase 키 제외)\r\n- revisions.json: REV 백업 이력\r\n- github_offline/: GitHub 구성의 오프라인 원본 파일 사본\r\n');
 const blob=await zip.generateAsync({type:'blob'});downloadBlob(blob,safeName(project.design.curName||project.design.sysName||'MES_Project')+'.mesproj','application/zip');if(!opts.quiet)localMessage(`프로젝트(.mesproj) 저장 완료 — 설계 + 내 모듈/구성 + REV + GitHub 오프라인 원본 ${ghCount}개 파일을 한 파일로 묶었습니다.`);
};
window.importProject=function(){const i=document.createElement('input');i.type='file';i.accept='.mesproj,.zip,.json';i.onchange=()=>{const f=i.files&&i.files[0];if(f)loadProjectFile(f)};i.click()};
async function loadProjectFile(file){
 let pack=null;
 try{
  if(typeof JSZip!=='undefined'){
   try{const z=await JSZip.loadAsync(file),pf=z.file('project.json');if(pf){const project=JSON.parse(await pf.async('string'));const lf=z.file('libraries.json'),rf=z.file('revisions.json');pack={project,libraries:lf?JSON.parse(await lf.async('string')):{},revisions:rf?JSON.parse(await rf.async('string')):[],zip:z}}}catch(e){}
  }
  if(!pack){const txt=await file.text(),o=JSON.parse(txt);pack=o.project?o:{project:o,libraries:{},revisions:[]}}
  if(pack.project?.format!=='MESPROJ'&&!pack.project?.design)throw new Error('MESPROJ 형식이 아닙니다.');
  if(!confirm(`프로젝트 '${file.name}'을 열면 현재 설계가 바뀝니다.\n현재 상태는 REV로 보호한 뒤 진행합니다.`))return;
  addRevision(false,'프로젝트 열기 전 자동보호');
  const p=pack.project,d=p.design||p;
  HIST.applying=true;
  try{
   D=clone(d.D||{nodes:[],edges:[]});view=clone(d.view||{x:40,y:40,k:1});if(typeof curName!=='undefined')curName=d.curName||'';try{if(curName)localStorage.setItem('sysdesign.name',curName);else localStorage.removeItem('sysdesign.name')}catch(e){}
   const sn=document.getElementById('sysName');if(sn&&d.sysName)sn.value=d.sysName;
   for(const [k,v] of Object.entries(pack.libraries||{})){try{localStorage.setItem(k,String(v))}catch(e){}}
   /* 페이지 시작 뒤 가져온 GitHub 저장소 설정도 현재 실행 중인 REPO 목록에 즉시 반영한다. */
   if(typeof window.registerGithubRepo==='function')try{const rr=JSON.parse(localStorage.getItem('sysdesign.githubRepos.v1')||'[]');for(const x of rr||[])if(x?.owner&&x?.repo)window.registerGithubRepo(x)}catch(e){}
   if(pack.zip&&typeof window.ghOfflineImportFromZip==='function')try{const g=await window.ghOfflineImportFromZip(pack.zip);if(g.repos)localMessage(`GitHub 오프라인 원본 복원 중 — 저장소 ${g.repos}개 · 파일 ${g.files}개`)}catch(e){console.warn('GitHub offline restore failed',e)}
   /* 프로젝트 안의 REV는 현재 PC의 REV와 합친다. 열기 직전 보호본도 잃지 않는다. */
   if(Array.isArray(pack.revisions)&&pack.revisions.length){
    const localKeep=revisions(), imported=pack.revisions.map(x=>{const y=clone(x);const oldId=y.id||'REV';y.id=nextRev();y.note=`[가져온 ${oldId}] ${y.note||''}`.trim();return y});
    saveRevisions([...imported,...localKeep].sort((a,b)=>String(b.time||'').localeCompare(String(a.time||''))));
   }
   if(typeof updateTitle==='function')updateTitle();sel=null;if(typeof renderPanel==='function')renderPanel();render();
  }finally{HIST.applying=false}
  if(baseSave)baseSave();historyInit();applyOfflineUI();try{document.getElementById('skinMenu').innerHTML=skinMenuHtml()}catch(e){}try{document.getElementById('layoutMenu').innerHTML=layoutMenuHtml()}catch(e){}
  localMessage(`프로젝트 열기 완료 — 블록 ${D.nodes.length} · 연결 ${D.edges.length}`);
 }catch(e){alert('프로젝트 파일을 열지 못했습니다.\n'+e.message)}
}

/* ── 시스템 생성 직전 안전백업 ─────────────────────────────────── */
const baseGenerate=typeof window.generate==='function'?window.generate:null;
if(baseGenerate){
 window.generate=async function(){
  if(D&&D.nodes&&D.nodes.length){
   historyCommit();addRevision(true,'시스템 생성 직전 자동보호');
   const want=confirm('시스템 생성 전에 프로젝트(.mesproj) 백업 파일도 함께 저장할까요?\n\n· [확인]  프로젝트 파일 저장 후 시스템 생성\n· [취소]  REV 자동보호만 하고 바로 시스템 생성');
   if(want)try{await window.exportProject({skipRevision:true,quiet:true})}catch(e){localMessage('프로젝트 백업 중 오류: '+(e.message||e))}
  }
  return baseGenerate.apply(this,arguments);
 };
}

/* ── 모달/상태 UI 주입 ─────────────────────────────────────────── */
function injectUI(){
 if(!document.getElementById('revDlg')){
  const w=document.createElement('div');w.innerHTML=`<div class="mbg" id="revDlg"><div class="modal rev-modal"><div class="t">⏱ REV 버전관리 · 자동백업 <span class="x" onclick="closeRevisionManager()">×</span></div><div class="bd rev-bd"><div class="rev-top"><button class="btn primary" onclick="manualRevision()">＋ 현재 상태 REV 저장</button><button class="btn" onclick="exportProject()">⇩ 프로젝트(.mesproj) 저장</button><span id="revCount" class="msg"></span></div><div id="revList" class="rev-list"></div></div><div class="bt"><button class="btn" onclick="closeRevisionManager()">닫기</button><span class="msg">REV 복원 전에는 현재 상태를 자동으로 한 번 더 보호합니다.</span></div></div></div>`;document.body.appendChild(w.firstElementChild);
 }
 applyOfflineUI();historyUpdateUI();
}

historyInit();injectUI();
window.addEventListener('beforeunload',()=>{try{historyCommit();const a=revisions(),last=a[0],lastT=last?Date.parse(last.time)||0:0;if(D.nodes?.length&&Date.now()-lastT>AUTO_REV_MS)addRevision(true,'종료 전 자동백업')}catch(e){}});

})();
