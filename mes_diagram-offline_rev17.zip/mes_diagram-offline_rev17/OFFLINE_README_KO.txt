MES 시스템 설계도 Offline REV17 — GitHub 전체 원본 오프라인 보관판  (변경 내용은 CHANGELOG.txt)

[실행 방법]
1. ZIP 압축을 완전히 풉니다.
2. 압축을 푼 폴더의 index.html 을 더블클릭합니다.
3. Edge 또는 Chrome에서 바로 실행됩니다.

BAT / PowerShell / 로컬 서버는 필요하지 않습니다.

[REV5 주요 변경]
- 시스템 이름(sysName)을 설계와 함께 자동저장
- [지난 작업 이어서]에서 시스템 이름까지 복원
- Ctrl+S = 이 PC 브라우저에 현재 작업 저장 (Supabase 전송 없음)
- Supabase 저장은 [저장] 메뉴의 별도 온라인 기능으로 명확히 분리
- [시스템 생성] 직전 현재 상태를 REV로 자동보호
- 시스템 생성 시 프로젝트(.mesproj) 백업 파일 저장 여부 확인
- 프로젝트(.mesproj)에 설계 + 시스템 이름 + 내 모듈/구성 + REV 이력 포함
- 사용안내의 저장/백업 설명을 REV5 기준으로 정리

[권장 백업 방법]
작업 중에는 자동저장과 Ctrl+S를 사용하고,
중요한 작업 시점에는 [저장 → 프로젝트(.mesproj) 저장]으로 별도 파일을 보관하세요.
브라우저 데이터 삭제나 PC 교체에도 .mesproj 파일로 다시 열 수 있습니다.

[오프라인 원본 화면]
origin 폴더의 HTML/JS/CSS는 origin/bundle.js에도 함께 묶여 있습니다.
따라서 file:// 방식으로 index.html을 직접 열어도 시스템 생성 시 로컬 원본 화면을 읽을 수 있습니다.

[주의]
- index.html만 따로 옮기지 말고 폴더 전체를 함께 보관하세요.
- `UPDATE_ORIGIN.bat`로 원본을 갱신하면 origin/manifest.js와 origin/bundle.js도 자동 재생성됩니다.
- origin 폴더를 수동으로 수정한 경우에는 UPDATE_ORIGIN.bat를 다시 실행해 번들을 맞추는 것이 안전합니다.
- 기본 오프라인 모드에서는 Supabase 및 웹/GitHub 접속 기능이 잠깁니다.
- Supabase를 온라인으로 사용할 경우 실제 사내 배포 전 RLS/사용자 권한 정책을 별도로 점검하세요.

[변경 상세]
CHANGELOG.txt 참조


[REV6 GitHub 원본 시스템]
설정 및 화면 블록의 원본 저장소 목록에 다음 저장소가 등록되어 있습니다.
- https://github.com/KnagByeongju-123/smtec_main2
- https://github.com/KnagByeongju-123/GF
- https://github.com/KnagByeongju-123/mm_main
- https://github.com/KnagByeongju-123/Gyeongil
- https://github.com/KnagByeongju-123/TaeJin_ESG/tree/main
GF/TaeJin_ESG를 포함한 5개 원본은 인터넷 연결 상태에서 `UPDATE_ORIGIN.bat`를 더블클릭하면 오프라인 사본으로 갱신됩니다.

[REV8 - Git/Python 없는 원본 시스템 원클릭 업데이트]
- Windows에서 `UPDATE_ORIGIN.bat` 또는 `원본시스템_업데이트.bat`를 더블클릭하면 아래 5개 GitHub 원본을 자동 갱신합니다.
  smtec_main2 / GF / mm_main / Gyeongil / TaeJin_ESG
- 별도 명령어 입력은 필요 없습니다.
- Git과 Python은 설치할 필요가 없습니다. Windows 기본 PowerShell을 사용합니다.
- 인터넷 연결이 필요합니다.
- 업데이트가 끝나면 origin 폴더, manifest.js, bundle.js까지 자동 갱신하고 성공/실패 결과를 표시합니다.
- 특정 저장소 업데이트가 실패하면 정상 갱신된 저장소는 유지되고 실패 저장소명이 표시됩니다.

[REV10 - GitHub 구성보관함]
- 구성보관함의 "GitHub 원본 시스템"에 smtec_main2 / GF / mm_main / Gyeongil / TaeJin_ESG가 각각 별도 전체 구성으로 표시됩니다.
- 구성보관함 상단의 [GitHub 링크로 구성 자동추가]에 공개 GitHub 저장소 주소를 붙여넣으면 HTML 화면 목록을 읽어 자동으로 구성보관함에 등록합니다.
- 여러 링크를 한 줄에 하나씩 넣어 한 번에 등록할 수 있습니다.
- 자동 등록한 구성은 "GitHub 가져오기" 카테고리에 저장되며 [GitHub 갱신]으로 최신 화면 목록을 다시 읽을 수 있습니다.
- GitHub 링크 자동추가는 인터넷 연결이 필요하며, 기본 오프라인 모드에서는 실행 시 온라인 허용 여부를 먼저 확인합니다.
- 자동 등록한 저장소 정보도 .mesproj 백업에 포함됩니다.


[REV12 - GitHub 전체 원본 오프라인 보관]
- 구성보관함에 GitHub 주소를 붙여넣으면 HTML 목록만 저장하는 것이 아니라 저장소의 실제 파일 전체(HTML/JS/CSS/이미지/JSON 등)를 브라우저 IndexedDB에 오프라인 사본으로 저장합니다.
- 구성 카드에 "📦 오프라인 저장됨 · 파일수 · 용량" 상태가 표시됩니다.
- 기존 5개 GitHub 기본 구성에도 [📥 오프라인 원본 저장/갱신] 버튼이 있어 주소를 다시 붙여넣지 않아도 원본 전체를 저장할 수 있습니다.
- 같은 GitHub 링크를 다시 넣거나 [GitHub 원본·구성 갱신]을 누르면 최신 커밋을 확인한 뒤 변경된 원본과 화면 구성을 갱신합니다.
- 오프라인 모드에서는 GitHub 외부 접속 대신 저장해 둔 IndexedDB 원본을 먼저 사용합니다.
- 프로젝트(.mesproj) 저장 시 IndexedDB의 GitHub 오프라인 원본도 github_offline/ 폴더로 함께 묶입니다. 다른 PC에서 .mesproj를 열면 원본 사본도 다시 복원됩니다.
- GitHub 다운로드 중에만 인터넷이 필요하고 작업이 끝나면 이전 오프라인 모드로 자동 복귀합니다.
- 브라우저 데이터 삭제 시 IndexedDB 사본도 지워질 수 있으므로 중요한 설계는 .mesproj 파일로 별도 보관하는 것이 안전합니다.
