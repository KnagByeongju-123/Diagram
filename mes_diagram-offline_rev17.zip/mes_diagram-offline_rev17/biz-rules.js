/* ═══════════════ 업무 규칙 ═══════════════
   테이블 블록에 규칙을 적어 두면 생성된 등록·체크시트 화면이 저장·삭제 때 그대로 지킨다.
   · 검증(check)   : 식이 참이어야 저장 — 예) receipt_qty <= order_qty
   · 잠금(lock)    : 그 컬럼 값이 목록에 들어가면 수정·삭제 금지 — 예) status 가 승인·완료
   · 조건부 필수   : 식이 참일 때만 그 컬럼을 필수로 — 예) status == '반려' 이면 reject_reason
   규칙은 테이블 meta.rules 에 저장되고, 설계 JSON/모듈/구성에 함께 들어간다. */
const RULE_KIND={
 check:{name:'검증 (저장 전 조건)',hint:'식이 참이어야 저장됩니다. 예: receipt_qty <= order_qty'},
 lock:{name:'잠금 (수정·삭제 금지)',hint:'그 컬럼 값이 목록에 있으면 수정·삭제를 막습니다.'},
 require:{name:'조건부 필수',hint:'식이 참일 때만 그 컬럼을 필수로 봅니다.'}
};
const rulesOf=t=>(t&&t.meta&&Array.isArray(t.meta.rules))?t.meta.rules:[];
function ruleAdd(id,kind){
 const t=N(id);if(!t)return;t.meta.rules=rulesOf(t).slice();
 const cols=colsOf(t),flowCol=cols.find(c=>typeof parseFlow==='function'&&parseFlow(c));
 const num=cols.filter(c=>c.type==='num');
 if(kind==='lock')t.meta.rules.push({kind:'lock',col:(flowCol||cols[0]||{}).name||'',vals:flowCol&&parseFlow(flowCol)?parseFlow(flowCol).steps.slice(-1):[],msg:''});
 else if(kind==='require')t.meta.rules.push({kind:'require',expr:flowCol?`${flowCol.name} == '반려'`:'',col:(cols.find(c=>/reason|remark|note/.test(c.name))||cols[cols.length-1]||{}).name||'',msg:''});
 else t.meta.rules.push({kind:'check',expr:num.length>=2?`${num[1].name} <= ${num[0].name}`:'',msg:''});
 save();renderPanel();render();
}
function ruleDel(id,i){const t=N(id);if(!t)return;t.meta.rules=rulesOf(t).slice();t.meta.rules.splice(i,1);if(!t.meta.rules.length)delete t.meta.rules;save();renderPanel();render()}
function ruleSet(id,i,k,v){const t=N(id);if(!t)return;const r=rulesOf(t)[i];if(!r)return;
 if(k==='vals')r[k]=String(v).split(/[,·]/).map(x=>x.trim()).filter(Boolean);else r[k]=v;
 if(k==='kind'){delete r.expr;delete r.col;delete r.vals}
 save();render();if(k==='kind')renderPanel();
}
/* 규칙 식에 쓰인 컬럼이 실제로 있는지 — 오타 잡기 */
function ruleBadCols(t,r){
 const names=colsOf(t).map(c=>c.name),used=new Set();
 const src=(r.expr||'')+' '+(r.col||'');
 for(const m of src.matchAll(/[A-Za-z_][A-Za-z0-9_]*/g)){
  const w=m[0];
  if(['true','false','null','and','or','not','Number','String','Math','includes','length','trim'].includes(w))continue;
  if(!names.includes(w))used.add(w);
 }
 return [...used];
}
function rulesPanelHtml(t){
 const cols=colsOf(t),rules=rulesOf(t);
 const opt=(sel)=>cols.map(c=>`<option value="${esc(c.name)}" ${c.name===sel?'selected':''}>${esc(c.label||c.name)} (${esc(c.name)})</option>`).join('');
 const row=(r,i)=>{
  const bad=ruleBadCols(t,r);
  const body=r.kind==='lock'
   ? `<div class="row2"><select onchange="ruleSet('${t.id}',${i},'col',this.value)">${opt(r.col)}</select>
      <input value="${esc((r.vals||[]).join(', '))}" placeholder="승인, 완료  (이 값이면 잠금)" onchange="ruleSet('${t.id}',${i},'vals',this.value)"></div>`
   : r.kind==='require'
   ? `<div class="row2"><input value="${esc(r.expr||'')}" placeholder="조건식 — 예: status == '반려'" onchange="ruleSet('${t.id}',${i},'expr',this.value)">
      <select onchange="ruleSet('${t.id}',${i},'col',this.value)">${opt(r.col)}</select></div>`
   : `<input value="${esc(r.expr||'')}" placeholder="식 — 예: receipt_qty <= order_qty" onchange="ruleSet('${t.id}',${i},'expr',this.value)">`;
  return `<div class="rule">
   <div class="rule-h"><select onchange="ruleSet('${t.id}',${i},'kind',this.value)">${Object.entries(RULE_KIND).map(([k,v])=>`<option value="${k}" ${r.kind===k?'selected':''}>${esc(v.name)}</option>`).join('')}</select>
    <button class="x" title="규칙 삭제" onclick="ruleDel('${t.id}',${i})">×</button></div>
   ${body}
   <input value="${esc(r.msg||'')}" placeholder="어길 때 보여줄 메시지 (비우면 자동 문구)" onchange="ruleSet('${t.id}',${i},'msg',this.value)">
   ${bad.length?`<div class="rule-bad">⚠ 이 테이블에 없는 이름: ${esc(bad.join(', '))}</div>`:''}
  </div>`};
 return `<div class="f"><label>업무 규칙 <span style="font-weight:400;color:#8a94a6">— 생성된 등록·체크시트 화면이 저장·삭제 때 지킵니다</span></label>
  <div class="rules">${rules.map(row).join('')||'<div class="rule-empty">규칙 없음 — 아래 버튼으로 추가하세요.</div>'}</div>
  <div class="acts" style="margin-top:5px"><button class="btn" onclick="ruleAdd('${t.id}','check')">＋ 검증</button><button class="btn" onclick="ruleAdd('${t.id}','lock')">＋ 잠금</button><button class="btn" onclick="ruleAdd('${t.id}','require')">＋ 조건부 필수</button></div>
  <div style="font-size:11px;color:#8a94a6;line-height:1.6;margin-top:4px">식에는 이 테이블의 <b>컬럼명(영문)</b> 을 그대로 씁니다. 비교 <code>== != &lt; &lt;= &gt; &gt;=</code> · 그리고 <code>&amp;&amp;</code> · 또는 <code>||</code> · 계산 <code>+ - * /</code> 를 쓸 수 있습니다.<br>
   예) <code>receipt_qty &lt;= order_qty</code> · <code>qty &gt; 0 &amp;&amp; unit_price &gt; 0</code> · <code>status == '완료'</code></div></div>`;
}
/* ── 생성 화면에 들어가는 규칙 검사기 ── */
function rulesJs(t){
 const rules=rulesOf(t).filter(r=>r&&(r.expr||r.col));
 const labels={};for(const c of colsOf(t))labels[c.name]=c.label||c.name;
 return `
const RULES=${JSON.stringify(rules)},RLAB=${JSON.stringify(labels)};
function ruleTest(expr,r){try{return !!(new Function('r','with(r){return ('+expr+')}')(r||{}))}catch(e){console.warn('업무 규칙 식 오류:',expr,e.message);return true}}
function checkRules(o,mode,prev){
 for(const R of RULES){
  if(R.kind==='lock'){
   if(mode==='new')continue;
   const src=prev||o,v=String(src&&src[R.col]!=null?src[R.col]:'');
   if((R.vals||[]).some(x=>String(x)===v))return R.msg||((RLAB[R.col]||R.col)+' 이(가) "'+v+'" 라서 '+(mode==='delete'?'삭제':'수정')+'할 수 없습니다.');
  }else if(R.kind==='require'){
   if(mode==='delete')continue;
   if(R.expr&&!ruleTest(R.expr,o))continue;
   const v=o?o[R.col]:'';
   if(v===''||v==null||v===false)return R.msg||((RLAB[R.col]||R.col)+' 은(는) 이 경우 반드시 입력해야 합니다.');
  }else{
   if(mode==='delete')continue;
   if(R.expr&&!ruleTest(R.expr,o))return R.msg||('업무 규칙에 맞지 않습니다 — '+R.expr);
  }
 }
 return '';
}`;
}
/* 규칙 요약 (블록·설계검증·관계정리 문서용) */
function ruleText(t,r){
 const lab=n=>{const c=colsOf(t).find(x=>x.name===n);return c?(c.label||c.name):n};
 if(r.kind==='lock')return `${lab(r.col)} 이(가) ${(r.vals||[]).join('·')} 이면 수정·삭제 금지`;
 if(r.kind==='require')return `${r.expr} 이면 ${lab(r.col)} 필수`;
 return `저장 조건: ${r.expr}`;
}
