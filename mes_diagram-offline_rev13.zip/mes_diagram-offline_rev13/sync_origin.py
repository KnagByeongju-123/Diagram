"""Git 없이 GitHub ZIP을 직접 내려받아 origin/ 폴더를 갱신한다.

사용:
  python sync_origin.py
  python sync_origin.py GF TaeJin_ESG

주의: REV8의 기본 실행 방법은 UPDATE_ORIGIN.bat이며 Python은 필요하지 않다.
"""
import io
import json
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

OWNER = "KnagByeongju-123"
REPOS = ["smtec_main2", "GF", "mm_main", "Gyeongil", "TaeJin_ESG", "ESG_Smart_Factory_Mold", "iptk_1"]
BRANCH = "main"
SKIP = {".git", ".github"}
ROOT = Path(__file__).resolve().parent
DEST = ROOT / "origin"
MANIFEST_JS = DEST / "manifest.js"
KST = timezone(timedelta(hours=9))
UA = {"User-Agent": "MES-Origin-Sync"}
BUNDLE_EXTS = {".html", ".js", ".sql", ".txt", ".json", ".ts", ".css"}


def load_manifest():
    if not MANIFEST_JS.exists():
        return {}
    txt = MANIFEST_JS.read_text(encoding="utf-8-sig")
    try:
        return json.loads(txt[txt.index("{"): txt.rindex("}") + 1]).get("repos", {})
    except Exception:
        return {}


def request_bytes(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.read()


def repo_meta(repo, previous=None):
    sha = f"archive-{BRANCH}"
    date = None
    try:
        raw = request_bytes(f"https://api.github.com/repos/{OWNER}/{repo}/commits/{BRANCH}")
        data = json.loads(raw.decode("utf-8"))
        sha = data.get("sha") or sha
        date = (((data.get("commit") or {}).get("committer") or {}).get("date"))
    except Exception:
        if previous:
            sha = previous.get("commit") or sha
            date = previous.get("commit_date")
    return sha, date


def sync(repo, previous=None):
    url = f"https://codeload.github.com/{OWNER}/{repo}/zip/refs/heads/{BRANCH}"
    raw = request_bytes(url)
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            zf.extractall(t / "extract")
        roots = [p for p in (t / "extract").iterdir() if p.is_dir()]
        if not roots:
            raise RuntimeError("압축 파일에서 저장소 폴더를 찾지 못했습니다.")
        src = roots[0]
        stage = t / "stage"
        stage.mkdir()
        for p in src.iterdir():
            if p.name in SKIP:
                continue
            target = stage / p.name
            if p.is_dir():
                shutil.copytree(p, target)
            else:
                shutil.copy2(p, target)
        dest = DEST / repo
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(stage, dest)
    files = [p for p in (DEST / repo).rglob("*") if p.is_file()]
    sha, cdate = repo_meta(repo, previous)
    return {
        "upstream": f"https://github.com/{OWNER}/{repo}",
        "raw": f"https://raw.githubusercontent.com/{OWNER}/{repo}/{BRANCH}/",
        "branch": BRANCH,
        "commit": sha,
        "commit_date": cdate,
        "synced_at": datetime.now(KST).isoformat(timespec="seconds"),
        "files": len(files),
        "bytes": sum(p.stat().st_size for p in files),
    }



def build_bundle():
    bundle = {}
    for p in sorted(DEST.rglob("*")):
        if not p.is_file() or p.name == "bundle.js":
            continue
        if p.name != "manifest.js" and p.suffix.lower() not in BUNDLE_EXTS:
            continue
        rel = p.relative_to(DEST).as_posix()
        try:
            bundle[rel] = p.read_text(encoding="utf-8-sig")
        except (UnicodeDecodeError, OSError):
            continue
    (DEST / "bundle.js").write_text(
        "/* 오프라인 직접실행용 원본 파일 번들 - 자동 생성 */\n"
        "window.ORIGIN_BUNDLE=" + json.dumps(bundle, ensure_ascii=False, separators=(",", ":")) + ";\n",
        encoding="utf-8",
    )
    return len(bundle)

def main():
    requested = sys.argv[1:]
    invalid = [r for r in requested if r not in REPOS]
    if invalid:
        print("등록되지 않은 저장소: " + ", ".join(invalid))
        return 2
    targets = requested or REPOS
    DEST.mkdir(exist_ok=True)
    repos = load_manifest()
    failed = []
    for r in targets:
        try:
            repos[r] = sync(r, repos.get(r))
            m = repos[r]
            short = str(m["commit"])[:7]
            print(f"OK {r:<24} {short}  {m['files']:>4} files  {m['bytes']/1e6:6.1f} MB")
        except Exception as e:
            failed.append(r)
            print(f"FAIL {r}: {e}")
    data = {"generated_at": datetime.now(KST).isoformat(timespec="seconds"), "repos": repos}
    MANIFEST_JS.write_text(
        "/* sync_origin.py 가 만든 파일 - 직접 고치지 마세요 */\n"
        "window.ORIGIN_MANIFEST=" + json.dumps(data, ensure_ascii=False, indent=1) + ";\n",
        encoding="utf-8",
    )
    count = build_bundle()
    print(f"bundle 갱신: {count} files")
    if failed:
        print("업데이트 실패: " + ", ".join(failed))
        return 1
    print(f"업데이트 완료: {len(targets)}개 저장소")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
