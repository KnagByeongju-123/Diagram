[REV9 원본시스템 업데이트 방법]

1. ZIP 파일을 반드시 압축 해제합니다.
2. 압축을 푼 폴더에서 UPDATE_ORIGIN.bat 를 더블클릭합니다.
3. Git 또는 Python 설치는 필요하지 않습니다.
4. 업데이트하는 동안에만 인터넷 연결이 필요합니다.
5. 성공하면 "Update completed successfully."가 표시됩니다.
6. 완료 후 index.html 을 실행합니다.

업데이트 대상:
- smtec_main2
- GF
- mm_main
- Gyeongil
- TaeJin_ESG

REV8에서 발생한 PowerShell ParserError는 스크립트 내부 한글 문자의 인코딩 문제였습니다.
REV9의 실행 스크립트는 ASCII 문자만 사용하도록 변경했습니다.
