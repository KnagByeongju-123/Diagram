/* ═══════════════ 구성 보관함 ═══════════════
   모듈 보관함 = 작은 기능 묶음, 구성 보관함 = 업종별 전체 시스템 뼈대.
   CONFIG_PRESETS는 data/config-presets.js에 따로 두어 업종 추가 시 큰 본체를 수정하지 않아도 된다. */
const CFG_LS='sysdesign.configs.v1';
const CFG_CUSTOM_COLS={
 vendor:[['vendor_code','업체코드','text',1,1],['vendor_name','업체명','text',0,1],['vendor_type','업체구분','text'],['manager','담당자','text'],['phone','전화번호','text'],['email','이메일','text'],['address','주소','text'],['active','사용여부','bool'],['remark','비고','text']],
 item:[['item_code','품번','text',1,1],['item_name','품명','text',0,1],['spec','규격','text'],['material','재질','text'],['unit','단위','text'],['unit_price','단가','num'],['customer','고객사','text'],['active','사용여부','bool'],['remark','비고','text']],
 process:[['process_code','공정코드','text',1,1],['process_name','공정명','text',0,1],['equipment','설비','text'],['std_ct','표준CT','num'],['worker_count','표준인원','num'],['active','사용여부','bool'],['remark','비고','text']],
 bom:[['bom_no','BOM번호','text',1,1],['item_code','모품번','text',0,1],['child_code','자품번','text',0,1],['qty','소요수량','num',0,1],['unit','단위','text'],['effective_date','적용일','date'],['remark','비고','text']],
 service:[['request_no','작업번호','text',1,1],['request_date','접수일','date',0,1],['customer','고객사','text'],['place','작업장소','text'],['title','작업내용','text',0,1],['owner','담당자','text'],['due_date','예정일','date'],['status','상태','text'],['remark','비고','text']],
 project:[['project_no','프로젝트번호','text',1,1],['project_name','프로젝트명','text',0,1],['customer','발주처','text'],['site','현장','text'],['start_date','시작일','date'],['due_date','완료예정일','date'],['owner','담당자','text'],['progress','진척률','num'],['status','상태','text'],['remark','비고','text']],
 finance:[['doc_no','전표번호','text',1,1],['doc_date','일자','date',0,1],['vendor','거래처','text'],['category','구분','text'],['amount','금액','num',0,1],['tax','세액','num'],['due_date','지급·수금예정일','date'],['status','상태','text'],['remark','비고','text']],
 import:[['import_no','수입관리번호','text',1,1],['po_no','발주번호','text'],['vendor','해외거래처','text'],['item_code','품목','text'],['invoice_no','Invoice No.','text'],['bl_no','B/L No.','text'],['etd','ETD','date'],['eta','ETA','date'],['qty','수량','num'],['amount','금액','num'],['status','통관상태','text'],['remark','비고','text']],
 haccp:[['check_no','점검번호','text',1,1],['check_date','점검일','date',0,1],['process','공정','text'],['item','점검항목','text',0,1],['standard','관리기준','text'],['result_value','측정값','text'],['judgement','판정','text',0,1],['checker','점검자','text'],['action','조치내용','text'],['remark','비고','text']]
};
function cfgClone(o){return JSON.parse(JSON.stringify(o))}
function cfgMy(){try{return JSON.parse(localStorage.getItem(CFG_LS)||'[]')}catch(e){return[]}}
function cfgSetMy(a){try{localStorage.setItem(CFG_LS,JSON.stringify(a))}catch(e){}}
function cfgCounts(p){let m=(p.modules||[]).length,s=0,c=0;for(const x of p.modules||[])for(const y of x.sections||[]){s++;c+=(y.screens||[]).length}return{m,s,c}}
function cfgAll(){return [...CONFIG_PRESETS.map((x,i)=>({...x,_kind:'builtin',_idx:i})),...cfgMy().map((x,i)=>({...x,_kind:'mine',_idx:i,cat:x.cat||'내 구성',icon:x.icon||'⭐'}))]}
function cfgPackagedRepo(repo){try{if(!repo)return false;const m=(typeof ORIGIN_MAN==='function'?ORIGIN_MAN():window.ORIGIN_MANIFEST?.repos)||{};if(m&&m[repo])return true;return !!(window.ORIGIN_BUNDLE&&Object.keys(window.ORIGIN_BUNDLE).some(k=>k.startsWith(repo+'/')))}catch(e){return false}}
function cfgOfflineBadgeHtml(p){if(!p?.github||!p.repo)return'';const packaged=cfgPackagedRepo(p.repo);return `<span class="offline-badge ${packaged?'ok':'wait'}" data-ghrepo="${esc(p.repo)}">${packaged?'📦 패키지 오프라인 사본':'📦 오프라인 사본 확인 중'}</span>`}
async function cfgRefreshOfflineBadges(){
 const els=[...document.querySelectorAll('[data-ghrepo]')],repos=[...new Set(els.map(e=>e.dataset.ghrepo).filter(Boolean))];
 for(const repo of repos){let label='',ok=false;if(cfgPackagedRepo(repo)){label='📦 패키지 오프라인 사본';ok=true}else if(typeof window.ghOfflineGetMeta==='function'){try{const m=await window.ghOfflineGetMeta(repo);if(m){label=`📦 오프라인 저장됨 · ${m.files||0}개 · ${typeof ghOfflineFmtBytes==='function'?ghOfflineFmtBytes(m.bytes||0):Math.round((m.bytes||0)/1024)+'KB'}`;ok=true}}catch(e){}}
  if(!label)label='○ 오프라인 원본 미저장';for(const e of document.querySelectorAll(`[data-ghrepo="${CSS.escape(repo)}"]`)){e.textContent=label;e.classList.toggle('ok',ok);e.classList.toggle('wait',!ok)}
 }
}
function cfgRefreshCats(prefer){const el=$('cfgCat');if(!el)return;const old=prefer||el.value||'전체',cats=['전체',...new Set(cfgAll().map(x=>x.cat).filter(Boolean))];el.innerHTML=cats.map(x=>`<option>${esc(x)}</option>`).join('');el.value=cats.includes(old)?old:'전체'}
function openConfigLibrary(){
 configDlg.classList.add('on');$('cfgSearch').value='';cfgRefreshCats();
 renderConfigLibrary();
}
function renderConfigLibrary(){
 const cat=$('cfgCat')?.value||'전체',q=String($('cfgSearch')?.value||'').trim().toLowerCase(),all=cfgAll();
 const rows=all.filter(p=>(cat==='전체'||p.cat===cat)&&(!q||`${p.name} ${p.desc||''} ${p.cat} ${(p.modules||[]).map(m=>m.name).join(' ')} ${(p.data?.nodes||[]).map(n=>n.name||'').join(' ')}`.toLowerCase().includes(q)));
 $('cfgList').innerHTML=rows.length?rows.map(p=>{const c=p.data?{m:p.data.nodes?.filter(n=>n.type==='module').length||0,s:p.data.nodes?.filter(n=>n.type==='section').length||0,c:p.data.nodes?.filter(n=>n.type==='screen').length||0}:cfgCounts(p);const key=`${p._kind}:${p._idx}`;
  return `<div class="config-card"><div class="ct"><span style="font-size:18px">${esc(p.icon||'🗂')}</span><b>${esc(p.name)}</b><span class="tag">${esc(p.cat)}</span>${p.github?`<a class="gh-link" href="${esc(p.github)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">GitHub ↗</a>`:''}</div><small>${esc(p.desc||'저장한 전체 설계 구성')}</small><span class="config-count">대분류 ${c.m} · 중분류 ${c.s} · 화면 ${c.c}${p.repo?` · <b style="color:#1d6b4a">📎 원본 ${esc(p.repo)}</b>`:''}</span>${cfgOfflineBadgeHtml(p)}<div class="acts"><button class="btn" onclick="showConfigDetail('${key}')">구성보기</button><button class="btn primary" onclick="applyConfigPreset('${key}','replace')">새 설계로 적용</button><button class="btn" onclick="applyConfigPreset('${key}','append')">현재 설계에 추가</button>${p.github?(p._kind==='mine'?`<button class="btn" onclick="refreshGithubConfig(${p._idx})">↻ GitHub 원본·구성 갱신</button>`:`<button class="btn" onclick="syncGithubPresetOffline('${key}')">📥 오프라인 원본 저장/갱신</button>`):''}${p._kind==='mine'?`<button class="btn danger" onclick="deleteMyConfig(${p._idx})">삭제</button>`:''}</div></div>`}).join(''):'<div class="config-empty">조건에 맞는 구성이 없습니다.</div>';
 if(rows[0])showConfigDetail(`${rows[0]._kind}:${rows[0]._idx}`);else $('cfgDetail').innerHTML='<div class="config-empty">구성을 선택하세요.</div>';
 cfgRefreshOfflineBadges();
}
function cfgGet(key){const [k,n]=String(key).split(':'),i=Number(n);return k==='builtin'?CONFIG_PRESETS[i]:cfgMy()[i]}
function showConfigDetail(key){const p=cfgGet(key);if(!p)return;if(p.data){const mods=(p.data.nodes||[]).filter(n=>n.type==='module'),secs=(p.data.nodes||[]).filter(n=>n.type==='section'),scr=(p.data.nodes||[]).filter(n=>n.type==='screen'),tbl=(p.data.nodes||[]).filter(n=>n.type==='table');$('cfgDetail').innerHTML=`<h3>${esc(p.icon||'⭐')} ${esc(p.name)}</h3><p>${esc(p.desc||'저장한 전체 설계 구성')}</p>${p.github?`<div class="manual-note" style="margin-bottom:8px"><b>🐙 GitHub 원본</b> · ${esc(p.branch||'main')} 브랜치${p.repo?` · 저장소키 ${esc(p.repo)}`:''}<br><a href="${esc(p.github)}" target="_blank" rel="noopener">${esc(p.github)}</a><br>${cfgOfflineBadgeHtml(p)}</div>`:''}<div class="manual-note">구성 전체를 그대로 불러옵니다. 대분류 ${mods.length} · 중분류 ${secs.length} · 화면 ${scr.length} · 테이블 ${tbl.length} · 연결 ${(p.data.edges||[]).length}</div>`;cfgRefreshOfflineBadges();return}
 const tree=(p.modules||[]).map((m,mi)=>`<div class="config-mod"><div class="config-mh"><span>${esc(m.icon||'▣')} ${esc(m.name)}</span><button class="cfg-mb" onclick="cfgPartToModule('${key}',${mi})" title="이 대분류(중분류·화면${p.repo?'·원본 DB 테이블':'·테이블'} 포함)를 모듈 보관함 › 내 모듈에 저장">📦 모듈로 저장</button></div>${(m.sections||[]).map((sec,si)=>`<div class="config-sec"><div class="config-sh"><b>└ ${esc(sec.name)}</b><button class="cfg-mb sm" onclick="cfgPartToModule('${key}',${mi},${si})" title="이 중분류만 모듈로 저장">📦</button></div><div class="config-screens">${(sec.screens||[]).map(x=>esc(x[0])).join(' · ')}</div></div>`).join('')}</div>`).join('');
 const c=cfgCounts(p);$('cfgDetail').innerHTML=`<h3>${esc(p.icon||'🗂')} ${esc(p.name)}</h3><p>${esc(p.desc||'')}</p><div class="config-count" style="margin-bottom:10px;display:flex;align-items:center;gap:8px">대분류 ${c.m} · 중분류 ${c.s} · 화면 ${c.c}<button class="cfg-mb" style="margin-left:auto" onclick="cfgPartToModule('${key}')" title="구성 전체를 하나의 모듈로 저장">📦 구성 전체를 모듈로</button></div><div class="config-tree">${tree}</div>`;
}
function cfgFindDirect(parent,type,name){return D.edges.filter(e=>e.kind==='contains'&&e.from===parent.id).map(e=>N(e.to)).find(x=>x?.type===type&&sameScreenName(x.name,name))||null}
function cfgEnsureModule(spec,append){let n=append?D.nodes.find(x=>x.type==='module'&&sameScreenName(x.name,spec.name)):null;if(!n){n={id:uid(),type:'module',name:spec.name,x:0,y:0,meta:{icon:spec.icon||'▣',desc:spec.desc||''}};D.nodes.push(n)}return n}
function cfgEnsureSection(mod,spec,append){let n=append?cfgFindDirect(mod,'section',spec.name):null;if(!n){n={id:uid(),type:'section',name:spec.name,x:0,y:0,meta:{icon:spec.icon||'▣'}};D.nodes.push(n);D.edges.push({id:uid(),from:mod.id,to:n.id,kind:'contains',label:''})}return n}
/* spec = [화면명, 종류, 파일명?] · repo 가 있는 구성(원본 시스템)은 화면을 포크 사본 원본 파일에 바로 연결한다 */
function cfgEnsureScreen(sec,spec,append,repo){let n=append?cfgFindDirect(sec,'screen',spec[0]):null;if(!n){n={id:uid(),type:'screen',name:spec[0],x:0,y:0,meta:{file:spec[2]||'',kind:spec[1]||'input'}};if(repo&&spec[2]){n.meta.repo=repo;n.meta.origin=true}D.nodes.push(n);D.edges.push({id:uid(),from:sec.id,to:n.id,kind:'contains',label:''})}return n}
function cfgAddColumns(t,profile){t.meta=t.meta||{};t.meta.cols=t.meta.cols||[];let defs=[];
 if(CFG_CUSTOM_COLS[profile])defs=CFG_CUSTOM_COLS[profile].map(x=>({name:x[0],label:x[1],type:x[2]||'text',pk:!!x[3],req:!!x[4]}));
 else if(typeof BASIC_PROFILE!=='undefined'&&BASIC_PROFILE[profile])defs=BASIC_PROFILE[profile].keys.map(k=>BASIC_COL_LIBRARY[k]).filter(Boolean).map((d,i)=>({...cfgClone(d),name:BASIC_PROFILE[profile].keys[i]||d.name}));
 else {addRecommendedBasicColumns(t);return}
 for(const d of defs){const norm=basicColNorm(d.label||d.name);if(!t.meta.cols.some(c=>basicColNorm(c.label||c.name)===norm))t.meta.cols.push(cfgClone(d))}
}
/* 원본 시스템(포크) 구성 — REPO_SCHEMA(원본 DB 스키마)로 테이블·컬럼·참조선까지 만든다 */
function cfgRepoTables(repo,screens,append){
 const S=typeof REPO_SCHEMA!=='undefined'&&REPO_SCHEMA[repo];if(!S)return 0;
 const byName={};let made=0;
 const ensure=name=>{if(byName[name])return byName[name];const spec=S.tables[name];if(!spec)return null;
  let t=D.nodes.find(x=>x.type==='table'&&x.name===name);
  if(!t){t={id:uid(),type:'table',name,x:0,y:0,meta:{desc:spec.label||'',repo,cols:spec.cols.map(c=>({name:c[0],label:c[1],type:c[2]||'text',pk:!!c[3],req:!!c[4]}))}};D.nodes.push(t);made++}
  return byName[name]=t};
 for(const sc of screens){const f=String(sc.meta.file||'').split('?')[0];
  for(const tn of S.screens[f]||[]){const t=ensure(tn);if(t&&!D.edges.some(e=>e.kind==='uses'&&e.from===sc.id&&e.to===t.id))D.edges.push({id:uid(),from:sc.id,to:t.id,kind:'uses',label:''})}}
 for(const [a,c,b,d] of S.refs||[]){if(!byName[a])continue;const A=byName[a],B=ensure(b);if(!B)continue;
  if(!D.edges.some(e=>e.kind==='ref'&&e.from===A.id&&e.to===B.id))D.edges.push({id:uid(),from:A.id,to:B.id,kind:'ref',label:`${c} → ${b}.${d}`,card:'1N'})}
 return made;
}
function cfgBuildPreset(p,mode,autoTable){const append=mode==='append';if(!append){clearDeleteUndo();D={nodes:[],edges:[]};curName='';try{localStorage.removeItem('sysdesign.name')}catch(e){}updateTitle()}
 let madeM=0,madeS=0,madeSc=0,madeT=0;const allScr=[];
 for(const ms of p.modules||[]){const beforeM=D.nodes.length,mod=cfgEnsureModule(ms,append);if(D.nodes.length>beforeM)madeM++;
  for(const ss of ms.sections||[]){const beforeS=D.nodes.length,sec=cfgEnsureSection(mod,ss,append);if(D.nodes.length>beforeS)madeS++;const screens=[];
   for(const sp of ss.screens||[]){const before=D.nodes.length,sc=cfgEnsureScreen(sec,sp,append,p.repo);if(D.nodes.length>before)madeSc++;screens.push(sc);allScr.push(sc)}
   if(autoTable&&!p.repo&&screens.length){let t=null;for(const sc of screens){t=firstUseTable(sc);if(t)break}if(!t){t=createTableForScreen(screens[0]);madeT++}for(const sc of screens)if(!D.edges.some(e=>e.kind==='uses'&&e.from===sc.id&&e.to===t.id))D.edges.push({id:uid(),from:sc.id,to:t.id,kind:'uses',label:''});cfgAddColumns(t,ss.profile||sectionProfileId(sec));autoKeyRequired(t);autoColumnNames(t);for(const sc of screens)autoScreenFileName(sc)}
  }
 }
 if(autoTable&&p.repo)madeT+=cfgRepoTables(p.repo,allScr,append);
 autoLayout();select(null);save();render();fitAll();return{madeM,madeS,madeSc,madeT}}
/* 구성 보관함 → 모듈 보관함: 현재 설계는 건드리지 않고, 임시 설계에서 대분류(또는 중분류)를 만들어 내 모듈로 저장 */
function cfgPartToModule(key,mi,si){
 const p=cfgGet(key);if(!p||!p.modules)return;
 let mods=p.modules,def=p.name;
 if(mi!=null){const m=p.modules[mi];if(!m)return;
  if(si!=null){const s=(m.sections||[])[si];if(!s)return;mods=[{...m,sections:[s]}];def=`${m.name} · ${s.name}`}
  else{mods=[m];def=m.name}}
 const auto=$('cfgAutoTable')?.checked!==false;
 const sub={...p,modules:mods};
 const keep={D,sel,save,render,fitAll,select};let ids=[],cnt={};
 try{
  D={nodes:[],edges:[]};save=()=>{};render=()=>{};fitAll=()=>{};select=s=>{sel=s};
  cfgBuildPreset(sub,'append',auto);
  ids=D.nodes.map(n=>n.id);cnt={s:D.nodes.filter(n=>n.type==='screen').length,t:D.nodes.filter(n=>n.type==='table').length};
  const name=(prompt(`모듈 이름 — 화면 ${cnt.s} · 테이블 ${cnt.t} · 블록 ${ids.length}개를 모듈 보관함 › 내 모듈에 저장`,def)||'').trim();
  if(!name){$('cfgMsg').textContent='모듈 저장을 취소했습니다.';return}
  const r=packIdsAsModule(ids,name);
  if(r)$('cfgMsg').textContent=`📦 '${name}' 모듈 저장 — 블록 ${r.nodes} · 연결 ${r.edges}. [설계 › 📦 모듈 보관함 › 내 모듈]에서 꺼내 쓸 수 있습니다.`;
 }finally{D=keep.D;sel=keep.sel;save=keep.save;render=keep.render;fitAll=keep.fitAll;select=keep.select}
}
function cfgApplySaved(p,mode){if(mode==='replace'){clearDeleteUndo();D={nodes:[],edges:[]};curName='';try{localStorage.removeItem('sysdesign.name')}catch(e){}updateTitle()}
 const before=new Set(D.nodes.map(n=>n.id));
 insertModule(p.data,p.name,{auto:false});
 let madeT=0;
 if(p.repo&&$('cfgAutoTable')?.checked!==false){
  const scr=D.nodes.filter(n=>!before.has(n.id)&&n.type==='screen');
  /* ① 원본 화면 — 원본 DB/소스 스키마로 테이블·칼럼 */
  madeT+=cfgRepoTables(p.repo,scr,true);
  /* ② 원본 파일이 없는(생성할) 화면 — 중분류마다 기본 테이블 */
  const bySec=new Map();
  for(const sc of scr){if(firstUseTable(sc))continue;const sec=D.edges.filter(e=>e.kind==='contains'&&e.to===sc.id).map(e=>N(e.from)).find(Boolean);const k=sec?sec.id:'_';if(!bySec.has(k))bySec.set(k,{sec,list:[]});bySec.get(k).list.push(sc)}
  for(const {sec,list} of bySec.values()){if(list.every(x=>x.meta.origin))continue;const gen=list.filter(x=>!x.meta.origin);const t=createTableForScreen(gen[0]);madeT++;
   for(const sc of gen)if(!D.edges.some(e=>e.kind==='uses'&&e.from===sc.id&&e.to===t.id))D.edges.push({id:uid(),from:sc.id,to:t.id,kind:'uses',label:''});
   try{cfgAddColumns(t,sec?sectionProfileId(sec):'common');autoKeyRequired(t);autoColumnNames(t)}catch(e){}}
 }
 autoLayout();select(null);save();render();fitAll();return{madeT}}
function applyConfigPreset(key,mode){const p=cfgGet(key);if(!p)return;if(mode==='replace'&&D.nodes.length&&!confirm(`현재 설계를 지우고 '${p.name}' 구성으로 시작할까요?`))return;configDlg.classList.remove('on');
 if(p.data){const r=cfgApplySaved(p,mode)||{};$('stat').textContent=`🗂 ${p.name} 구성 적용 완료 — 저장된 전체 설계를 ${mode==='replace'?'새 설계로 적용':'현재 설계에 추가'}했습니다.${r.madeT?` · 테이블 ${r.madeT}개 생성`:''}${p.repo?` (📎 원본: origin/${p.repo} 포크 사본)`:''}`;return}
 const r=cfgBuildPreset(p,mode,$('cfgAutoTable')?.checked!==false);$('stat').textContent=p.repo?`🗂 ${p.name} 구성 적용 완료 — 대분류 ${r.madeM} · 중분류 ${r.madeS} · 화면 ${r.madeSc}${r.madeT?` · 테이블 ${r.madeT} (원본 DB 스키마)`:''} (📎 원본: origin/${p.repo} 포크 사본 사용)`:`🗂 ${p.name} 구성 적용 완료 — 대분류 ${r.madeM} · 중분류 ${r.madeS} · 화면 ${r.madeSc}${$('cfgAutoTable')?.checked!==false?` · 테이블 ${r.madeT}`:''} 추가`;
}
function saveCurrentAsConfig(){if(!D.nodes.length)return $('cfgMsg').textContent='저장할 설계가 없습니다.';const name=(prompt('내 구성 이름',($('sysName')?.value||'내 시스템')+' 구성')||'').trim();if(!name)return;const desc=(prompt('간단한 설명 (선택)','현재 설계 전체를 저장한 구성')||'').trim();const ids=D.nodes.map(n=>n.id),map=new Map(ids.map((id,i)=>[id,i]));const minx=Math.min(...D.nodes.map(n=>n.x||0)),miny=Math.min(...D.nodes.map(n=>n.y||0));const data={nodes:D.nodes.map(n=>({type:n.type,name:n.name,meta:cfgClone(n.meta||{}),dx:(n.x||0)-minx,dy:(n.y||0)-miny})),edges:D.edges.filter(e=>map.has(e.from)&&map.has(e.to)).map(e=>e.card?[map.get(e.from),map.get(e.to),e.kind,e.label||'',e.card]:[map.get(e.from),map.get(e.to),e.kind,e.label||''])};let a=cfgMy(),i=a.findIndex(x=>x.name===name);const rec={name,desc,icon:'⭐',data,at:Date.now()};if(i>=0){if(!confirm(`'${name}' 구성이 이미 있습니다. 덮어쓸까요?`))return;a[i]=rec}else a.push(rec);cfgSetMy(a);$('cfgCat').value='내 구성';renderConfigLibrary();$('cfgMsg').textContent=`'${name}' 구성을 저장했습니다.`}
function deleteMyConfig(i){let a=cfgMy(),p=a[i];if(!p||!confirm(`'${p.name}' 구성을 삭제할까요?`))return;a.splice(i,1);cfgSetMy(a);cfgRefreshCats();renderConfigLibrary();$('cfgMsg').textContent='내 구성을 삭제했습니다.'}

/* ═══════════════ REV11 · GitHub 링크 → 구성보관함 + 전체 원본 오프라인 저장 ═══════════════ */
function cfgGhLabel(path){
 const f=String(path||'').split('/').pop().replace(/\.html?$/i,'');
 if(/^index$/i.test(f))return '메인';
 return f.replace(/[_-]+/g,' ').replace(/\b\w/g,m=>m.toUpperCase()).slice(0,42)||'화면';
}
function cfgGhKind(path){const s=String(path||'').toLowerCase();if(/dashboard|board|monitor|summary|chart/.test(s))return'dash';if(/check|inspection|audit/.test(s))return'check';if(/status|history|list|report|inquiry|view/.test(s))return'status';if(/input|register|registration|edit|manage|management|upload|order|request/.test(s))return'input';return'other'}
function cfgGhGroup(path,prefixCounts){
 const seg=String(path||'').split('/');if(seg.length>1)return seg.slice(0,-1).join(' / ').slice(0,40);
 const base=seg[0].replace(/\.html?$/i,'');const p=(base.match(/^([A-Za-z0-9]+)[_-]/)||[])[1];if(p&&prefixCounts[p]>=2)return p.toUpperCase();return /^index\.html?$/i.test(seg[0])?'메인':'기타 화면';
}
function cfgGhPlainText(s){return String(s||'').replace(/<script\b[\s\S]*?<\/script>/gi,' ').replace(/<style\b[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'"').replace(/&#39;/gi,"'").replace(/[+`'"\\]/g,' ').replace(/\s+/g,' ').trim()}
function cfgGhColName(label,i){let s=String(label||'').trim().toLowerCase().replace(/[^0-9a-zA-Z가-힣_]+/g,'_').replace(/^_+|_+$/g,'');return (s||('col_'+(i+1))).slice(0,40)}
function cfgGhColType(label){const s=String(label||'').toLowerCase();if(/날짜|일자|date|일시|시간/.test(s))return'date';if(/금액|수량|타수|점수|합계|평균|순위|count|qty|amount|price|score|번호|no\.?$/.test(s))return'num';if(/사용|여부|체크|승인/.test(s))return'bool';return'text'}
function cfgGhTableContext(src,pos,file,seq){const from=Math.max(0,pos-1800),pre=String(src||'').slice(from,pos);let m=[...pre.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)].pop();if(m)return m[1].replace(/^render/i,'')||m[1];m=[...pre.matchAll(/getElementById\(\s*['"]([^'"]+)['"]\s*\)/g)].pop();if(m)return m[1];m=[...pre.matchAll(/<h[1-6][^>]*>([\s\S]{0,120}?)<\/h[1-6]>/gi)].pop();if(m){const t=cfgGhPlainText(m[1]);if(t)return t.slice(0,36)}const b=String(file||'').split('/').pop().replace(/\.html?$/i,'')||'page';return `${b}_table${seq}`}
function cfgGhExtractTables(src,file){src=String(src||'');const out=[],seen=new Set();let seq=0,m;const re=/<table\b[\s\S]{0,14000}?<\/table>/gi;while((m=re.exec(src))&&seq<80){seq++;const chunk=m[0],heads=[];let h;const hr=/<th\b[^>]*>([\s\S]{0,500}?)<\/th>/gi;while((h=hr.exec(chunk))&&heads.length<40){const t=cfgGhPlainText(h[1]);if(t&&t.length<=80)heads.push(t)}const context=cfgGhTableContext(src,m.index,file,seq),sig=(context+'|'+heads.join('|')).toLowerCase();if(seen.has(sig))continue;seen.add(sig);const cols=(heads.length?heads:['내용']).map((x,i)=>({name:cfgGhColName(x,i),label:x,type:cfgGhColType(x),pk:false,req:false}));out.push({name:context,cols,desc:`${file} 화면에서 자동 감지한 테이블`,kind:'ui'});}return out}
function cfgGhExtractDataCollections(src,file){src=String(src||'');const counts={};for(const m of src.matchAll(/\bDATA\.([A-Za-z_$][\w$]*)\s*(?:\.|\[)/g))counts[m[1]]=(counts[m[1]]||0)+1;const out=[];for(const [name,cnt] of Object.entries(counts)){if(cnt<2||/^(settings?)$/i.test(name))continue;out.push({name,cols:[],desc:`${file}의 DATA.${name} 데이터 컬렉션 (${cnt}회 참조)`,kind:'data'});}return out}
async function cfgGithubData(repoKey,repoName,files){
 files=(files||[]).filter(f=>/\.html?$/i.test(f)).slice(0,500);
 const prefixCounts={};for(const f of files){const b=f.split('/').pop().replace(/\.html?$/i,''),p=(b.match(/^([A-Za-z0-9]+)[_-]/)||[])[1];if(p)prefixCounts[p]=(prefixCounts[p]||0)+1}
 const nodes=[{type:'module',name:repoName,meta:{icon:'🐙',desc:'GitHub 저장소에서 자동 생성한 구성'}}],edges=[],sections=new Map(),tableKeys=new Map();
 const secOf=g=>{if(sections.has(g))return sections.get(g);const i=nodes.length;nodes.push({type:'section',name:g,meta:{icon:'▣'}});edges.push([0,i,'contains','']);sections.set(g,i);return i};
 const addTable=(screenIndex,t,file)=>{const base=String(t.name||'table').replace(/\s+/g,' ').trim().slice(0,50)||'table',key=(t.kind==='data'?'data:':'ui:')+base.toLowerCase();let ti=tableKeys.get(key);if(ti==null){let name=base,n=2;while(nodes.some(x=>x.type==='table'&&x.name===name))name=`${base}_${n++}`;ti=nodes.length;nodes.push({type:'table',name,meta:{desc:t.desc||'',repo:repoKey,file,source:'github-auto',sourceKind:t.kind||'ui',cols:(t.cols||[]).map(c=>({...c}))}});tableKeys.set(key,ti)}if(!edges.some(e=>e[0]===screenIndex&&e[1]===ti&&e[2]==='uses'))edges.push([screenIndex,ti,'uses','']);};
 const ordered=files.slice().sort((a,b)=>(/^index\.html?$/i.test(a)?-1:0)-(/^index\.html?$/i.test(b)?-1:0)||a.localeCompare(b));
 for(const f of ordered){const g=cfgGhGroup(f,prefixCounts),si=secOf(g),i=nodes.length;nodes.push({type:'screen',name:cfgGhLabel(f),meta:{file:f,kind:cfgGhKind(f),repo:repoKey,origin:true}});edges.push([si,i,'contains','']);try{const src=typeof window.ghOfflineGetText==='function'?await window.ghOfflineGetText(repoKey,f):'';if(src){for(const t of cfgGhExtractTables(src,f))addTable(i,t,f);for(const t of cfgGhExtractDataCollections(src,f))addTable(i,t,f)}}catch(e){}}
 return{nodes,edges};
}
function cfgGithubNormalize(u){try{const r=ghRepo(u);return r?`https://github.com/${r.own}/${r.repo}`.toLowerCase():String(u||'').trim().replace(/\/$/,'').toLowerCase()}catch(e){return String(u||'').trim().toLowerCase()}}
function cfgMergeGithubTablesIntoData(base,analyzed){
 const out=cfgClone(base||{nodes:[],edges:[]}),A=analyzed||{nodes:[],edges:[]};out.nodes=out.nodes||[];out.edges=out.edges||[];
 const baseScreens=new Map();out.nodes.forEach((n,i)=>{if(n.type==='screen'&&n.meta?.file)baseScreens.set(String(n.meta.file).split('?')[0].toLowerCase(),i)});
 const tableMap=new Map();out.nodes.forEach((n,i)=>{if(n.type==='table')tableMap.set(`${String(n.meta?.file||'').toLowerCase()}|${String(n.name||'').toLowerCase()}`,i)});
 let added=0;for(const e of A.edges||[]){if(e[2]!=='uses')continue;const sc=A.nodes?.[e[0]],tb=A.nodes?.[e[1]];if(sc?.type!=='screen'||tb?.type!=='table')continue;const f=String(sc.meta?.file||'').split('?')[0].toLowerCase(),bi=baseScreens.get(f);if(bi==null)continue;const tk=`${String(tb.meta?.file||sc.meta?.file||'').toLowerCase()}|${String(tb.name||'').toLowerCase()}`;let ti=tableMap.get(tk);if(ti==null){ti=out.nodes.length;out.nodes.push(cfgClone(tb));tableMap.set(tk,ti);added++}if(!out.edges.some(x=>x[0]===bi&&x[1]===ti&&x[2]==='uses'))out.edges.push([bi,ti,'uses','']);}
 return{data:out,added};
}
async function cfgEnsureOnlineForGithub(){
 if(typeof isOfflineMode==='function'&&isOfflineMode()){
  if(!confirm('GitHub 최신 원본을 내려받으려면 인터넷 연결을 잠시 허용해야 합니다.\n다운로드가 끝나면 다시 오프라인 모드로 돌아갑니다.'))return false;
  if(typeof toggleOfflineMode==='function')toggleOfflineMode();
 }
 return true;
}
function cfgRestoreOffline(wasOffline){try{if(wasOffline&&typeof isOfflineMode==='function'&&!isOfflineMode()&&typeof toggleOfflineMode==='function')toggleOfflineMode()}catch(e){}}
function cfgGhProgress(repo,msg,p){if(!msg)return;const total=p?.total||0,done=p?.done||0;if(p?.phase==='download')msg.textContent=`${repo} 오프라인 원본 저장 중… ${done}/${total}${p.path?' · '+p.path:''}`;else msg.textContent=`${repo} · ${p?.message||'GitHub 확인 중…'}`}
async function cfgSyncGithubRepo(r,repoKey,msg){
 if(typeof window.ghOfflineSyncRepo!=='function')throw new Error('오프라인 저장 모듈을 불러오지 못했습니다. github-offline-store.js를 확인하세요.');
 const meta=await window.ghOfflineSyncRepo({key:repoKey,owner:r.own,repo:r.repo,branch:r.branch||''},p=>cfgGhProgress(r.repo,msg,p));
 if(typeof registerGithubRepo==='function')registerGithubRepo({owner:r.own,repo:r.repo,branch:meta.branch});
 return meta;
}
async function syncGithubPresetOffline(key){
 const p=cfgGet(key);if(!p?.github)return;const msg=$('cfgGithubMsg'),r=typeof ghRepo==='function'?ghRepo(p.github):null;if(!r){if(msg)msg.textContent='GitHub 주소를 해석하지 못했습니다.';return}
 const wasOffline=typeof isOfflineMode==='function'&&isOfflineMode();if(!await cfgEnsureOnlineForGithub())return;
 try{const meta=await cfgSyncGithubRepo(r,p.repo||r.repo,msg);const analyzed=await cfgGithubData(p.repo||r.repo,r.repo,meta.html||[]);let added=0;if(p.data){const merged=cfgMergeGithubTablesIntoData(p.data,analyzed);p.data=merged.data;added=merged.added}else p.data=analyzed;if(msg)msg.textContent=`✅ ${r.repo} 원본+테이블 분석 완료 — 파일 ${meta.files}개 · 테이블 ${p.data.nodes?.filter(n=>n.type==='table').length||0}개${added?` (+${added})`:''} · ${typeof ghOfflineFmtBytes==='function'?ghOfflineFmtBytes(meta.bytes):meta.bytes+' bytes'}`;renderConfigLibrary()}
 catch(e){if(msg)msg.textContent='오프라인 원본 저장/테이블 분석 실패: '+(e.message||e)}
 finally{cfgRestoreOffline(wasOffline)}
}
async function cfgImportGithubUrl(url,targetIndex){
 const msg=$('cfgGithubMsg'),r=typeof ghRepo==='function'?ghRepo(url):null;if(!r)throw new Error('GitHub 저장소 주소 형식이 아닙니다. 예: https://github.com/사용자/저장소');
 const base=`https://github.com/${r.own}/${r.repo}`;
 /* 이미 기본 구성으로 들어 있는 저장소는 중복 구성을 만들지 않고 원본 사본만 최신화한다. */
 if(!Number.isInteger(targetIndex)){
  const bi=CONFIG_PRESETS.findIndex(x=>x.github&&cfgGithubNormalize(x.github)===cfgGithubNormalize(base));
  if(bi>=0){const bp=CONFIG_PRESETS[bi],meta=await cfgSyncGithubRepo(r,bp.repo||r.repo,msg),analyzed=await cfgGithubData(bp.repo||r.repo,r.repo,meta.html||[]);let added=0;if(bp.data){const merged=cfgMergeGithubTablesIntoData(bp.data,analyzed);bp.data=merged.data;added=merged.added}else bp.data=analyzed;if(msg)msg.textContent=`✅ ${r.repo} 기본 구성 갱신 완료 — 원본 ${meta.files}개 · 테이블 ${bp.data.nodes?.filter(n=>n.type==='table').length||0}개${added?` (+${added})`:''}`;renderConfigLibrary();return{builtin:true,meta};}
 }
 const provisionalKey=Number.isInteger(targetIndex)?(cfgMy()[targetIndex]?.repo||r.repo):(typeof registerGithubRepo==='function'?registerGithubRepo({owner:r.own,repo:r.repo,branch:r.branch||'main'}):r.repo);
 const meta=await cfgSyncGithubRepo(r,provisionalKey,msg);if(!meta.html?.length)throw new Error(`${r.own}/${r.repo} 저장소에서 HTML 화면을 찾지 못했습니다.`);
 const repoKey=typeof registerGithubRepo==='function'?registerGithubRepo({owner:r.own,repo:r.repo,branch:meta.branch}):provisionalKey;
 const data=await cfgGithubData(repoKey,r.repo,meta.html),size=typeof ghOfflineFmtBytes==='function'?ghOfflineFmtBytes(meta.bytes):`${Math.round((meta.bytes||0)/1024)}KB`;
 const rec={name:`${r.repo} · GitHub 전체 구성`,desc:`${base} · ${meta.branch} · 화면 ${meta.html.length}개 · 전체 원본 ${meta.files}개/${size} 오프라인 저장`,icon:'🐙',cat:'GitHub 가져오기',repo:repoKey,github:base,branch:meta.branch,offlineFiles:meta.files,offlineBytes:meta.bytes,offlineCommit:meta.commit,data,at:Date.now()};
 const a=cfgMy();let idx=Number.isInteger(targetIndex)?targetIndex:a.findIndex(x=>x.github&&cfgGithubNormalize(x.github)===cfgGithubNormalize(base));
 if(idx>=0&&idx<a.length){if(!Number.isInteger(targetIndex)&&!confirm(`'${a[idx].name}' 구성이 이미 있습니다. GitHub 최신 원본과 화면 구성으로 갱신할까요?`))return null;a[idx]=rec}else{a.push(rec);idx=a.length-1}
 cfgSetMy(a);cfgRefreshCats('GitHub 가져오기');renderConfigLibrary();if(msg)msg.textContent=`✅ ${r.repo} 등록 완료 — 구성 ${meta.html.length}화면 · 원본 ${meta.files}개/${size} 오프라인 저장`;
 return rec;
}
async function addGithubConfigsFromInput(){
 const box=$('cfgGithubUrl'),btn=$('cfgGithubAdd'),msg=$('cfgGithubMsg'),urls=[...new Set(String(box?.value||'').split(/\s+/).map(x=>x.trim()).filter(Boolean))];
 if(!urls.length){if(msg)msg.textContent='GitHub 저장소 링크를 입력하세요.';return}
 const wasOffline=typeof isOfflineMode==='function'&&isOfflineMode();if(!await cfgEnsureOnlineForGithub()){if(msg)msg.textContent='GitHub 자동추가를 취소했습니다.';return}
 if(btn)btn.disabled=true;let ok=0,fail=[];
 try{for(let i=0;i<urls.length;i++){if(msg)msg.textContent=`GitHub 구성 자동추가 ${i+1}/${urls.length}…`;try{const r=await cfgImportGithubUrl(urls[i]);if(r)ok++}catch(e){fail.push(`${urls[i]} — ${e.message||e}`)}}}
 finally{if(btn)btn.disabled=false;cfgRestoreOffline(wasOffline)}
 if(msg)msg.textContent=fail.length?`완료: ${ok}개 처리 · ${fail.length}개 실패 — ${fail[0]}`:`✅ 완료: ${ok}개 GitHub 구성을 처리했고 원본 전체를 오프라인 저장했습니다.`;
 if(ok&&box)box.value='';cfgRefreshOfflineBadges();
}
async function refreshGithubConfig(i){
 const a=cfgMy(),p=a[i];if(!p||!p.github)return;const wasOffline=typeof isOfflineMode==='function'&&isOfflineMode();if(!await cfgEnsureOnlineForGithub())return;
 try{await cfgImportGithubUrl(p.github,i)}catch(e){const m=$('cfgGithubMsg');if(m)m.textContent='GitHub 갱신 실패: '+(e.message||e)}finally{cfgRestoreOffline(wasOffline)}
}
