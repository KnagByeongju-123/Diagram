/* GitHub 원본 시스템을 구성 보관함의 '전체 구성'으로 보여주는 프리셋.
   - 기존 모듈 보관함의 검증된 화면/테이블 구조를 재사용한다.
   - 화면 파일은 각 GitHub 저장소 원본(repo + origin:true)에 연결한다. */
(function(){
'use strict';
if(typeof CONFIG_PRESETS==='undefined'||typeof BUILTIN==='undefined')return;
const clone=o=>JSON.parse(JSON.stringify(o));
/* 생성 시스템의 셸 파일(index.html 등)과 이름이 겹치는 원본 화면은 출력 파일명만 바꾸고 원본은 src 로 읽는다 */
const RESERVED=/^(index|user_information|user_manual)\.html$/i;
function fixReserved(n,repo){const f=String(n.meta.file||'').split('?')[0];if(!RESERVED.test(f))return;n.meta.srcFile=f;n.meta.src='origin/'+repo+'/'+f;n.meta.file=repo.toLowerCase()+'_'+f}
const hasFile=(repo,f)=>{const B=window.ORIGIN_BUNDLE;if(!B)return true;return !!B[repo+'/'+String(f||'').split('?')[0]]};
const edgeObj=e=>Array.isArray(e)?{a:e[0],b:e[1],k:e[2],lab:e[3]||'',card:e[4]||''}:{a:e.from,b:e.to,k:e.kind,lab:e.label||'',card:e.card||''};
function repoData(data,repo,rootName){
 const d=clone(data||{nodes:[],edges:[]});
 for(const n of d.nodes||[])if(n.type==='screen'&&n.meta&&n.meta.file){if(hasFile(repo,n.meta.file)){n.meta.repo=repo;n.meta.origin=true;fixReserved(n,repo)}else{delete n.meta.repo;delete n.meta.origin}}
 if(!(d.nodes||[]).some(n=>n.type==='module')){
  const oldEdges=(d.edges||[]).map(edgeObj),targets=new Set(oldEdges.filter(e=>e.k==='contains').map(e=>e.b));
  d.nodes.unshift({type:'module',name:rootName||repo,meta:{icon:'🐙',desc:'원본 시스템 전체 구성 (오프라인 포크 사본)'}});
  d.edges=oldEdges.map(e=>e.card?[e.a+1,e.b+1,e.k,e.lab,e.card]:[e.a+1,e.b+1,e.k,e.lab]);
  for(let i=0;i<d.nodes.length-1;i++){const n=d.nodes[i+1];if(!targets.has(i)&&(n.type==='section'||n.type==='screen'))d.edges.push([0,i+1,'contains',''])}
 }
 return d;
}
/* 여러 기능 모듈을 하나의 저장소 전체 구성으로 합친다.
   각 기능 모듈 이름을 중분류로 만들고 화면/테이블 연결은 그대로 보존한다. */
function mergeFeaturePresets(items,repo,rootName,icon){
 const nodes=[{type:'module',name:rootName,meta:{icon:icon||'🐙',desc:'원본 시스템 전체 구성 (오프라인 포크 사본)'}}],edges=[];
 const tableByName=new Map(),screenByFile=new Map();
 const addEdge=(a,b,k,lab,card)=>{if(a==null||b==null||a===b)return;const sig=[a,b,k,lab||'',card||''].join('|');if(edges.some(x=>[x[0],x[1],x[2],x[3]||'',x[4]||''].join('|')===sig))return;edges.push(card?[a,b,k,lab||'',card]:[a,b,k,lab||''])};
 for(const p of items){
  const secIdx=nodes.length;nodes.push({type:'section',name:p.name,meta:{icon:'▣'}});addEdge(0,secIdx,'contains','');
  const map=new Map(),d=p.data||{nodes:[],edges:[]};
  for(let i=0;i<(d.nodes||[]).length;i++){
   const old=d.nodes[i];if(!old||old.type==='module'||old.type==='section')continue;
   let ni=null;
   if(old.type==='table'){
    if(tableByName.has(old.name))ni=tableByName.get(old.name);
    else{const n=clone(old);ni=nodes.length;nodes.push(n);tableByName.set(old.name,ni)}
   }else if(old.type==='screen'){
    const n=clone(old);n.meta=n.meta||{};if(n.meta.file&&hasFile(repo,n.meta.file)){n.meta.repo=repo;n.meta.origin=true;fixReserved(n,repo)}
    const key=(n.meta.file||n.name||'').toLowerCase();
    if(key&&screenByFile.has(key))ni=screenByFile.get(key);
    else{ni=nodes.length;nodes.push(n);if(key)screenByFile.set(key,ni)}
    addEdge(secIdx,ni,'contains','');
   }else{const n=clone(old);ni=nodes.length;nodes.push(n)}
   map.set(i,ni);
  }
  for(const ee of d.edges||[]){const e=edgeObj(ee);if(e.k==='contains')continue;const a=map.get(e.a),b=map.get(e.b);if(a!=null&&b!=null)addEdge(a,b,e.k,e.lab,e.card)}
 }
 return{nodes,edges};
}
function findBuiltin(name){return BUILTIN.find(x=>x.name===name)}
function hasRepo(data,repo){return(data?.nodes||[]).some(n=>n.type==='screen'&&n.meta?.repo===repo)}
const out=[];
const sm=BUILTIN.filter(x=>x.cat==='ESG 스마트팩토리'&&hasRepo(x.data,'smtec_main2'));
if(sm.length)out.push({cat:'원본 시스템 (포크)',name:'smtec_main2 · ESG 스마트팩토리 전체 구성',icon:'🐙',repo:'smtec_main2',desc:`smtec_main2의 점검·품질·소재·MES·환경·금형·출하 등 ${sm.length}개 기능 모듈을 하나의 전체 구성으로 묶음`,data:mergeFeaturePresets(sm,'smtec_main2','smtec_main2 · ESG 스마트팩토리','🌿')});
const mm=findBuiltin('mm MES 화면배치도 (전체 메뉴체계)');
if(mm)out.push({cat:'원본 시스템 (포크)',name:'mm_main · TJ MES 전체 구성',icon:'🐙',repo:'mm_main',desc:'mm_main의 전체 메뉴체계 · 금형부품·수리·생산일보·업무현황 등을 구성보관함에서 한 번에 적용',data:repoData(mm.data,'mm_main','mm_main · TJ MES')});
const gi=findBuiltin('GI MES 화면배치도 (전체 메뉴체계)');
if(gi)out.push({cat:'원본 시스템 (포크)',name:'Gyeongil · GI MES 전체 구성',icon:'🐙',repo:'Gyeongil',desc:'Gyeongil의 전체 메뉴체계 · 금형점검·타발·물류·기준정보 등을 구성보관함에서 한 번에 적용',data:repoData(gi.data,'Gyeongil','Gyeongil · GI MES')});
const gf=findBuiltin('GF · 호영회');
if(gf)out.push({cat:'원본 시스템 (포크)',name:'GF · 호영회 전체 구성',icon:'🐙',repo:'GF',desc:'GF 저장소의 원본 화면을 구성보관함에서 바로 적용',data:repoData(gf.data,'GF','GF · 호영회')});
const te=findBuiltin('TaeJin_ESG · 품질/환경/계측');
if(te)out.push({cat:'원본 시스템 (포크)',name:'TaeJin_ESG · 품질/환경/계측 전체 구성',icon:'🐙',repo:'TaeJin_ESG',desc:'TaeJin_ESG의 생산일보·환경·조도·보안·3D·계측기 화면을 구성보관함에서 한 번에 적용',data:repoData(te.data,'TaeJin_ESG','TaeJin_ESG · 품질/환경/계측')});
/* stock_ledger — 원본 화면 2개(재고 입출고 현황 · 재고 검증표) 패키지 구성 */
out.push({cat:'원본 시스템 (포크)',name:'stock_ledger · 태진 재고원장 전체 구성',icon:'🧩',repo:'stock_ledger',desc:'stock_ledger 저장소 — 재고 입출고 현황(원소재 입고·사용·재고·출하·마감) · 재고 검증표',data:repoData({nodes:[
  {type:'module',name:'stock_ledger · 재고원장',meta:{icon:'📦',desc:'태진 재고 입출고 현황 · 재고원장'}},
  {type:'section',name:'재고원장',meta:{icon:'📦'}},
  {type:'screen',name:'재고 입출고 현황',meta:{file:'index.html',kind:'status'}},
  {type:'screen',name:'재고 검증표',meta:{file:'검증표.html',kind:'status'}}],
 edges:[[0,1,'contains',''],[1,2,'contains',''],[1,3,'contains','']]},'stock_ledger','stock_ledger · 재고원장')});
for(const p of out){p.icon='🧩';const S=typeof REPO_SCHEMA!=='undefined'&&REPO_SCHEMA[p.repo];p.desc+=` · 화면은 origin/${p.repo} 포크 사본(오프라인)`+(S?` · 테이블 ${Object.keys(S.tables).length}개 함께 생성 (${S.src||'원본 스키마'})`:'')}
for(const p of out)if(!CONFIG_PRESETS.some(x=>x.name===p.name))CONFIG_PRESETS.push(p);
window.GITHUB_CONFIG_PRESETS=out;
})();
