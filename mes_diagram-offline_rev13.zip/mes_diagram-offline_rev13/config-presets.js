/* 업종별 구성 보관함 데이터 — 화면/기능 코드와 분리하여 이 파일만 수정하면 업종 구성을 늘릴 수 있습니다. */
const CONFIG_PRESETS=[
 {cat:'제조업',name:'프레스 · 금형 제조업',icon:'🔩',desc:'수주부터 프레스 생산, 금형, 품질, 자재, 설비, 안전까지 기본 MES 구성',modules:[
  {name:'영업관리',icon:'📑',sections:[{name:'수주·영업',profile:'order',screens:[['수주등록','input'],['수주현황','status'],['수주대시보드','dash']]},{name:'출하·납품',profile:'shipping',screens:[['출하등록','input'],['출하현황','status'],['납품현황','status']]}]},
  {name:'생산관리',icon:'⚙',sections:[{name:'생산계획',profile:'production',screens:[['생산계획 등록','input'],['생산계획 현황','status']]},{name:'생산실적',profile:'production',screens:[['생산실적 등록','input'],['생산현황','status'],['생산대시보드','dash']]}]},
  {name:'금형관리',icon:'🧰',sections:[{name:'금형대장',profile:'die',screens:[['금형등록','input'],['금형현황','status']]},{name:'금형점검',profile:'die',screens:[['금형점검 등록','check'],['금형점검 현황','status']]},{name:'금형수리',profile:'die',screens:[['금형수리이력','input'],['수리현황','status']]}]},
  {name:'품질관리',icon:'✓',sections:[{name:'공정검사',profile:'quality',screens:[['검사결과 등록','input'],['검사결과 현황','status']]},{name:'불량관리',profile:'quality',screens:[['불량등록','input'],['불량현황','status'],['품질대시보드','dash']]}]},
  {name:'자재관리',icon:'📦',sections:[{name:'자재·재고',profile:'material',screens:[['자재입고','input'],['자재출고','input'],['재고현황','status']]}]},
  {name:'설비관리',icon:'🏭',sections:[{name:'설비·보전',profile:'equipment',screens:[['설비등록','input'],['예방점검 등록','check'],['고장이력','input'],['설비현황','status']]}]},
  {name:'안전환경',icon:'🦺',sections:[{name:'위험성평가',profile:'safety',screens:[['위험성평가 등록','input'],['개선조치','input'],['위험성평가 현황','status']]},{name:'안전교육',profile:'common',screens:[['교육일지 등록','input'],['교육현황','status']]}]}
 ]},
 {cat:'제조업',name:'자동차부품 제조업',icon:'🚗',desc:'수주·생산·LOT 추적·품질·출하 중심의 자동차부품 기본 구성',modules:[
  {name:'영업·납품',icon:'🚚',sections:[{name:'수주·영업',profile:'order',screens:[['수주등록','input'],['수주현황','status']]},{name:'출하·납품',profile:'shipping',screens:[['출하등록','input'],['납품현황','status']]}]},
  {name:'생산관리',icon:'⚙',sections:[{name:'생산실적',profile:'production',screens:[['생산실적 등록','input'],['생산현황','status'],['생산대시보드','dash']]},{name:'LOT 추적',profile:'production',screens:[['LOT 실적등록','input'],['LOT 추적현황','status']]}]},
  {name:'품질관리',icon:'🔎',sections:[{name:'수입검사',profile:'quality',screens:[['수입검사 등록','input'],['수입검사 현황','status']]},{name:'공정검사',profile:'quality',screens:[['공정검사 등록','input'],['공정불량 현황','status']]},{name:'출하검사',profile:'quality',screens:[['출하검사 등록','input'],['출하검사 현황','status']]}]},
  {name:'자재·재고',icon:'📦',sections:[{name:'원부자재',profile:'material',screens:[['입고등록','input'],['출고등록','input'],['재고현황','status']]}]},
  {name:'설비·금형',icon:'🧰',sections:[{name:'설비보전',profile:'equipment',screens:[['설비점검 등록','check'],['고장이력','input'],['설비현황','status']]},{name:'금형관리',profile:'die',screens:[['금형등록','input'],['금형점검','check'],['금형현황','status']]}]},
  {name:'기준정보',icon:'▦',sections:[{name:'품목기준',profile:'item',screens:[['품목관리','input']]},{name:'거래처기준',profile:'vendor',screens:[['거래처관리','input']]},{name:'공정기준',profile:'process',screens:[['공정관리','input']]}]}
 ]},
 {cat:'제조업',name:'일반 제조업 · MES',icon:'🏭',desc:'업종에 관계없이 가장 많이 쓰는 수주·생산·품질·재고·설비 기본형',modules:[
  {name:'영업관리',icon:'📑',sections:[{name:'수주·영업',profile:'order',screens:[['수주등록','input'],['수주현황','status']]},{name:'출하관리',profile:'shipping',screens:[['출하등록','input'],['출하현황','status']]}]},
  {name:'생산관리',icon:'⚙',sections:[{name:'생산실적',profile:'production',screens:[['생산실적 등록','input'],['생산현황','status'],['생산대시보드','dash']]}]},
  {name:'품질관리',icon:'✓',sections:[{name:'품질검사',profile:'quality',screens:[['검사결과 등록','input'],['검사현황','status'],['불량현황','status']]}]},
  {name:'자재관리',icon:'📦',sections:[{name:'자재·재고',profile:'material',screens:[['입고등록','input'],['출고등록','input'],['재고현황','status']]}]},
  {name:'설비관리',icon:'🔧',sections:[{name:'설비·보전',profile:'equipment',screens:[['설비등록','input'],['점검등록','check'],['고장이력','input'],['설비현황','status']]}]},
  {name:'기준정보',icon:'▦',sections:[{name:'품목기준',profile:'item',screens:[['품목관리','input']]},{name:'거래처기준',profile:'vendor',screens:[['거래처관리','input']]}]}
 ]},
 {cat:'제조업',name:'기계가공 · 정밀가공',icon:'⚙',desc:'가공공정, 외주가공, 공구, 검사, 설비를 중심으로 한 기본 구성',modules:[
  {name:'영업관리',icon:'📑',sections:[{name:'수주·견적',profile:'order',screens:[['견적등록','input'],['수주등록','input'],['수주현황','status']]}]},
  {name:'가공관리',icon:'🛠',sections:[{name:'가공계획',profile:'production',screens:[['가공계획 등록','input'],['가공계획 현황','status']]},{name:'가공실적',profile:'production',screens:[['가공실적 등록','input'],['가공현황','status']]},{name:'외주가공',profile:'purchase',screens:[['외주발주 등록','input'],['외주입고 현황','status']]}]},
  {name:'품질관리',icon:'🔎',sections:[{name:'가공검사',profile:'quality',screens:[['측정결과 등록','input'],['검사현황','status'],['불량현황','status']]}]},
  {name:'공구·설비',icon:'🔧',sections:[{name:'공구관리',profile:'equipment',screens:[['공구등록','input'],['교체이력','input']]},{name:'설비보전',profile:'equipment',screens:[['설비점검','check'],['고장이력','input'],['설비현황','status']]}]},
  {name:'자재·재고',icon:'📦',sections:[{name:'소재재고',profile:'material',screens:[['소재입고','input'],['소재출고','input'],['재고현황','status']]}]}
 ]},
 {cat:'제조업',name:'조립 · 전자부품 제조업',icon:'🔌',desc:'BOM·조립실적·검사·자재·출하·A/S를 중심으로 구성',modules:[
  {name:'제품기준',icon:'▦',sections:[{name:'품목기준',profile:'item',screens:[['품목관리','input']]},{name:'BOM관리',profile:'bom',screens:[['BOM등록','input'],['BOM현황','status']]}]},
  {name:'생산관리',icon:'⚙',sections:[{name:'조립생산',profile:'production',screens:[['조립실적 등록','input'],['생산현황','status'],['생산대시보드','dash']]}]},
  {name:'품질관리',icon:'✓',sections:[{name:'검사관리',profile:'quality',screens:[['검사결과 등록','input'],['불량현황','status']]}]},
  {name:'자재관리',icon:'📦',sections:[{name:'부품재고',profile:'material',screens:[['부품입고','input'],['부품출고','input'],['재고현황','status']]}]},
  {name:'영업·출하',icon:'🚚',sections:[{name:'수주관리',profile:'order',screens:[['수주등록','input'],['수주현황','status']]},{name:'출하관리',profile:'shipping',screens:[['출하등록','input'],['출하현황','status']]}]},
  {name:'고객서비스',icon:'☎',sections:[{name:'A/S관리',profile:'service',screens:[['A/S 접수','input'],['처리현황','status']]}]}
 ]},
 {cat:'유통·무역',name:'철강 · 소재 · 수입무역',icon:'🚢',desc:'견적·수주·해외발주·수입통관·창고·출하·정산 기본 구성',modules:[
  {name:'영업관리',icon:'📑',sections:[{name:'견적·수주',profile:'order',screens:[['견적등록','input'],['수주등록','input'],['수주현황','status']]}]},
  {name:'구매·수입',icon:'🚢',sections:[{name:'해외발주',profile:'purchase',screens:[['해외발주 등록','input'],['발주현황','status']]},{name:'수입통관',profile:'import',screens:[['선적정보 등록','input'],['통관현황','status']]}]},
  {name:'재고관리',icon:'📦',sections:[{name:'창고재고',profile:'material',screens:[['입고등록','input'],['출고등록','input'],['재고현황','status']]}]},
  {name:'출하관리',icon:'🚚',sections:[{name:'납품·출하',profile:'shipping',screens:[['출하등록','input'],['납품현황','status']]}]},
  {name:'정산관리',icon:'₩',sections:[{name:'매입·매출',profile:'finance',screens:[['매입등록','input'],['매출등록','input'],['정산현황','status']]}]},
  {name:'기준정보',icon:'▦',sections:[{name:'거래처기준',profile:'vendor',screens:[['거래처관리','input']]},{name:'품목기준',profile:'item',screens:[['강종·품목관리','input']]}]}
 ]},
 {cat:'유통·무역',name:'유통 · 재고 · 물류',icon:'📦',desc:'상품·구매·입고·재고·주문·출고·배송을 한 흐름으로 관리',modules:[
  {name:'상품관리',icon:'▦',sections:[{name:'상품기준',profile:'item',screens:[['상품등록','input'],['상품현황','status']]},{name:'거래처기준',profile:'vendor',screens:[['거래처관리','input']]}]},
  {name:'구매관리',icon:'🛒',sections:[{name:'구매·발주',profile:'purchase',screens:[['발주등록','input'],['발주현황','status']]}]},
  {name:'재고관리',icon:'📦',sections:[{name:'입출고·재고',profile:'material',screens:[['입고등록','input'],['출고등록','input'],['재고현황','status'],['재고대시보드','dash']]}]},
  {name:'주문관리',icon:'🧾',sections:[{name:'주문·판매',profile:'order',screens:[['주문등록','input'],['주문현황','status']]}]},
  {name:'배송관리',icon:'🚚',sections:[{name:'출고·배송',profile:'shipping',screens:[['출고등록','input'],['배송현황','status']]}]}
 ]},
 {cat:'건설·서비스',name:'건설 · 설비공사',icon:'🏗',desc:'프로젝트·견적계약·공정·자재·작업일보·안전·기성 정산 기본 구성',modules:[
  {name:'프로젝트관리',icon:'🏗',sections:[{name:'프로젝트',profile:'project',screens:[['프로젝트 등록','input'],['프로젝트 현황','status']]},{name:'견적·계약',profile:'order',screens:[['견적등록','input'],['계약현황','status']]}]},
  {name:'공정관리',icon:'📅',sections:[{name:'공정계획',profile:'project',screens:[['공정계획 등록','input'],['공정현황','status']]},{name:'작업일보',profile:'service',screens:[['작업일보 등록','input'],['작업현황','status']]}]},
  {name:'자재관리',icon:'📦',sections:[{name:'현장자재',profile:'material',screens:[['자재입고','input'],['자재사용','input'],['재고현황','status']]}]},
  {name:'안전관리',icon:'🦺',sections:[{name:'위험성평가',profile:'safety',screens:[['위험성평가 등록','input'],['개선조치','input'],['안전현황','status']]}]},
  {name:'정산관리',icon:'₩',sections:[{name:'기성·정산',profile:'finance',screens:[['기성등록','input'],['정산현황','status']]}]}
 ]},
 {cat:'건설·서비스',name:'시설관리 · 유지보수 서비스',icon:'🧑‍🔧',desc:'고객계약·작업요청·설비점검·보수이력·일정·비용 관리',modules:[
  {name:'고객관리',icon:'👥',sections:[{name:'고객·계약',profile:'vendor',screens:[['고객등록','input'],['계약현황','status']]}]},
  {name:'작업관리',icon:'🧑‍🔧',sections:[{name:'작업요청',profile:'service',screens:[['작업요청 등록','input'],['처리현황','status']]},{name:'정기점검',profile:'equipment',screens:[['점검등록','check'],['점검현황','status']]}]},
  {name:'자산·설비',icon:'🔧',sections:[{name:'설비대장',profile:'equipment',screens:[['설비등록','input'],['설비현황','status']]},{name:'보수이력',profile:'equipment',screens:[['보수이력 등록','input'],['고장이력','status']]}]},
  {name:'일정관리',icon:'📅',sections:[{name:'방문일정',profile:'service',screens:[['일정등록','input'],['일정현황','status']]}]},
  {name:'비용관리',icon:'₩',sections:[{name:'작업비용',profile:'finance',screens:[['비용등록','input'],['비용현황','status']]}]}
 ]},
 {cat:'식품·환경',name:'식품 제조 · HACCP',icon:'🍱',desc:'원료입고·배치생산·HACCP 점검·품질·재고·출하·추적성 기본 구성',modules:[
  {name:'원료관리',icon:'📦',sections:[{name:'원료입고',profile:'material',screens:[['원료입고 등록','input'],['원료재고 현황','status']]}]},
  {name:'생산관리',icon:'⚙',sections:[{name:'배치생산',profile:'production',screens:[['배치생산 등록','input'],['생산현황','status']]}]},
  {name:'품질·HACCP',icon:'🧪',sections:[{name:'품질검사',profile:'quality',screens:[['검사결과 등록','input'],['검사현황','status']]},{name:'HACCP점검',profile:'haccp',screens:[['CCP 점검등록','check'],['점검현황','status']]}]},
  {name:'재고·출하',icon:'🚚',sections:[{name:'제품재고',profile:'material',screens:[['제품입고','input'],['재고현황','status']]},{name:'출하관리',profile:'shipping',screens:[['출하등록','input'],['출하현황','status']]}]},
  {name:'추적관리',icon:'🔗',sections:[{name:'LOT추적',profile:'quality',screens:[['LOT 추적조회','status'],['회수이력 등록','input']]}]},
  {name:'위생관리',icon:'🧹',sections:[{name:'위생점검',profile:'haccp',screens:[['위생점검 등록','check'],['위생점검 현황','status']]}]}
 ]},
 {cat:'식품·환경',name:'ESG · 안전 · 환경 통합',icon:'🌱',desc:'위험성평가, 교육, 환경, 에너지, 폐기물, ESG 지표를 통합 관리',modules:[
  {name:'안전관리',icon:'🦺',sections:[{name:'위험성평가',profile:'safety',screens:[['위험성평가 등록','input'],['개선조치','input'],['위험성평가 현황','status']]},{name:'안전교육',profile:'common',screens:[['교육일지 등록','input'],['교육현황','status']]}]},
  {name:'환경관리',icon:'🌿',sections:[{name:'환경점검',profile:'esg',screens:[['환경점검 등록','check'],['환경현황','status']]},{name:'폐기물관리',profile:'esg',screens:[['폐기물 실적등록','input'],['폐기물 현황','status']]}]},
  {name:'에너지관리',icon:'⚡',sections:[{name:'에너지·탄소',profile:'esg',screens:[['에너지 실적등록','input'],['탄소배출 현황','status'],['ESG 대시보드','dash']]}]},
  {name:'법규·점검',icon:'📚',sections:[{name:'법규준수',profile:'common',screens:[['법규목록 등록','input'],['점검이력','input'],['준수현황','status']]}]}
 ]},
 {cat:'원본 시스템 (포크)',name:'IPTK 금형제작 MES (iptk_1)',icon:'🧩',repo:'iptk_1',desc:'iptk_1 저장소 메뉴 그대로 — 대메뉴 8 · 중분류 42 · 화면 113 (여러 메뉴에 중복된 화면은 첫 메뉴에만). 화면은 origin/iptk_1 포크 사본의 원본 HTML 을 그대로 사용. 테이블 72 · 참조 38 은 원본 DB 스키마(repo-schemas.js)로 함께 생성',modules:[
  {name:"영업관리",icon:"▣",sections:[{name:"수주",icon:"▣",screens:[["수주등록", "input", "sale_order_input.html"], ["수주현황", "status", "sale_order_status.html"], ["금형진척현황", "dash", "job_progress_board.html"], ["제번종합현황", "status", "job_overview.html"]]},{name:"제작계획",icon:"◴",screens:[["제작계획등록", "input", "sales_plan_input.html"], ["제작계획현황", "status", "sales_plan_status.html"]]},{name:"설계외주",icon:"✎",screens:[["외주설계발주등록", "input", "outsourced_design_order_input.html"], ["외주설계발주입고", "input", "outsourced_design_receipt_input.html"], ["외주설계발주현황", "status", "outsourced_design_order_status.html"]]},{name:"조립외주",icon:"◆",screens:[["SET외주제작등록", "input", "set_order_registration.html"], ["SET발주입고", "input", "set_order_receipt.html"], ["SET발주현황", "status", "set_order_status.html"]]},{name:"경비",icon:"▤",screens:[["경비등록", "input", "expense_registration.html"], ["경비현황", "status", "expense_status.html"]]}]},
  {name:"설계관리",icon:"▣",sections:[{name:"사내설계",icon:"▤",screens:[["설계계획등록", "input", "design_plan_input.html"], ["설계실적등록", "input", "design_result_input.html"], ["설계실적조회", "status", "design_result_inquiry.html?mode=design"]]},{name:"PARTLIST",icon:"▦",screens:[["PartList 등록(원재료)", "input", "partlist_material_input.html"], ["PartList 등록(구매품)", "input", "partlist_purchase_input.html"], ["PartList 현황", "status", "partlist_status.html"], ["PartList 복사", "input", "partlist_copy.html"]]}]},
  {name:"구매관리",icon:"▣",sections:[{name:"원재료",icon:"▣",screens:[["원재료 발주", "input", "material_order_input.html"], ["원재료 입고", "input", "material_receipt_input.html"], ["원재료 입고확정", "input", "material_receipt_confirmation.html"], ["원재료 발주현황", "status", "material_order_status.html"]]},{name:"구매품",icon:"◆",screens:[["구매품 발주", "input", "purchase_order_input.html"], ["구매품 입고", "input", "purchase_receipt_input.html"], ["구매품 입고확정", "input", "purchase_receipt_confirmation.html"], ["구매품 발주현황", "status", "purchase_order_status.html"]]},{name:"가공 · 가공",icon:"⚒",screens:[["가공계획등록", "input", "machining_plan_input.html"], ["공정이력카드", "input", "process_history_card.html"]]},{name:"가공 · 외주가공",icon:"⚒",screens:[["외주가공 발주", "input", "outsourcing_order_input.html"], ["외주가공 입고", "input", "outsourcing_receipt_input.html"], ["외주가공 입고확정", "input", "outsourcing_receipt_confirmation.html"], ["외주가공 QR스캔", "input", "mobile_scan.html"]]},{name:"가공 · 현황",icon:"⚒",screens:[["외주가공발주현황", "status", "outsourcing_order_status.html"], ["외주가공 진척현황", "dash", "outsourcing_pipeline_board.html"]]}]},
  {name:"조립관리",icon:"▣",sections:[{name:"사내조립",icon:"⚙",screens:[["조립실적등록", "input", "assembly_result_input.html"], ["조립실적현황", "status", "design_result_status.html?mode=assembly"], ["조립실적조회", "status", "design_result_inquiry.html?mode=assembly"]]},{name:"검사",icon:"⌕",screens:[["검사실적등록", "input", "inspection_result_input.html"]]}]},
  {name:"원가관리",icon:"▣",sections:[{name:"원가관리 · 제조원가",icon:"◴",screens:[["제조원가조회(실시간)", "status", "manufacturing_cost_inquiry.html"]]},{name:"매입매출현황",icon:"▥",screens:[["매입현황", "status", "purchase_status.html"], ["매출현황", "status", "sales_status.html"], ["재고조회", "status", "stock_inquiry.html"]]}]},
  {name:"SQ",icon:"▣",sections:[{name:"알림판 · 점검",icon:"🔔",screens:[["기한관리 알림판", "dash", "sq_alert_board.html"], ["입력누락 점검판", "dash", "mes_gap_board.html"]]},{name:"품질목표",icon:"◎",screens:[["품질목표 등록", "input", "quality_kpi_target_input.html"], ["품질목표 달성현황", "status", "quality_kpi_status.html"], ["품질목표 월별추이", "status", "quality_kpi_monthly.html"]]},{name:"심사 · 심사",icon:"☑",screens:[["심사등록", "input", "quality_audit_input.html"], ["지적사항등록", "input", "audit_finding_input.html"], ["심사현황", "status", "quality_audit_status.html"], ["지적사항 조치현황", "status", "audit_finding_status.html"]]},{name:"심사 · 고객 요구사항",icon:"☑",screens:[["고객 요구사항 등록", "input", "customer_requirement_input.html"], ["고객 요구사항 현황", "status", "customer_requirement_status.html"]]},{name:"부적합",icon:"⚠",screens:[["부적합등록", "input", "nonconformance_input.html"], ["시정조치등록", "input", "corrective_action_input.html"], ["부적합현황", "status", "nonconformance_status.html"]]},{name:"변경관리 · 4M변경",icon:"⇄",screens:[["4M변경신청", "input", "change_request_input.html"], ["4M변경현황", "status", "change_request_status.html"]]},{name:"계측기",icon:"⌗",screens:[["계측기대장", "status", "gauge_management.html"], ["교정이력등록", "input", "gauge_calibration_input.html"], ["계측기 교정현황", "status", "gauge_calibration_status.html"]]},{name:"문서/도면 · 도면",icon:"▤",screens:[["도면등록", "input", "drawing_management.html"], ["도면개정등록", "input", "drawing_revision_input.html"], ["도면개정현황", "status", "drawing_revision_status.html"]]},{name:"문서/도면 · 문서",icon:"▤",screens:[["문서관리대장", "status", "document_management.html"], ["문서 제·개정등록", "input", "document_revision_input.html"], ["문서 유효현황", "status", "document_status.html"]]},{name:"추적성",icon:"⌕",screens:[["소재LOT등록", "input", "material_lot_input.html"], ["성적서등록", "input", "certificate_input.html"], ["추적성조회", "status", "traceability_inquiry.html"]]},{name:"관리계획서",icon:"⊞",screens:[["관리계획서 등록", "input", "control_plan_input.html"], ["관리계획서 현황", "status", "control_plan_status.html"], ["기준공정 관리계획 커버리지", "status", "standard_process_control_status.html"]]},{name:"교육/자격 · 자격",icon:"⚇",screens:[["자격종류 등록", "input", "qualification_type_input.html"], ["사원 자격등록", "input", "employee_qualification_input.html"], ["자격 유효현황", "status", "qualification_status.html"]]},{name:"교육/자격 · 교육",icon:"⚇",screens:[["교육훈련 등록", "input", "training_input.html"], ["사원별 역량현황", "status", "employee_competency_status.html"]]},{name:"협력업체",icon:"⚑",screens:[["협력업체 평가등록", "input", "vendor_evaluation_input.html"], ["협력업체 인증서등록", "input", "vendor_certificate_input.html"], ["협력업체 등급현황", "status", "vendor_grade_status.html"], ["협력업체 인증현황", "status", "vendor_certificate_status.html"]]}]},
  {name:"기준정보",icon:"▣",sections:[{name:"생산/품질 · 공정관리",icon:"👥",screens:[["가공공정관리", "input", "machining_process_management.html"], ["가공 기준공정관리", "input", "machining_standard_process.html"]]},{name:"생산/품질 · 작업지시",icon:"👥",screens:[["작업지시 관리", "input", "work_order_input.html"]]},{name:"공통 · 사용자",icon:"⚙",screens:[["사용자정보", "input", "user_information.html"]]},{name:"공통 · 공통",icon:"⚙",screens:[["부품관리", "input", "part_management.html"], ["자재등록", "input", "material_management.html"], ["설비등록", "input", "equipment_registration.html"], ["업체관리", "input", "vendor_management.html"], ["사업부정보", "input", "business_division_info.html"], ["아이템 관리", "input", "item_management.html"], ["경비사유", "input", "expense_reason_registration.html"], ["금형타입관리", "input", "mold_type_management.html"], ["금형코드 매칭", "input", "mold_code_matching.html"], ["기계사양관리", "input", "machine_spec_management.html"]]},{name:"공통 · 검사",icon:"⚙",screens:[["검사구분", "input", "inspection_category.html"], ["검사항목", "input", "inspection_item_management.html"]]},{name:"공통 · 공지사항",icon:"⚙",screens:[["공지사항 등록", "input", "notice_registration.html"]]},{name:"공통 · 시스템",icon:"⚙",screens:[["DB 동기화", "input", "db_sync.html"], ["에러로그", "status", "error_log_inquiry.html"]]},{name:"공통 · 인사",icon:"⚙",screens:[["부서정보", "input", "department_registration.html"], ["직급정보", "input", "position_info.html"]]},{name:"공통 · 단가관리",icon:"⚙",screens:[["자재단가변동등록", "input", "material_price_change_registration.html"], ["자재단가변동현황", "status", "material_price_change_status.html"], ["공정단가변동등록", "input", "process_price_change_registration.html"], ["공정단가변동현황", "status", "process_price_change_status.html"]]}]},
  {name:"사용메뉴얼",icon:"▣",sections:[{name:"사용메뉴얼 · 사용메뉴얼",icon:"📖",screens:[["사용메뉴얼", "other", "user_manual.html"]]},{name:"사용메뉴얼 · 게시판",icon:"📖",screens:[["수정요청게시판", "dash", "mod_request_board.html"]]},{name:"사용메뉴얼 · 조직",icon:"📖",screens:[["조직도", "other", "org_chart.html"]]}]}
 ]}
];
