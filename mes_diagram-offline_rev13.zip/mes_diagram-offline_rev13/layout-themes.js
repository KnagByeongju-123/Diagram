/* ═══════════════ 레이아웃 (앱 프레임 index.html 의 뼈대) ═══════════════
   🎨 색상테마(SKIN) = 색·글꼴,  🧭 레이아웃 = 메뉴가 놓이는 자리 (PC용 / 모바일용).
   PC·모바일 둘 다 체크하면 병합 — 화면 폭 900px 이하에서 모바일 레이아웃으로 자동 전환.
   하나만 체크하면 그 레이아웃만 쓴다. 모바일 레이아웃 중 원본 계열(ESG 라이트·GI 현장 QR)은
   화면 CSS(큰 입력칸·둥근 카드·큰 버튼)까지 같이 바꾼다. */
const LAYOUT={
 top:{name:'IPTK 상단 메가메뉴 (기본)',desc:'iptk_1 index.html — 상단 대분류 + 마우스오버 메가메뉴 + 탭 + 경로표시',ico:'▤'},
 side:{name:'좌측 트리 사이드바',desc:'대분류 ▸ 중분류 ▸ 화면을 왼쪽 트리로. « 로 아이콘만 남기고 접기',ico:'▥'},
 topside:{name:'상단 대분류 + 좌측 트리 (ERP형)',desc:'상단에서 대분류를 고르면 왼쪽에 그 대분류의 중분류·화면 트리',ico:'▦'},
 rail:{name:'아이콘 레일 + 펼침 패널',desc:'왼쪽 좁은 아이콘 줄. 누르거나 올리면 중분류·화면 패널이 펼쳐짐',ico:'▮'}
};
const MLAYOUT={
 'm-drawer':{name:'기본 모바일 — 햄버거 드로어',desc:'☰ 로 왼쪽 메뉴 트리를 여닫음. 화면 모양은 색상테마 그대로',ico:'☰',nav:'drawer',skin:null},
 'm-tabbar':{name:'앱형 — 하단 탭바',desc:'아래 탭바에 대분류 아이콘, 누르면 중분류·화면 시트가 올라옴',ico:'▁',nav:'tabbar',skin:null},
 'esg-light':{name:'ESG 라이트 (모바일)',desc:'smtec 원본 — 햄버거 드로어 + 빨강 헤더 · 흰 카드 · 44px 버튼 화면',ico:'●',nav:'drawer',skin:'esg-light',dot:'#c62828'},
 'gi-mobile':{name:'GI 현장 QR (모바일)',desc:'Gyeongil 원본 — 하단 탭바 + 파랑 상단바 · 46px 입력칸 · 56px 버튼 화면',ico:'●',nav:'tabbar',skin:'gi-mobile',dot:'#3579b8'}
};
const MOB_SKINS=Object.values(MLAYOUT).map(x=>x.skin).filter(Boolean);
/* 예전 설계에서 모바일 스킨을 색상테마로 골라 둔 경우 → 모바일 레이아웃으로 옮긴다 */
function migMobileSkin(){
 if(typeof D==='undefined'||!D||!D.skin||!MOB_SKINS.includes(D.skin))return;
 D.mlayout=D.skin;D.useMobile=true;D.skin=undefined;
}
const layoutId=()=>{migMobileSkin();return LAYOUT[D.layout]?D.layout:'top'};
const mlayoutId=()=>(MLAYOUT[D.mlayout]?D.mlayout:'m-drawer');
const layUsePC=()=>D.usePC!==false;
const layUseMob=()=>!!D.useMobile;
function layCfg(){return{pc:layoutId(),nav:MLAYOUT[mlayoutId()].nav,usePC:layUsePC(),useMob:layUseMob()}}
function layModeText(){const p=layUsePC(),m=layUseMob();
 return p&&m?`병합 — PC: ${LAYOUT[layoutId()].name} / 모바일(900px 이하): ${MLAYOUT[mlayoutId()].name}`:p?`PC 전용 — ${LAYOUT[layoutId()].name}`:`모바일 전용 — ${MLAYOUT[mlayoutId()].name}`}
function layChanged(){
 save();try{$('layoutMenu').innerHTML=layoutMenuHtml()}catch(e){}
 $('stat').textContent=`🧭 레이아웃: ${layModeText()} — 미리보기와 [▶ 시스템 생성] 에 적용됩니다.`;
 if(typeof pvDlg!=='undefined'&&pvDlg.classList.contains('on')&&pvNode)previewNode(pvNode.id);
}
function setLayout(id){if(!LAYOUT[id])return;D.layout=id==='top'?undefined:id;D.usePC=undefined;layChanged()}
function setMLayout(id){if(!MLAYOUT[id])return;D.mlayout=id==='m-drawer'?undefined:id;D.useMobile=true;layChanged()}
function setLayUse(k,on){
 if(k==='pc')D.usePC=on?undefined:false;else D.useMobile=on?true:undefined;
 if(!layUsePC()&&!layUseMob()){if(k==='pc')D.useMobile=true;else D.usePC=undefined}
 layChanged();
}
function layoutMenuHtml(){
 migMobileSkin();
 const cur=layoutId(),mcur=mlayoutId(),p=layUsePC(),m=layUseMob();
 const row=(fn,k,v,on,dis)=>`<button onclick="${fn}('${k}')" title="${esc(v.desc)}" style="${on?'font-weight:700;background:#eef2f8;':''}${dis?'opacity:.5':''}"><span style="display:inline-block;width:18px;${v.dot?'color:'+v.dot:''}">${on?'✓':v.ico}</span><span style="display:flex;flex-direction:column;align-items:flex-start;gap:2px"><span>${esc(v.name)}</span><small style="color:#8a94a6;font-size:11px;font-weight:400;white-space:normal">${esc(v.desc)}</small></span></button>`;
 const head=(k,label,on)=>`<label style="display:flex;align-items:center;gap:8px;padding:8px 10px 4px;font-weight:700;cursor:pointer" onclick="event.stopPropagation()"><input type="checkbox" ${on?'checked':''} onchange="setLayUse('${k}',this.checked)" style="width:15px;height:15px">${label}</label>`;
 return head('pc','🖥 PC 레이아웃',p)+Object.entries(LAYOUT).map(([k,v])=>row('setLayout',k,v,p&&k===cur,!p)).join('')
  +'<hr>'+head('mob','📱 모바일 레이아웃',m)+Object.entries(MLAYOUT).map(([k,v])=>row('setMLayout',k,v,m&&k===mcur,!m)).join('')
  +`<div style="margin-top:6px;padding:8px 10px;font-size:11px;color:#4a5568;background:#f6f8fb;border-radius:6px;line-height:1.5">둘 다 체크 = <b>병합</b> (폭 900px 이하에서 모바일로 자동 전환)<br>하나만 체크 = 그 레이아웃만 사용<br><span style="color:#8a94a6">현재: ${esc(layModeText())}</span></div>`;
}
/* 모바일 레이아웃이 화면 CSS(mes_screen.css)·셸 색을 바꾸는 경우 — 병합이면 폭 900px 이하에서만 */
function layWrapMob(css){return !css?'':(layUsePC()?`\n@media(max-width:900px){\n${css}\n}\n`:`\n${css}\n`)}
function mobileSkinId(){return layUseMob()?MLAYOUT[mlayoutId()].skin:null}
function mobileScreenCss(){const s=mobileSkinId();return s&&SKIN[s]?`/* 📱 ${MLAYOUT[mlayoutId()].name} */`+layWrapMob(SKIN[s].css):''}
function mobileShellCss(){const s=mobileSkinId();return s&&SKIN[s]?layWrapMob(SKIN[s].shell):''}

/* ── 셸에 들어가는 CSS ── (색은 셸 변수만 써서 어느 🎨 색상테마와도 어울리게) */
const LAYOUT_CSS=`/* ── 레이아웃 (PC · 모바일) ── */
.lay-hb,.lay-aside,.lay-fly,.lay-dim,.lay-tabbar,.lay-sheet{display:none}
body.lay-side .app,body.lay-topside .app,body.lay-rail .app{grid-template-columns:var(--lay-w,244px) minmax(0,1fr)}
body.lay-rail,body.lay-side.lay-mini{--lay-w:74px}
body.lay-side .top-menu,body.lay-rail .top-menu{display:none}
body.lay-topside .top-menu .mega{display:none!important}
body.lay-side .lay-aside,body.lay-topside .lay-aside,body.lay-rail .lay-aside,body.mob-drawer .lay-aside{display:flex}
.lay-aside{flex-direction:column;min-height:0;overflow:hidden;background:var(--white);color:var(--ink);border-right:1px solid var(--line)}
.lay-scroll{flex:1;min-height:0;overflow:auto;padding:8px 0 16px}
.lay-foot{flex-shrink:0;border-top:1px solid var(--line);display:flex}
.lay-foot button{flex:1;height:34px;color:var(--ink-3);font-size:13px}
.lay-foot button:hover{background:var(--paper);color:var(--ink)}
.lay-title{display:flex;align-items:center;gap:8px;margin:2px 10px 8px;padding:10px 10px;border-radius:var(--r);background:var(--paper);font-weight:700;font-size:15px;text-align:left;width:calc(100% - 20px)}
.lay-title:hover{color:var(--blue)}
.lay-title small{margin-left:auto;font-weight:400;font-size:11px;color:var(--ink-3)}
.lay-hint{padding:4px 18px 8px;font-size:11.5px;color:var(--ink-3)}
.lay-mod{margin:0 0 2px}
.lay-mod-h,.lay-sec-h{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:8px 12px;white-space:nowrap}
.lay-mod-h{font-weight:700;font-size:14px;color:var(--ink)}
.lay-mod-h:hover,.lay-sec-h:hover{background:var(--paper)}
.lay-mod.on>.lay-mod-h{color:var(--blue)}
.lay-mod-h .ic{width:22px;text-align:center;flex-shrink:0}
.lay-mod-h .tx,.lay-sec-h .tx{overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0}
.car{width:12px;flex-shrink:0;color:var(--ink-3);font-size:10px;transition:transform .15s}
.open>.lay-mod-h .car,.open>.lay-sec-h .car{transform:rotate(90deg)}
.go{flex-shrink:0;width:22px;height:22px;border-radius:4px;display:grid;place-items:center;color:var(--ink-3);opacity:0}
.lay-mod-h:hover .go,.lay-sec-h:hover .go{opacity:1}
.go:hover{background:var(--line);color:var(--ink)}
.lay-mod-b{display:none;padding-bottom:4px}
.lay-mod.open>.lay-mod-b{display:block}
.lay-sec-h{font-size:13.5px;font-weight:600;color:var(--ink-2);padding-left:22px}
.lay-sec.on>.lay-sec-h{color:var(--ink)}
.lay-sec-h .ic{width:18px;text-align:center;flex-shrink:0;font-size:12px}
.lay-items{display:none;padding:2px 0 6px}
.lay-sec.open>.lay-items,.lay-items.flat{display:block}
.lay-grp{padding:6px 12px 2px 50px;font-size:11.5px;color:var(--ink-3)}
.lay-items a{display:flex;align-items:center;gap:6px;padding:6px 12px 6px 50px;font-size:13.5px;color:var(--ink-2);text-decoration:none;white-space:nowrap;border-left:3px solid transparent}
.lay-items a>span:first-child{overflow:hidden;text-overflow:ellipsis;min-width:0}
.lay-items.flat a{padding-left:32px}
.lay-items a:hover{background:var(--paper);color:var(--blue)}
.lay-items a.active{color:var(--blue);font-weight:700;background:var(--paper);border-left-color:var(--blue)}
.lay-items a .star{margin-left:auto;padding-left:10px;color:#c9d0da;opacity:0;font-size:11px}
.lay-items a:hover .star{opacity:1}.lay-items a .star.on{opacity:1;color:var(--amber)}
/* PC 레일 */
.lay-rb{display:flex;flex-direction:column;align-items:center;gap:3px;width:calc(100% - 10px);margin:2px 5px;padding:9px 2px;border-radius:var(--r);color:var(--ink-2);font-size:11px;line-height:1.2;text-align:center}
.lay-rb .ic{font-size:19px;line-height:1}
.lay-rb .tx{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 2px}
.lay-rb:hover{background:var(--paper);color:var(--ink)}
.lay-rb.on{background:var(--paper);color:var(--blue);font-weight:700;box-shadow:inset 3px 0 0 var(--blue)}
.lay-rb.hot{background:var(--paper)}
.lay-fly{position:fixed;z-index:140;width:270px;max-height:calc(100vh - var(--top-h) - 16px);overflow:auto;background:var(--white);color:var(--ink);border:1px solid var(--line);border-radius:0 var(--r) var(--r) 0;box-shadow:var(--shadow);padding:6px 0 10px}
.lay-fly.on{display:block}
.lay-fly .lay-title{margin-top:6px}
.lay-dim{position:fixed;inset:var(--top-h) 0 0 0;background:rgba(10,16,26,.38);z-index:110}
body.lay-open .lay-dim,body.sheet-open .lay-dim{display:block}
body.sheet-open .lay-dim{inset:0 0 60px 0;z-index:124}
/* ── 📱 모바일 공통 ── */
body.mob .app{grid-template-columns:minmax(0,1fr)}
body.mob .top-menu,body.mob .lay-fly{display:none!important}
body.mob .top{padding-right:6px}
body.mob .brand{padding:0 10px;border-right:0;gap:8px}
body.mob .brand .name small,body.mob .ubtn .txt,body.mob .search kbd,body.mob .icon-btn.txt span{display:none}
body.mob .search{flex:1;min-width:0;width:auto;margin-left:4px}
body.mob .top-actions{margin-left:6px}
body.mob .crumb{padding:6px 12px}body.mob .crumb .right{display:none}
body.mob .tab{font-size:13px}
body.mob .lay-mod-h{padding:12px 14px;font-size:15px}
body.mob .lay-sec-h{padding:11px 14px 11px 24px;font-size:14.5px}
body.mob .lay-items a{padding:11px 14px 11px 52px;font-size:15px}
body.mob .lay-items.flat a{padding-left:34px}
body.mob .lay-items a .star,body.mob .go{opacity:1}
body.mob .go{width:30px;height:30px}
/* 햄버거 드로어 */
body.mob-drawer .lay-hb{display:grid;place-items:center;width:44px;height:100%;flex-shrink:0;color:inherit;font-size:20px}
body.mob-drawer .lay-aside{position:fixed;left:0;top:var(--top-h);bottom:0;width:min(310px,86vw);z-index:120;transform:translateX(-104%);transition:transform .2s;box-shadow:var(--shadow)}
body.mob-drawer.lay-open .lay-aside{transform:none}
body.mob-drawer .lay-foot{display:none}
/* 하단 탭바 */
body.mob-tabbar .app{height:calc(100vh - 60px)}
body.mob-tabbar .status{display:none}
body.mob-tabbar .lay-tabbar{display:flex;position:fixed;left:0;right:0;bottom:0;height:60px;background:var(--white);border-top:1px solid var(--line);z-index:130;box-shadow:0 -2px 12px rgba(20,28,40,.08)}
.lay-tabbar button{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;font-size:11px;color:var(--ink-3);padding:0 2px}
.lay-tabbar button .ic{font-size:20px;line-height:1}
.lay-tabbar button .tx{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lay-tabbar button.on{color:var(--blue);font-weight:700}
.lay-tabbar button.hot{color:var(--ink);background:var(--paper)}
body.mob-tabbar .lay-sheet.on{display:block;position:fixed;left:0;right:0;bottom:60px;max-height:72vh;overflow:auto;background:var(--white);color:var(--ink);border-radius:16px 16px 0 0;box-shadow:0 -8px 30px rgba(10,16,26,.22);z-index:125;padding:6px 0 12px}
.lay-sheet .grab{width:42px;height:4px;border-radius:2px;background:var(--line);margin:4px auto 10px}
.lay-sheet .lay-title{font-size:16px}`;

/* ── 셸에 들어가는 스크립트 ── (셸의 전역 함수·변수를 그대로 사용 · cfg 는 생성 시 박아 넣음) */
function LAYOUT_RUNTIME(cfg){
 var PC=cfg.pc||'top';
 var KEY=C.STORAGE+'.layout',st={};try{st=JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){}
 st.open=st.open||{};
 function sv(){try{localStorage.setItem(KEY,JSON.stringify(st))}catch(e){}}
 var B=document.body,app=document.getElementById('app'),main=app.querySelector('.main'),top=app.querySelector('.top');
 var aside=el('aside','lay-aside');aside.id='layAside';app.insertBefore(aside,main);
 var fly=el('div','lay-fly');B.appendChild(fly);
 var dim=el('div','lay-dim');B.appendChild(dim);
 var bar=el('nav','lay-tabbar');B.appendChild(bar);
 var sheet=el('div','lay-sheet');B.appendChild(sheet);
 var hb=el('button','lay-hb','☰');hb.title='메뉴';top.insertBefore(hb,top.firstChild);
 hb.onclick=function(e){e.stopPropagation();B.classList.toggle('lay-open')};
 dim.onclick=function(){closeMobile();closeSheet()};
 function mob(){return !cfg.usePC||window.innerWidth<=900}
 function nav(){return cfg.useMob?cfg.nav:'drawer'}
 function applyCls(){
  ['lay-top','lay-side','lay-topside','lay-rail','lay-mini','mob','mob-drawer','mob-tabbar','lay-open','sheet-open'].forEach(function(c){B.classList.remove(c)});
  if(mob()){B.classList.add('mob');B.classList.add('mob-'+nav())}
  else{B.classList.add('lay-'+PC);if(PC==='side'&&st.mini)B.classList.add('lay-mini')}
 }
 function closeMobile(){B.classList.remove('lay-open')}
 function railMode(){return !mob()&&(PC==='rail'||(PC==='side'&&st.mini))}
 function cur(){return openTabs.get(activeId)||{}}
 function isOpen(k,def){return st.open[k]!=null?st.open[k]:def}
 function tog(k,box){var o=!box.classList.contains('open');box.classList.toggle('open',o);st.open[k]=o;sv()}
 function done(){closeMobile();hideFly(true);closeSheet()}
 function link(n){var a=menuLink(n);a.addEventListener('click',done);return a}
 function items(mod,sec,flat){
  var gs=groupsOf(mod,sec),b=el('div','lay-items'+(flat?' flat':''));
  gs.forEach(function(g){if(gs.length>1||g.name!==sec)b.appendChild(el('div','lay-grp',esc(g.name)));g.items.forEach(function(n){b.appendChild(link(n))})});
  return b;
 }
 function secBlock(mod,s,forceOpen){
  if(!groupsOf(mod,s.name).length)return null;
  if(s.name===mod)return items(mod,s.name,true);
  var p=cur(),on=p.mod===mod&&p.sec===s.name,k=mod+'/'+s.name;
  var box=el('div','lay-sec'+(on?' on':'')+(isOpen(k,on||!!forceOpen)?' open':''));
  var h=el('button','lay-sec-h','<span class="car">▶</span><span class="ic">'+(s.icon||'')+'</span><span class="tx">'+esc(s.name)+'</span><span class="go" title="중분류 홈">›</span>');
  h.onclick=function(e){if(e.target.closest('.go')){openSection(mod,s.name);done();return}tog(k,box)};
  box.appendChild(h);box.appendChild(items(mod,s.name));return box;
 }
 function secs(mod){return (APP[mod]&&APP[mod].secondary)||[]}
 function modBlock(mod){
  var on=activeModule===mod,box=el('div','lay-mod'+(on?' on':'')+(isOpen(mod,on)?' open':''));
  var h=el('button','lay-mod-h','<span class="car">'+(mod===HELP?'':'▶')+'</span><span class="ic">'+(MOD_ICON[mod]||(mod===HELP?'📖':'▣'))+'</span><span class="tx">'+esc(mod)+'</span>'+(mod===HELP?'':'<span class="go" title="대분류 홈">⌂</span>'));
  h.onclick=function(e){if(mod===HELP||e.target.closest('.go')){openModule(mod);done();return}tog(mod,box)};
  box.appendChild(h);
  if(mod!==HELP){var b=el('div','lay-mod-b');secs(mod).forEach(function(s){var x=secBlock(mod,s);if(x)b.appendChild(x)});box.appendChild(b)}
  return box;
 }
 function titleBtn(mod){
  var b=el('button','lay-title','<span>'+(MOD_ICON[mod]||'▣')+'</span><span>'+esc(mod)+'</span><small>대분류 홈 ›</small>');
  b.onclick=function(){openModule(mod);done()};return b;
 }
 function fillMod(box,mod){box.appendChild(titleBtn(mod));secs(mod).forEach(function(s){var x=secBlock(mod,s,true);if(x)box.appendChild(x)})}
 /* PC 레일 펼침 패널 */
 var flyMod='',flyT=0;
 function showFly(mod,btn){
  clearTimeout(flyT);if(mod===HELP){hideFly(true);return}
  flyMod=mod;fly.innerHTML='';fillMod(fly,mod);
  var r=btn.getBoundingClientRect(),ar=aside.getBoundingClientRect();
  fly.style.left=ar.right+'px';fly.classList.add('on');
  fly.style.top=Math.max(ar.top,Math.min(r.top,window.innerHeight-fly.offsetHeight-8))+'px';
  aside.querySelectorAll('.lay-rb').forEach(function(x){x.classList.toggle('hot',x===btn)});
 }
 function hideFly(now){clearTimeout(flyT);var f=function(){fly.classList.remove('on');flyMod='';aside.querySelectorAll('.lay-rb.hot').forEach(function(x){x.classList.remove('hot')})};if(now)f();else flyT=setTimeout(f,260)}
 fly.onmouseenter=function(){clearTimeout(flyT)};fly.onmouseleave=function(){hideFly()};
 document.addEventListener('click',function(e){if(!e.target.closest('.lay-fly')&&!e.target.closest('.lay-rb'))hideFly(true)});
 function renderRail(sc){
  visibleModules().forEach(function(mod){
   var b=el('button','lay-rb'+(activeModule===mod?' on':''),'<span class="ic">'+(MOD_ICON[mod]||(mod===HELP?'📖':'▣'))+'</span><span class="tx">'+esc(mod)+'</span>');
   b.title=mod;
   b.onclick=function(e){e.stopPropagation();if(mod===HELP){openModule(mod);return}if(flyMod===mod&&fly.classList.contains('on')){openModule(mod);hideFly(true)}else showFly(mod,b)};
   b.onmouseenter=function(){showFly(mod,b)};b.onmouseleave=function(){hideFly()};
   sc.appendChild(b);
  });
 }
 /* 모바일 하단 탭바 + 시트 */
 var sheetMod='';
 function closeSheet(){sheet.classList.remove('on');B.classList.remove('sheet-open');sheetMod='';bar.querySelectorAll('.hot').forEach(function(x){x.classList.remove('hot')})}
 function openSheet(key,btn){
  if(sheetMod===key&&sheet.classList.contains('on')){closeSheet();return}
  sheetMod=key;sheet.innerHTML='<div class="grab"></div>';
  if(key==='*')visibleModules().forEach(function(m){sheet.appendChild(modBlock(m))});else fillMod(sheet,key);
  sheet.classList.add('on');B.classList.add('sheet-open');
  bar.querySelectorAll('button').forEach(function(x){x.classList.toggle('hot',x===btn)});
 }
 function renderBar(){
  bar.innerHTML='';
  var mods=visibleModules().filter(function(m){return m!==HELP}),max=mods.length>4?3:4,shown=mods.slice(0,max);
  var p=cur(),h=el('button',p.home||activeId==='home'?'on':'','<span class="ic">⌂</span><span class="tx">홈</span>');
  h.onclick=function(){closeSheet();if(typeof activate==='function')activate('home')};bar.appendChild(h);
  shown.forEach(function(m){var b=el('button',activeModule===m&&!p.home?'on':'','<span class="ic">'+(MOD_ICON[m]||'▣')+'</span><span class="tx">'+esc(m)+'</span>');
   b.onclick=function(e){e.stopPropagation();openSheet(m,b)};bar.appendChild(b)});
  var more=el('button',shown.indexOf(activeModule)<0&&activeModule&&!p.home?'on':'','<span class="ic">☰</span><span class="tx">전체메뉴</span>');
  more.onclick=function(e){e.stopPropagation();openSheet('*',more)};bar.appendChild(more);
 }
 function render(){
  applyCls();
  var old=aside.querySelector('.lay-scroll'),y=old?old.scrollTop:0;
  aside.innerHTML='';var sc=el('div','lay-scroll');aside.appendChild(sc);
  if(mob()){
   if(nav()==='tabbar')renderBar();else visibleModules().forEach(function(x){sc.appendChild(modBlock(x))});
  }
  else if(railMode())renderRail(sc);
  else if(PC==='topside'){
   var m=activeModule&&activeModule!==HELP&&visibleModules().indexOf(activeModule)>=0?activeModule:'';
   if(m)fillMod(sc,m);
   else{sc.appendChild(el('div','lay-hint','상단에서 대분류를 고르면 여기에 중분류·화면이 나옵니다.'));visibleModules().forEach(function(x){sc.appendChild(modBlock(x))})}
  }
  else if(PC!=='top')visibleModules().forEach(function(x){sc.appendChild(modBlock(x))});
  if(!mob()&&PC==='side'){
   var f=el('div','lay-foot'),t=el('button','',st.mini?'»':'« 메뉴 접기');
   t.title=st.mini?'메뉴 펼치기':'아이콘만 남기고 접기';
   t.onclick=function(){st.mini=!st.mini;sv();hideFly(true);render()};
   f.appendChild(t);aside.appendChild(f);
  }
  sc.scrollTop=y;
 }
 var _bt=buildTop;buildTop=function(){_bt.apply(this,arguments);render()};
 var _tf=toggleFav;toggleFav=function(n){_tf(n);render()};
 var wm=mob();window.addEventListener('resize',function(){var m=mob();if(m!==wm){wm=m;closeMobile();closeSheet();hideFly(true);render()}});
 render();
}
function applyLayout(html){
 const cfg=layCfg();
 html=html.replace('</head>',`<style>/* 레이아웃: ${esc(layModeText())} */\n${LAYOUT_CSS}\n${mobileShellCss()}</style>\n</head>`);
 const js=`<script>/* 레이아웃 (PC·모바일) — 시스템 설계도 생성 */\n(${LAYOUT_RUNTIME.toString()})(${JSON.stringify(cfg)});<\/script>\n`;
 const i=html.lastIndexOf('</body>');
 return i<0?html+js:html.slice(0,i)+js+html.slice(i);
}
/* 생성 결과를 새 창에서 바로 실행해 보기 (단일 index.html 과 같은 내용) */
function previewSystem(){
 const html=buildSingleHtml();if(!html)return alert('먼저 [▶ 시스템 생성] 을 실행하세요.');
 const w=window.open(URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),'_blank');
 if(!w)alert('팝업이 막혔습니다. 브라우저에서 팝업을 허용해 주세요.');
}

/* ═══ 미리보기에 앱 프레임(레이아웃 + 색상테마) 씌우기 ═══
   셸 CSS 는 생성기 런타임(RT['index.html'])의 것, 메뉴 동작은 위 LAYOUT_RUNTIME 을 그대로 써서
   생성 결과와 같은 모양·동작으로 보인다. 메뉴를 누르면 해당 블록의 미리보기로 이동. */
let PV_FRAME=(()=>{try{return localStorage.getItem('sysdesign.pvFrame')!=='0'}catch(e){return true}})();
let PV_DEV=(()=>{try{return localStorage.getItem('sysdesign.pvDev')||'pc'}catch(e){return 'pc'}})();
function pvFrameToggle(){
 PV_FRAME=!PV_FRAME;try{localStorage.setItem('sysdesign.pvFrame',PV_FRAME?'1':'0')}catch(e){}
 pvFrameBtn();if(pvNode)previewNode(pvNode.id);
}
function pvDevToggle(){
 PV_DEV=PV_DEV==='mob'?'pc':'mob';try{localStorage.setItem('sysdesign.pvDev',PV_DEV)}catch(e){}
 pvFrameBtn();if(pvNode)previewNode(pvNode.id);
}
function pvFrameBtn(){
 const b=$('pv_frameBtn');if(b)b.textContent=PV_FRAME?'▣ 앱 프레임 ON':'▢ 앱 프레임 OFF';
 const d=$('pv_devBtn');if(d)d.textContent=PV_DEV==='mob'?'📱 모바일 폭':'🖥 PC 폭';
 const w=$('pv_wrap');if(w)w.classList.toggle('mob',PV_DEV==='mob');
}
let _shellCss=null;
function shellCssOnly(){
 if(_shellCss==null){const m=/<style>([\s\S]*?)<\/style>/.exec(RT['index.html']||'');_shellCss=m?m[1]:''}
 return _shellCss;
}
function pvCtxOf(n){
 if(n.type==='module')return{mod:n,sec:null};
 if(n.type==='section')return{mod:parentModuleOfSection(n),sec:n};
 const p=parentPathOfScreen(n);return{mod:p.module,sec:p.section};
}
function pvWrap(inner,n){
 if(!PV_FRAME)return inner;
 const L=layoutId(),ctx=pvCtxOf(n);
 const appName=($('sysName')&&$('sysName').value.trim())||'SAMPLE MES';
 const sortY=a=>a.slice().sort((p,q)=>p.y-q.y||p.x-q.x);
 /* 셸과 같은 메뉴 데이터 + 이름 → 블록 id */
 const APP={},MODULES=[],ICON={},ID={mod:{},sec:{},scr:{}};
 for(const m of sortY(D.nodes.filter(x=>x.type==='module'))){
  MODULES.push(m.name);ICON[m.name]=m.meta.icon||'▣';ID.mod[m.name]=m.id;
  const secondary=[],menus={};
  for(const s of containsKidsOf(m.id,'section')){const it=containsKidsOf(s.id,'screen');secondary.push({name:s.name,icon:s.meta.icon||'▣'});menus[s.name]=[{name:s.name,items:it.map(x=>x.name)}];ID.sec[m.name+'/'+s.name]=s.id;it.forEach(x=>ID.scr[x.name]=ID.scr[x.name]||x.id)}
  const dir=containsKidsOf(m.id,'screen');if(dir.length){secondary.push({name:m.name,icon:m.meta.icon||'▣'});menus[m.name]=[{name:m.name,items:dir.map(x=>x.name)}];dir.forEach(x=>ID.scr[x.name]=ID.scr[x.name]||x.id)}
  APP[m.name]={secondary,menus};
 }
 MODULES.push('사용메뉴얼');APP['사용메뉴얼']={secondary:[],menus:{}};
 const curTab={mod:ctx.mod&&ctx.mod.name,sec:ctx.sec?ctx.sec.name:(n.type==='screen'&&ctx.mod?ctx.mod.name:undefined)};
 const I=x=>esc(x.meta&&x.meta.icon||'▣');
 const topMenu=MODULES.map(mn=>{const m=APP[mn],mid=ID.mod[mn];
  const cols=(m.secondary||[]).map(s=>{const it=(m.menus[s.name]||[])[0]?.items||[];const sid=s.name===mn?mid:ID.sec[mn+'/'+s.name];
   return `<div class="col"><button class="sec-head" data-id="${sid||''}"><span>${esc(s.icon||'')} ${esc(s.name)}</span><small>${s.name===mn?'대분류 홈':'중분류 열기'} ›</small></button>${it.map(x=>`<a href="#" data-id="${ID.scr[x]}" class="${ID.scr[x]===n.id?'active':''}"><span>${esc(x)}</span><span class="star">★</span></a>`).join('')}</div>`}).join('');
  return `<li class="${ctx.mod&&ctx.mod.name===mn?'on':''}"><button data-id="${mid||''}">${esc(mn)}</button>${cols?`<div class="mega">${cols}</div>`:''}</li>`}).join('');
 const crumb=`<span>${esc(appName)}</span>${ctx.mod&&n.type!=='module'?`<span>›</span><span>${esc(ctx.mod.name)}</span>`:''}${ctx.sec&&n.type==='screen'?`<span>›</span><span>${esc(ctx.sec.name)}</span>`:''}<span>›</span><b>${esc(n.name)}</b><span class="right"><span>${n.type==='module'?'대분류 홈':n.type==='section'?'중분류':esc(n.meta.file||'')}</span></span>`;
 const innerDoc=inner.replace(/<\/head>/i,'<style>.pv-crumb{display:none!important}</style></head>');
 const skin=SKIN[skinId()]||{};
 const stub=`<script>
var APP=${JSON.stringify(APP)},MODULES=${JSON.stringify(MODULES)},HELP='사용메뉴얼',MOD_ICON=${JSON.stringify(ICON)},ID=${JSON.stringify(ID)},C={STORAGE:'sysdesign.pv'};
var activeModule=${JSON.stringify(ctx.mod?ctx.mod.name:'')},activeId='cur',CURNAME=${JSON.stringify(n.type==='screen'?n.name:'')};
var openTabs=new Map([['cur',${JSON.stringify(curTab)}]]);
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function go(id){if(id)parent.previewNode(id)}
function visibleModules(){return MODULES}
function groupsOf(m,s){return (APP[m]&&APP[m].menus&&APP[m].menus[s])||[]}
function menuLink(nm){var a=el('a',nm===CURNAME?'active':'','<span>'+esc(nm)+'</span><span class="star">★</span>');a.href='#';a.onclick=function(e){e.preventDefault();go(ID.scr[nm])};return a}
function openModule(m){go(ID.mod[m])}
function openSection(m,s){go(ID.sec[m+'/'+s])}
function buildTop(){} function toggleFav(){} function activate(){}
window.previewNode=function(id){parent.previewNode(id)};
window.addEventListener('message',function(e){if(e.source!==parent)try{parent.postMessage(e.data,'*')}catch(_){}});
document.addEventListener('click',function(e){var g=e.target.closest('.top [data-id]');if(g){e.preventDefault();go(g.getAttribute('data-id'))}},true);
<\/script>`;
 return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>${shellCssOnly()}</style>${skin.shell?`<style>${skin.shell}</style>`:''}<style>${LAYOUT_CSS}
${mobileShellCss()}
.stage iframe{visibility:visible;pointer-events:auto}.top-menu>li>button{cursor:pointer}</style></head>
<body><div class="app" id="app">
 <header class="top">
  <div class="brand"><div class="mark">${esc((appName[0]||'M').toUpperCase())}</div><div class="name"><span class="home-lbl">⌂ 홈</span><small>${esc(appName)}</small></div></div>
  <ul class="top-menu">${topMenu}</ul>
  <div class="search"><span class="ico">⌕</span><input placeholder="메뉴 검색" autocomplete="off"><kbd>Ctrl K</kbd></div>
  <div class="top-actions"><div class="dd"><button class="icon-btn" title="즐겨찾기">★</button></div><div class="dd"><button class="ubtn"><span class="avatar">미</span><span class="txt"><b>미리보기</b><span>master</span></span></button></div></div>
 </header>
 <section class="main">
  <div class="tabs"><div class="tabs-scroll"><div class="tab"><span>📌 홈</span></div><div class="tab active"><span>${esc(n.name)}</span><span class="x">×</span></div></div><div class="tabs-act"><button>‹</button><button>›</button><button>×</button></div></div>
  <div class="crumb">${crumb}</div>
  <div class="stage"><iframe class="on" id="pvInner" srcdoc="${innerDoc.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe></div>
  <div class="status"><span><span class="dot"></span>미리보기 — ${esc(layModeText())} · 🎨 ${esc(skin.name||'')}</span><span class="r"></span></div>
 </section>
</div>${stub}<script>(${LAYOUT_RUNTIME.toString()})(${JSON.stringify(layCfg())});<\/script></body></html>`;
}
