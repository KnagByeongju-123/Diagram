# MES origin updater. ASCII-only script for Windows PowerShell 5.1.
# Git and Python are not required.
param(
    [string[]]$Repos = @("smtec_main2", "GF", "mm_main", "Gyeongil", "TaeJin_ESG", "stock_ledger")
)

$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Owner = "KnagByeongju-123"
$AllowedRepos = @("smtec_main2", "GF", "mm_main", "Gyeongil", "TaeJin_ESG", "ESG_Smart_Factory_Mold", "iptk_1", "stock_ledger")
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Origin = Join-Path $Root "origin"
$Manifest = Join-Path $Origin "manifest.js"

function Get-IsoNow {
    return [DateTimeOffset]::Now.ToString("yyyy-MM-ddTHH:mm:sszzz")
}

function Load-ManifestRepos {
    $result = [ordered]@{}
    if (-not (Test-Path -LiteralPath $Manifest)) {
        return $result
    }

    try {
        $txt = [IO.File]::ReadAllText($Manifest, [Text.Encoding]::UTF8)
        $start = $txt.IndexOf('{')
        $end = $txt.LastIndexOf('}')
        if ($start -lt 0 -or $end -le $start) {
            return $result
        }

        $obj = ($txt.Substring($start, $end - $start + 1) | ConvertFrom-Json)
        if ($obj.repos) {
            foreach ($p in $obj.repos.PSObject.Properties) {
                $result[$p.Name] = $p.Value
            }
        }
    }
    catch {
        Write-Host "  Warning: manifest.js could not be read. A new manifest will be written." -ForegroundColor Yellow
    }

    return $result
}

function Get-RepoInfo([string]$Repo, $Previous) {
    $branch = "main"
    $sha = "archive-main"
    $date = $null
    $headers = @{
        "User-Agent" = "MES-Origin-Sync"
        "Accept" = "application/vnd.github+json"
    }

    try {
        $repoApi = "https://api.github.com/repos/$Owner/$Repo"
        $repoInfo = Invoke-RestMethod -Uri $repoApi -Headers $headers -Method Get
        if ($repoInfo.default_branch) {
            $branch = [string]$repoInfo.default_branch
        }
    }
    catch {
        if ($Previous -and $Previous.branch) {
            $branch = [string]$Previous.branch
        }
        Write-Host "  Warning: default branch lookup failed. Using branch: $branch" -ForegroundColor DarkYellow
    }

    $sha = "archive-$branch"
    try {
        $commitApi = "https://api.github.com/repos/$Owner/$Repo/commits/$branch"
        $commitInfo = Invoke-RestMethod -Uri $commitApi -Headers $headers -Method Get
        if ($commitInfo.sha) {
            $sha = [string]$commitInfo.sha
        }
        if ($commitInfo.commit.committer.date) {
            $date = [string]$commitInfo.commit.committer.date
        }
    }
    catch {
        if ($Previous) {
            if ($Previous.commit) {
                $sha = [string]$Previous.commit
            }
            if ($Previous.commit_date) {
                $date = [string]$Previous.commit_date
            }
        }
        Write-Host "  Warning: commit metadata lookup failed. Files will still be updated." -ForegroundColor DarkYellow
    }

    return [pscustomobject]@{
        branch = $branch
        sha = $sha
        date = $date
    }
}

function Build-OriginBundle {
    $bundlePath = Join-Path $Origin "bundle.js"
    $allowedExt = @(".html", ".js", ".sql", ".txt", ".json", ".ts", ".css")
    $bundle = [ordered]@{}

    $files = Get-ChildItem -LiteralPath $Origin -File -Recurse -Force | Sort-Object FullName
    foreach ($f in $files) {
        if ($f.FullName -eq $bundlePath) {
            continue
        }
        if (($f.Name -ne "manifest.js") -and ($allowedExt -notcontains $f.Extension.ToLowerInvariant())) {
            continue
        }

        $rel = $f.FullName.Substring($Origin.Length).TrimStart([char[]]"\/") -replace "\\", "/"
        try {
            $bundle[$rel] = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
        }
        catch {
            Write-Host "  Warning: skipped unreadable text file: $rel" -ForegroundColor DarkYellow
        }
    }

    $json = $bundle | ConvertTo-Json -Depth 4 -Compress
    $content = "/* Offline origin bundle - generated automatically. */`r`nwindow.ORIGIN_BUNDLE=$json;`r`n"
    [IO.File]::WriteAllText($bundlePath, $content, (New-Object Text.UTF8Encoding($false)))
    return $bundle.Count
}

function Sync-Repo([string]$Repo, $Previous) {
    $repoInfo = Get-RepoInfo $Repo $Previous
    $branch = [string]$repoInfo.branch

    $tempRoot = Join-Path ([IO.Path]::GetTempPath()) ("mes_origin_" + [Guid]::NewGuid().ToString("N"))
    $zipPath = Join-Path $tempRoot "$Repo.zip"
    $extractPath = Join-Path $tempRoot "extract"
    $stagePath = Join-Path $Origin ("." + $Repo + ".new")
    $destPath = Join-Path $Origin $Repo

    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $extractPath -Force | Out-Null

    try {
        $url = "https://codeload.github.com/$Owner/$Repo/zip/refs/heads/$branch"
        Write-Host "  Download: $url" -ForegroundColor DarkGray
        Invoke-WebRequest -Uri $url -OutFile $zipPath -UseBasicParsing
        Expand-Archive -LiteralPath $zipPath -DestinationPath $extractPath -Force

        $sourceRoot = Get-ChildItem -LiteralPath $extractPath -Directory | Select-Object -First 1
        if (-not $sourceRoot) {
            throw "Repository folder was not found in the downloaded ZIP."
        }

        if (Test-Path -LiteralPath $stagePath) {
            Remove-Item -LiteralPath $stagePath -Recurse -Force
        }
        New-Item -ItemType Directory -Path $stagePath -Force | Out-Null

        foreach ($item in Get-ChildItem -LiteralPath $sourceRoot.FullName -Force) {
            if ($item.Name -eq ".git" -or $item.Name -eq ".github") {
                continue
            }
            Copy-Item -LiteralPath $item.FullName -Destination $stagePath -Recurse -Force
        }

        $files = @(Get-ChildItem -LiteralPath $stagePath -File -Recurse -Force)
        $bytes = 0L
        foreach ($f in $files) {
            $bytes += $f.Length
        }

        if (Test-Path -LiteralPath $destPath) {
            Remove-Item -LiteralPath $destPath -Recurse -Force
        }
        Rename-Item -LiteralPath $stagePath -NewName $Repo

        return [ordered]@{
            upstream = "https://github.com/$Owner/$Repo"
            raw = "https://raw.githubusercontent.com/$Owner/$Repo/$branch/"
            branch = $branch
            commit = [string]$repoInfo.sha
            commit_date = $repoInfo.date
            synced_at = Get-IsoNow
            files = $files.Count
            bytes = $bytes
        }
    }
    finally {
        if (Test-Path -LiteralPath $stagePath) {
            Remove-Item -LiteralPath $stagePath -Recurse -Force -ErrorAction SilentlyContinue
        }
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

$invalid = @($Repos | Where-Object { $_ -notin $AllowedRepos })
if ($invalid.Count -gt 0) {
    Write-Host "Unknown repository: $($invalid -join ', ')" -ForegroundColor Red
    exit 2
}

New-Item -ItemType Directory -Path $Origin -Force | Out-Null
$manifestRepos = Load-ManifestRepos
$failed = @()

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " MES Origin Update - No Git / No Python" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

foreach ($repo in $Repos) {
    Write-Host "[$repo] Updating..." -ForegroundColor White
    try {
        $prev = $null
        if ($manifestRepos.Contains($repo)) {
            $prev = $manifestRepos[$repo]
        }

        $m = Sync-Repo $repo $prev
        $manifestRepos[$repo] = $m

        $short = [string]$m.commit
        if ($short.Length -gt 7) {
            $short = $short.Substring(0, 7)
        }
        $mb = [Math]::Round(([double]$m.bytes / 1MB), 1)
        Write-Host ("  OK  {0,-20} {1}  {2} files  {3} MB" -f $repo, $short, $m.files, $mb) -ForegroundColor Green
    }
    catch {
        $failed += $repo
        Write-Host "  FAIL $repo : $($_.Exception.Message)" -ForegroundColor Red
    }
    Write-Host ""
}

$data = [ordered]@{
    generated_at = Get-IsoNow
    repos = $manifestRepos
}
$json = $data | ConvertTo-Json -Depth 8
$content = "/* Generated by sync_origin_nogit.ps1. Do not edit manually. */`r`nwindow.ORIGIN_MANIFEST=$json;`r`n"
[IO.File]::WriteAllText($Manifest, $content, (New-Object Text.UTF8Encoding($false)))
Write-Host "Manifest updated: origin\manifest.js" -ForegroundColor DarkGray

Write-Host "Building offline bundle..." -ForegroundColor DarkGray
$bundleCount = Build-OriginBundle
Write-Host "Bundle updated: origin\bundle.js ($bundleCount files)" -ForegroundColor DarkGray
Write-Host ""

if ($failed.Count -gt 0) {
    Write-Host "Update failed for: $($failed -join ', ')" -ForegroundColor Red
    exit 1
}

Write-Host "All 5 origin systems were updated successfully." -ForegroundColor Green
exit 0
