/* GitHub Offline Repository Store v1
   - Public GitHub repository snapshots are stored in IndexedDB.
   - All repository files (text + binary) are kept for offline reuse.
   - Current snapshots can be embedded into / restored from .mesproj ZIP files. */
(function(){
'use strict';

const DB_NAME='sysdesign.githubOffline.v1';
const DB_VER=1;
const STORE_REPOS='repos';
const STORE_FILES='files';
const API_HEADERS={'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'};
const MAX_WORKERS=6;

function idbReq(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('IndexedDB request failed'));});}
function txDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('IndexedDB transaction failed'));tx.onabort=()=>reject(tx.error||new Error('IndexedDB transaction aborted'));});}
function openDb(){return new Promise((resolve,reject)=>{
 const req=indexedDB.open(DB_NAME,DB_VER);
 req.onupgradeneeded=()=>{
  const db=req.result;
  if(!db.objectStoreNames.contains(STORE_REPOS))db.createObjectStore(STORE_REPOS,{keyPath:'key'});
  if(!db.objectStoreNames.contains(STORE_FILES)){
   const s=db.createObjectStore(STORE_FILES,{keyPath:'id'});
   s.createIndex('repoKey','repoKey',{unique:false});
   s.createIndex('repoSnapshot','repoSnapshot',{unique:false});
  }
 };
 req.onsuccess=()=>resolve(req.result);
 req.onerror=()=>reject(req.error||new Error('IndexedDB open failed'));
});}
function cleanPath(p){return String(p||'').replace(/\\/g,'/').replace(/^\/+/, '').split('/').filter(x=>x&&x!=='.'&&x!=='..').join('/');}
function encPath(p){return cleanPath(p).split('/').map(encodeURIComponent).join('/');}
function mimeOf(path){const e=(String(path).match(/\.([^.\/]+)$/)||[])[1]?.toLowerCase()||'';return ({html:'text/html',htm:'text/html',js:'text/javascript',mjs:'text/javascript',css:'text/css',json:'application/json',txt:'text/plain',md:'text/markdown',sql:'text/plain',csv:'text/csv',xml:'application/xml',svg:'image/svg+xml',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',ico:'image/x-icon',woff:'font/woff',woff2:'font/woff2',ttf:'font/ttf',pdf:'application/pdf'}[e]||'application/octet-stream');}
function isTextPath(path){return /\.(?:html?|js|mjs|cjs|css|json|txt|md|sql|csv|xml|svg|ts|tsx|jsx|yml|yaml|ini|conf|map)$/i.test(String(path||''));}
function fmtBytes(n){n=Number(n)||0;if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(1)+' MB';}
function snapId(sha){return String(sha||'snapshot').slice(0,16)+'_'+Date.now().toString(36);}

async function getMeta(key){const db=await openDb();try{return await idbReq(db.transaction(STORE_REPOS,'readonly').objectStore(STORE_REPOS).get(key));}finally{db.close();}}
async function listMeta(){const db=await openDb();try{return await idbReq(db.transaction(STORE_REPOS,'readonly').objectStore(STORE_REPOS).getAll());}finally{db.close();}}
async function putMeta(meta){const db=await openDb();try{const tx=db.transaction(STORE_REPOS,'readwrite');tx.objectStore(STORE_REPOS).put(meta);await txDone(tx);}finally{db.close();}}
async function putFileDb(db,rec){const tx=db.transaction(STORE_FILES,'readwrite');tx.objectStore(STORE_FILES).put(rec);await txDone(tx);}
async function putFile(rec){const db=await openDb();try{await putFileDb(db,rec);}finally{db.close();}}
async function getFile(key,path){const meta=await getMeta(key);if(!meta||!meta.snapshot)return undefined;const p=cleanPath(path),id=`${key}|${meta.snapshot}|${p}`;const db=await openDb();try{return await idbReq(db.transaction(STORE_FILES,'readonly').objectStore(STORE_FILES).get(id));}finally{db.close();}}
async function deleteSnapshot(key,snapshot){if(!snapshot)return;const db=await openDb();try{
 const tx=db.transaction(STORE_FILES,'readwrite'),idx=tx.objectStore(STORE_FILES).index('repoSnapshot'),range=IDBKeyRange.only(`${key}|${snapshot}`);
 await new Promise((resolve,reject)=>{const req=idx.openCursor(range);req.onsuccess=()=>{const c=req.result;if(!c){resolve();return}c.delete();c.continue();};req.onerror=()=>reject(req.error||new Error('snapshot delete failed'));});
 await txDone(tx);
}finally{db.close();}}
async function deleteRepo(key){const meta=await getMeta(key);if(meta?.snapshot)await deleteSnapshot(key,meta.snapshot);const db=await openDb();try{const tx=db.transaction(STORE_REPOS,'readwrite');tx.objectStore(STORE_REPOS).delete(key);await txDone(tx);}finally{db.close();}}

async function fetchJson(url){const r=await fetch(url,{headers:API_HEADERS,cache:'no-store'});if(!r.ok){let m='HTTP '+r.status;try{const j=await r.json();if(j?.message)m+=' · '+j.message}catch(e){}throw new Error(m)}return r.json();}
async function repoSnapshot(info,onProgress){
 const owner=String(info.owner||info.own||'').trim(),repo=String(info.repo||'').trim();if(!owner||!repo)throw new Error('GitHub owner/repository 정보가 없습니다.');
 const key=String(info.key||repo).trim()||repo,baseApi=`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
 onProgress?.({phase:'meta',message:'저장소 정보 확인 중…'});
 const ri=await fetchJson(baseApi),branch=String(info.branch||ri.default_branch||'main');
 onProgress?.({phase:'meta',message:`${branch} 브랜치 최신 커밋 확인 중…`});
 const ci=await fetchJson(`${baseApi}/commits/${encodeURIComponent(branch)}`),sha=String(ci.sha||''),treeSha=String(ci.commit?.tree?.sha||'');if(!sha||!treeSha)throw new Error('GitHub 커밋 정보를 확인하지 못했습니다.');
 const old=await getMeta(key);
 const tj=await fetchJson(`${baseApi}/git/trees/${treeSha}?recursive=1`);if(tj.truncated)throw new Error('저장소 파일 목록이 너무 커 GitHub API에서 일부가 잘렸습니다.');
 const blobs=(tj.tree||[]).filter(x=>x.type==='blob'&&x.path).map(x=>({path:cleanPath(x.path),size:Number(x.size)||0,sha:x.sha})).filter(x=>x.path);
 if(!blobs.length)throw new Error('저장소에 파일이 없습니다.');
 const html=blobs.map(x=>x.path).filter(p=>/\.html?$/i.test(p)&&!/(^|\/)(node_modules|vendor)(\/|$)/i.test(p));
 if(old&&old.commit===sha&&old.files===blobs.length&&old.snapshot){onProgress?.({phase:'done',done:blobs.length,total:blobs.length,message:'이미 최신 오프라인 사본입니다.'});return {...old,unchanged:true};}
 const snapshot=snapId(sha),repoSnapshotKey=`${key}|${snapshot}`;let next=0,done=0,bytes=0,failed=null;const stageDb=await openDb();
 onProgress?.({phase:'download',done:0,total:blobs.length,message:`파일 0/${blobs.length} 저장 중…`});
 async function worker(){
  while(true){if(failed)throw failed;const i=next++;if(i>=blobs.length)return;const f=blobs[i];try{
   const raw=`https://raw.githubusercontent.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/${encodeURIComponent(sha)}/${encPath(f.path)}`;
   const r=await fetch(raw,{cache:'no-store'});if(!r.ok)throw new Error(`HTTP ${r.status}`);const data=await r.arrayBuffer();bytes+=data.byteLength;
   await putFileDb(stageDb,{id:`${key}|${snapshot}|${f.path}`,repoKey:key,repoSnapshot:repoSnapshotKey,snapshot,path:f.path,size:data.byteLength,mime:r.headers.get('content-type')||mimeOf(f.path),text:isTextPath(f.path),data});
   done++;onProgress?.({phase:'download',done,total:blobs.length,path:f.path,bytes,message:`파일 ${done}/${blobs.length} 저장 중… ${f.path}`});
  }catch(e){failed=new Error(`${f.path} 저장 실패: ${e.message||e}`);throw failed;}}
 }
 try{await Promise.all(Array.from({length:Math.min(MAX_WORKERS,blobs.length)},()=>worker()));}
 catch(e){stageDb.close();await deleteSnapshot(key,snapshot);throw e;}
 stageDb.close();
 const meta={key,owner,repo,branch,github:`https://github.com/${owner}/${repo}`,raw:`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/`,commit:sha,commit_date:ci.commit?.committer?.date||ci.commit?.author?.date||null,synced_at:new Date().toISOString(),snapshot,files:blobs.length,bytes,paths:blobs.map(x=>x.path),html};
 await putMeta(meta);if(old?.snapshot&&old.snapshot!==snapshot)await deleteSnapshot(key,old.snapshot);
 onProgress?.({phase:'done',done:blobs.length,total:blobs.length,bytes,message:`오프라인 저장 완료 · ${blobs.length}개 · ${fmtBytes(bytes)}`});return meta;
}

async function getText(key,path){const rec=await getFile(key,path);if(!rec)return undefined;try{return new TextDecoder('utf-8').decode(rec.data);}catch(e){return undefined;}}
async function getBytes(key,path){const rec=await getFile(key,path);return rec?.data;}

async function exportToZip(zip,keys){if(!zip)return 0;const all=await listMeta(),want=keys&&keys.length?new Set(keys):null,metas=all.filter(m=>!want||want.has(m.key));if(!metas.length)return 0;
 zip.file('github_offline/repos.json',JSON.stringify(metas,null,2));let count=0;
 for(const m of metas){for(const p of m.paths||[]){const rec=await getFile(m.key,p);if(!rec)continue;zip.file(`github_offline/files/${encodeURIComponent(m.key)}/${p}`,rec.data,{binary:true});count++;}}
 return count;
}
async function importFromZip(zip){if(!zip)return{repos:0,files:0};const mf=zip.file('github_offline/repos.json');if(!mf)return{repos:0,files:0};const metas=JSON.parse(await mf.async('string'));if(!Array.isArray(metas))return{repos:0,files:0};let files=0,repos=0;
 for(const src of metas){if(!src?.key||!src?.snapshot)continue;const meta={...src},old=await getMeta(meta.key);for(const p of meta.paths||[]){const zf=zip.file(`github_offline/files/${encodeURIComponent(meta.key)}/${p}`);if(!zf)continue;const data=await zf.async('arraybuffer');await putFile({id:`${meta.key}|${meta.snapshot}|${cleanPath(p)}`,repoKey:meta.key,repoSnapshot:`${meta.key}|${meta.snapshot}`,snapshot:meta.snapshot,path:cleanPath(p),size:data.byteLength,mime:mimeOf(p),text:isTextPath(p),data});files++;}
 await putMeta(meta);if(old?.snapshot&&old.snapshot!==meta.snapshot)await deleteSnapshot(meta.key,old.snapshot);repos++;}
 return{repos,files};
}

window.ghOfflineGetMeta=getMeta;
window.ghOfflineListMeta=listMeta;
window.ghOfflineGetText=getText;
window.ghOfflineGetBytes=getBytes;
window.ghOfflineDeleteRepo=deleteRepo;
window.ghOfflineSyncRepo=repoSnapshot;
window.ghOfflineExportToZip=exportToZip;
window.ghOfflineImportFromZip=importFromZip;
window.ghOfflineFmtBytes=fmtBytes;
})();
