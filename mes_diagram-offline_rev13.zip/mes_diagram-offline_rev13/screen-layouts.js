/* ═══════════════ 화면 배치(화면 레이아웃) 이름 · 그림 ═══════════════
   🧭 레이아웃 = 시스템 전체 앱 프레임,  화면 배치 = 화면 한 장의 안쪽 구성.
   화면 블록 제목줄 오른쪽에 배치명을 표시하고, 블록 패널에서 그림을 보고 고른다.
   배치는 화면 종류(meta.kind)로 정해진다 — 등록 화면에 1:N 참조 테이블이 있으면 헤더+명세로 자동 전환. */
const SCREEN_LAYOUT={
 input:{kind:'등록',name:'입력폼+목록',desc:'위 입력폼 · 아래 목록 그리드. 목록 행을 누르면 폼으로 불러와 수정',
  svg:'<rect x="4" y="4" width="56" height="15" rx="2" class="a"/><path d="M8 9h14M26 9h14M8 14h14M26 14h14" class="l"/><rect x="4" y="22" width="56" height="18" rx="2" class="b"/><path d="M4 27h56M4 32h56M4 36h56" class="l"/>'},
 detail:{kind:'등록',name:'헤더+명세',desc:'위 헤더폼(1) · 아래 명세 그리드(N). 테이블이 1:N 참조로 이어진 등록 화면이면 자동',
  svg:'<rect x="4" y="4" width="56" height="11" rx="2" class="a"/><path d="M8 9.5h12M24 9.5h12M40 9.5h12" class="l"/><rect x="4" y="18" width="56" height="22" rx="2" class="b"/><path d="M4 23h56M4 28h56M4 33h56M18 18v22M34 18v22" class="l"/>'},
 status:{kind:'현황',name:'조회+상세',desc:'위 조회조건 · 전체 폭 그리드 · 행 선택 시 상세. 저장 없이 조회만',
  svg:'<rect x="4" y="4" width="56" height="7" rx="2" class="a"/><rect x="48" y="5.5" width="9" height="4" rx="1" class="k"/><rect x="4" y="14" width="56" height="26" rx="2" class="b"/><path d="M4 19h56M4 24h56M4 29h56M4 34h56" class="l"/>'},
 check:{kind:'체크시트',name:'점검시트',desc:'헤더(일자·설비·점검자) · 점검항목별 OK/NG 토글 · NG수·판정 합계',
  svg:'<rect x="4" y="4" width="56" height="8" rx="2" class="a"/><g class="l"><path d="M8 17h28M8 24h28M8 31h28M8 38h28"/></g><g class="k"><rect x="40" y="15" width="8" height="4" rx="1"/><rect x="40" y="22" width="8" height="4" rx="1"/><rect x="40" y="29" width="8" height="4" rx="1"/></g><rect x="50" y="29" width="8" height="4" rx="1" class="n"/><rect x="50" y="36" width="8" height="4" rx="1" class="n"/><rect x="40" y="36" width="8" height="4" rx="1" class="k"/>'},
 board:{kind:'보드',name:'공정보드',desc:'제번·부품(행) × 공정(열) 매트릭스. 칸을 눌러 업체·요청·발주·입고 처리',
  svg:'<rect x="4" y="4" width="56" height="36" rx="2" class="b"/><path d="M4 11h56M4 18h56M4 25h56M4 32h56M18 4v36M29 4v36M40 4v36M51 4v36" class="l"/><rect x="19" y="12" width="9" height="5" class="k"/><rect x="30" y="12" width="9" height="5" class="k"/><rect x="19" y="19" width="9" height="5" class="k"/><rect x="30" y="26" width="9" height="5" class="n"/>'},
 perm:{kind:'권한관리',name:'사용자+권한트리',desc:'왼쪽 사용자 목록 · 오른쪽 메뉴 트리별 조회·저장·수정·삭제 체크',
  svg:'<rect x="4" y="4" width="18" height="36" rx="2" class="a"/><path d="M7 10h12M7 16h12M7 22h12M7 28h12" class="l"/><rect x="25" y="4" width="35" height="36" rx="2" class="b"/><path d="M28 10h10M31 16h10M31 22h10M28 28h10M31 34h10" class="l"/><g class="k"><rect x="46" y="14" width="3" height="3"/><rect x="51" y="14" width="3" height="3"/><rect x="46" y="20" width="3" height="3"/><rect x="51" y="32" width="3" height="3"/></g>'},
 paste:{kind:'붙여넣기',name:'엑셀 붙여넣기',desc:'엑셀에서 복사한 표를 Ctrl+V → 열 자동 인식 → 검토 그리드 → 일괄 저장',
  svg:'<rect x="4" y="4" width="56" height="9" rx="2" class="a" stroke-dasharray="2 1.5"/><path d="M26 8.5h12" class="l"/><rect x="4" y="16" width="56" height="24" rx="2" class="b"/><path d="M4 21h56M4 26h56M4 31h56M4 36h56M20 16v24M36 16v24" class="l"/>'},
 dash:{kind:'대시보드',name:'KPI 대시보드',desc:'KPI 타일 · 그룹 칩 · 상태별 목록 · 알림 · 자동갱신',
  svg:'<rect x="4" y="4" width="17" height="10" rx="2" class="k"/><rect x="23.5" y="4" width="17" height="10" rx="2" class="a"/><rect x="43" y="4" width="17" height="10" rx="2" class="n"/><rect x="4" y="17" width="10" height="4" rx="2" class="a"/><rect x="16" y="17" width="10" height="4" rx="2" class="a"/><rect x="4" y="24" width="56" height="16" rx="2" class="b"/><path d="M4 29h56M4 34h56" class="l"/>'},
 other:{kind:'기타',name:'자유 화면',desc:'빈 화면 — 직접 만들거나 원본 파일을 연결',
  svg:'<rect x="4" y="4" width="56" height="36" rx="2" class="b" stroke-dasharray="3 2"/>'},
 origin:{kind:'원본',name:'원본 화면',desc:'원본 저장소의 HTML 을 그대로 사용 (배치는 원본을 따름)',
  svg:'<rect x="4" y="4" width="56" height="36" rx="2" class="b"/><path d="M26 16l6-4 6 4v10l-6 4-6-4z" class="k"/>'}
};
/* 화면 블록의 배치 키 */
function screenLayoutKey(n){
 if(!n||n.type!=='screen')return null;
 if(n.meta.origin&&typeof originUrl==='function'&&originUrl(n))return 'origin';
 const k=SCREEN_LAYOUT[n.meta.kind]?n.meta.kind:'input';
 if(k==='input'&&typeof detailOf==='function'&&detailOf(n))return 'detail';
 return k;
}
function screenLayoutShort(n){const k=screenLayoutKey(n);return k?SCREEN_LAYOUT[k].name:''}
function screenLayoutSvg(k,w){
 return `<svg class="sl-svg" viewBox="0 0 64 44" width="${w||64}" height="${Math.round((w||64)*44/64)}">${SCREEN_LAYOUT[k].svg}</svg>`;
}
/* 블록 패널 — 배치 그림 고르기 (기존 화면 종류 select 와 연동) */
function screenLayoutPicker(n){
 const cur=screenLayoutKey(n),md=typeof detailOf==='function'&&n.meta.kind==='input'&&detailOf(n);
 const keys=['input','status','check','board','perm','paste','dash','other'];
 return `<div class="f"><label>화면 배치 <span style="font-weight:400;color:#8a94a6">— 지금: <b style="color:#2e7d5b">${esc(SCREEN_LAYOUT[cur].kind)} · ${esc(SCREEN_LAYOUT[cur].name)}</b></span></label>
 <div class="sl-grid">${keys.map(k=>{const on=(k===n.meta.kind)||(k==='input'&&!SCREEN_LAYOUT[n.meta.kind]);const kk=(k==='input'&&md)?'detail':k;
  return `<button type="button" class="sl-tile${on?' on':''}" title="${esc(SCREEN_LAYOUT[kk].desc)}" onclick="setScreenLayout('${n.id}','${k}')">${screenLayoutSvg(kk,58)}<b>${esc(SCREEN_LAYOUT[kk].kind)}</b><small>${esc(SCREEN_LAYOUT[kk].name)}</small></button>`}).join('')}</div>
 <div class="sl-note">${cur==='origin'?'📎 원본 파일을 쓰는 화면입니다 — 배치는 원본을 따릅니다. 원본 연결을 끄면 아래 배치로 생성됩니다.':esc(SCREEN_LAYOUT[cur].desc)}${!md&&n.meta.kind==='input'?' · 사용 테이블이 1:N 참조로 이어져 있으면 헤더+명세로 자동 전환':''}</div></div>`;
}
function setScreenLayout(id,k){
 const n=N(id);if(!n||n.type!=='screen')return;
 n.meta.kind=k;save();renderPanel();render();
 $('stat').textContent=`${n.name} — 화면 배치: ${SCREEN_LAYOUT[screenLayoutKey(n)].kind} · ${SCREEN_LAYOUT[screenLayoutKey(n)].name}`;
 if(typeof pvDlg!=='undefined'&&pvDlg.classList.contains('on')&&pvNode&&pvNode.id===id)previewScreen(id);
}
