@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MES Origin Update - No Git or Python Required

echo.
echo ============================================================
echo   MES Origin Update - NO Git / NO Python required
echo ============================================================
echo.
echo   Repositories:
echo     1. smtec_main2
echo     2. GF
echo     3. mm_main
echo     4. Gyeongil
echo     5. TaeJin_ESG
echo.
echo   Internet connection is required only while updating.
echo.

where powershell.exe >nul 2>&1
if errorlevel 1 goto :NO_POWERSHELL

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0sync_origin_nogit.ps1"
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" goto :SUCCESS

echo ============================================================
echo   Update failed. Error code: %RC%
echo ============================================================
echo   Check the FAIL message above.
echo.
pause
exit /b %RC%

:SUCCESS
echo ============================================================
echo   Update completed successfully.
echo ============================================================
echo   Open index.html to use the updated origin systems.
echo.
pause
exit /b 0

:NO_POWERSHELL
echo ============================================================
echo   Windows PowerShell was not found.
echo ============================================================
echo   Windows 10/11 normally includes Windows PowerShell.
echo.
pause
exit /b 12
