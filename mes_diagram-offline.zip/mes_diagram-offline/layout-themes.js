/* ═══════════════ 메인 레이아웃 테마 (앱 프레임 index.html 의 뼈대) ═══════════════
   🎨 테마(SKIN) = 색·글꼴,  🧭 레이아웃(LAYOUT) = 메뉴가 놓이는 자리.
   둘은 따로 고른다. 레이아웃은 생성되는 index.html 셸에 CSS + 스크립트를 덧붙여
   같은 메뉴 데이터(APP·MODULES·pageRegistry)와 같은 탭·권한·즐겨찾기 로직을 그대로 쓴다. */
const LAYOUT={
 top:{name:'IPTK 상단 메가메뉴 (기본)',desc:'iptk_1 index.html — 상단 대분류 + 마우스오버 메가메뉴 + 탭 + 경로표시',ico:'▤'},
 side:{name:'좌측 트리 사이드바',desc:'대분류 ▸ 중분류 ▸ 화면을 왼쪽 트리로. « 로 아이콘만 남기고 접기',ico:'▥'},
 topside:{name:'상단 대분류 + 좌측 트리 (ERP형)',desc:'상단에서 대분류를 고르면 왼쪽에 그 대분류의 중분류·화면 트리',ico:'▦'},
 rail:{name:'아이콘 레일 + 펼침 패널',desc:'왼쪽 좁은 아이콘 줄. 누르거나 올리면 중분류·화면 패널이 펼쳐짐',ico:'▮'}
};
const layoutId=()=>(LAYOUT[D.layout]?D.layout:'top');
function setLayout(id){
 if(!LAYOUT[id])return;
 D.layout=id==='top'?undefined:id;save();
 try{$('layoutMenu').innerHTML=layoutMenuHtml()}catch(e){}
 $('stat').textContent=`메인 레이아웃: ${LAYOUT[id].name} — 미리보기(블록 더블클릭)와 [▶ 시스템 생성] 의 index.html 에 적용됩니다.`;
 if(typeof pvDlg!=='undefined'&&pvDlg.classList.contains('on')&&pvNode)previewNode(pvNode.id);
}
function layoutMenuHtml(){
 const cur=layoutId();
 return '<div class="hd" style="padding:6px 10px;font-size:11px;color:#8a94a6">메인 레이아웃 (앱 프레임)</div>'+
  Object.entries(LAYOUT).map(([k,v])=>`<button onclick="setLayout('${k}')" title="${esc(v.desc)}" style="${k===cur?'font-weight:700;background:#eef2f8':''}"><span style="display:inline-block;width:18px">${k===cur?'✓':v.ico}</span><span style="display:flex;flex-direction:column;align-items:flex-start;gap:2px"><span>${esc(v.name)}</span><small style="color:#8a94a6;font-size:11px;font-weight:400;white-space:normal">${esc(v.desc)}</small></span></button>`).join('');
}

/* ── 셸에 들어가는 CSS ── (색은 셸 변수만 써서 어느 🎨 테마와도 어울리게) */
const LAYOUT_CSS=`/* ── 메인 레이아웃 테마 ── */
.lay-hb,.lay-aside,.lay-fly,.lay-dim{display:none}
body.lay-side .app,body.lay-topside .app,body.lay-rail .app{grid-template-columns:var(--lay-w,244px) minmax(0,1fr)}
body.lay-rail,body.lay-side.lay-mini{--lay-w:74px}
body.lay-side .top-menu,body.lay-rail .top-menu{display:none}
body.lay-topside .top-menu .mega{display:none!important}
.lay-aside{display:flex;flex-direction:column;min-height:0;overflow:hidden;background:var(--white);color:var(--ink);border-right:1px solid var(--line)}
.lay-scroll{flex:1;min-height:0;overflow:auto;padding:8px 0 16px}
.lay-foot{flex-shrink:0;border-top:1px solid var(--line);display:flex}
.lay-foot button{flex:1;height:34px;color:var(--ink-3);font-size:13px}
.lay-foot button:hover{background:var(--paper);color:var(--ink)}
.lay-title{display:flex;align-items:center;gap:8px;margin:2px 10px 8px;padding:10px 10px;border-radius:var(--r);background:var(--paper);font-weight:700;font-size:15px;text-align:left;width:calc(100% - 20px)}
.lay-title:hover{color:var(--blue)}
.lay-title small{margin-left:auto;font-weight:400;font-size:11px;color:var(--ink-3)}
.lay-hint{padding:4px 18px 8px;font-size:11.5px;color:var(--ink-3)}
.lay-mod{margin:0 0 2px}
.lay-mod-h,.lay-sec-h{display:flex;align-items:center;gap:8px;width:100%;text-align:left;padding:8px 12px 8px 12px;white-space:nowrap}
.lay-mod-h{font-weight:700;font-size:14px;color:var(--ink)}
.lay-mod-h:hover,.lay-sec-h:hover{background:var(--paper)}
.lay-mod.on>.lay-mod-h{color:var(--blue)}
.lay-mod-h .ic{width:22px;text-align:center;flex-shrink:0}
.lay-mod-h .tx,.lay-sec-h .tx{overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0}
.car{width:12px;flex-shrink:0;color:var(--ink-3);font-size:10px;transition:transform .15s}
.open>.lay-mod-h .car,.open>.lay-sec-h .car{transform:rotate(90deg)}
.go{flex-shrink:0;width:22px;height:22px;border-radius:4px;display:grid;place-items:center;color:var(--ink-3);opacity:0}
.lay-mod-h:hover .go,.lay-sec-h:hover .go{opacity:1}
.go:hover{background:var(--line);color:var(--ink)}
.lay-mod-b{display:none;padding-bottom:4px}
.lay-mod.open>.lay-mod-b{display:block}
.lay-sec-h{font-size:13.5px;font-weight:600;color:var(--ink-2);padding-left:22px}
.lay-sec.on>.lay-sec-h{color:var(--ink)}
.lay-sec-h .ic{width:18px;text-align:center;flex-shrink:0;font-size:12px}
.lay-items{display:none;padding:2px 0 6px}
.lay-sec.open>.lay-items,.lay-items.flat{display:block}
.lay-grp{padding:6px 12px 2px 50px;font-size:11.5px;color:var(--ink-3)}
.lay-items a{display:flex;align-items:center;gap:6px;padding:6px 12px 6px 50px;font-size:13.5px;color:var(--ink-2);text-decoration:none;white-space:nowrap;border-left:3px solid transparent}
.lay-items a>span:first-child{overflow:hidden;text-overflow:ellipsis;min-width:0}
.lay-items.flat a{padding-left:32px}
.lay-items a:hover{background:var(--paper);color:var(--blue)}
.lay-items a.active{color:var(--blue);font-weight:700;background:var(--paper);border-left-color:var(--blue)}
.lay-items a .star{margin-left:auto;padding-left:10px;color:#c9d0da;opacity:0;font-size:11px}
.lay-items a:hover .star{opacity:1}.lay-items a .star.on{opacity:1;color:var(--amber)}
/* 레일 */
.lay-rb{display:flex;flex-direction:column;align-items:center;gap:3px;width:calc(100% - 10px);margin:2px 5px;padding:9px 2px;border-radius:var(--r);color:var(--ink-2);font-size:11px;line-height:1.2;text-align:center}
.lay-rb .ic{font-size:19px;line-height:1}
.lay-rb .tx{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0 2px}
.lay-rb:hover{background:var(--paper);color:var(--ink)}
.lay-rb.on{background:var(--paper);color:var(--blue);font-weight:700;box-shadow:inset 3px 0 0 var(--blue)}
.lay-rb.hot{background:var(--paper)}
.lay-fly{position:fixed;z-index:140;width:270px;max-height:calc(100vh - var(--top-h) - 16px);overflow:auto;background:var(--white);color:var(--ink);border:1px solid var(--line);border-radius:0 var(--r) var(--r) 0;box-shadow:var(--shadow);padding:6px 0 10px}
.lay-fly.on{display:block}
.lay-fly .lay-title{margin-top:6px}
.lay-dim{position:fixed;inset:var(--top-h) 0 0 0;background:rgba(10,16,26,.38);z-index:110}
/* 모바일: 사이드는 햄버거로 여닫기 */
@media(max-width:900px){
 body.lay-side .app,body.lay-topside .app,body.lay-rail .app{grid-template-columns:minmax(0,1fr)}
 body.lay-side .lay-hb,body.lay-topside .lay-hb,body.lay-rail .lay-hb{display:grid;place-items:center;width:44px;height:100%;flex-shrink:0;color:inherit;font-size:19px}
 .lay-aside{position:fixed;left:0;top:var(--top-h);bottom:0;width:min(300px,86vw);z-index:120;transform:translateX(-104%);transition:transform .2s;box-shadow:var(--shadow)}
 body.lay-open .lay-aside{transform:none}
 body.lay-open .lay-dim{display:block}
 .lay-foot{display:none}
 .lay-fly{display:none!important}
 .lay-items a .star{opacity:1}
}`;

/* ── 셸에 들어가는 스크립트 ── (셸의 전역 함수·변수를 그대로 사용) */
function LAYOUT_RUNTIME(){
 var L=(window.APP_CONFIG&&APP_CONFIG.SHELL_LAYOUT)||'top';if(L==='top')return;
 var KEY=C.STORAGE+'.layout',st={};try{st=JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){}
 st.open=st.open||{};
 function sv(){try{localStorage.setItem(KEY,JSON.stringify(st))}catch(e){}}
 var B=document.body,app=document.getElementById('app'),main=app.querySelector('.main'),top=app.querySelector('.top');
 B.classList.add('lay-'+L);if(L==='side'&&st.mini)B.classList.add('lay-mini');
 var aside=el('aside','lay-aside');aside.id='layAside';app.insertBefore(aside,main);
 var fly=el('div','lay-fly');fly.id='layFly';B.appendChild(fly);
 var dim=el('div','lay-dim');B.appendChild(dim);
 var hb=el('button','lay-hb','☰');hb.title='메뉴';top.insertBefore(hb,top.firstChild);
 hb.onclick=function(e){e.stopPropagation();B.classList.toggle('lay-open')};
 dim.onclick=closeMobile;
 function mobile(){return window.innerWidth<=900}
 function closeMobile(){B.classList.remove('lay-open')}
 function railMode(){return !mobile()&&(L==='rail'||(L==='side'&&B.classList.contains('lay-mini')))}
 function cur(){return openTabs.get(activeId)||{}}
 function isOpen(k,def){return st.open[k]!=null?st.open[k]:def}
 function tog(k,box){var o=!box.classList.contains('open');box.classList.toggle('open',o);st.open[k]=o;sv()}
 function link(n){var a=menuLink(n);a.addEventListener('click',function(){closeMobile();hideFly(true)});return a}
 function items(mod,sec,flat){
  var gs=groupsOf(mod,sec),b=el('div','lay-items'+(flat?' flat':''));
  gs.forEach(function(g){if(gs.length>1||g.name!==sec)b.appendChild(el('div','lay-grp',esc(g.name)));g.items.forEach(function(n){b.appendChild(link(n))})});
  return b;
 }
 function secBlock(mod,s){
  if(!groupsOf(mod,s.name).length)return null;
  if(s.name===mod)return items(mod,s.name,true);          /* 대분류 바로 아래 화면 */
  var p=cur(),on=p.mod===mod&&p.sec===s.name,k=mod+'/'+s.name;
  var box=el('div','lay-sec'+(on?' on':'')+(isOpen(k,on)?' open':''));
  var h=el('button','lay-sec-h','<span class="car">▶</span><span class="ic">'+(s.icon||'')+'</span><span class="tx">'+esc(s.name)+'</span><span class="go" title="중분류 홈">›</span>');
  h.onclick=function(e){if(e.target.closest('.go')){openSection(mod,s.name);closeMobile();hideFly(true);return}tog(k,box)};
  box.appendChild(h);box.appendChild(items(mod,s.name));return box;
 }
 function secs(mod){return (APP[mod]&&APP[mod].secondary)||[]}
 function modBlock(mod){
  var on=activeModule===mod,box=el('div','lay-mod'+(on?' on':'')+(isOpen(mod,on)?' open':''));
  var h=el('button','lay-mod-h','<span class="car">'+(mod===HELP?'':'▶')+'</span><span class="ic">'+(MOD_ICON[mod]||'▣')+'</span><span class="tx">'+esc(mod)+'</span>'+(mod===HELP?'':'<span class="go" title="대분류 홈">⌂</span>'));
  h.onclick=function(e){if(mod===HELP||e.target.closest('.go')){openModule(mod);closeMobile();return}tog(mod,box)};
  box.appendChild(h);
  if(mod!==HELP){var b=el('div','lay-mod-b');secs(mod).forEach(function(s){var x=secBlock(mod,s);if(x)b.appendChild(x)});box.appendChild(b)}
  return box;
 }
 function titleBtn(mod){
  var b=el('button','lay-title','<span>'+(MOD_ICON[mod]||'▣')+'</span><span>'+esc(mod)+'</span><small>대분류 홈 ›</small>');
  b.onclick=function(){openModule(mod);closeMobile();hideFly(true)};return b;
 }
 /* 레일 + 펼침 패널 */
 var flyMod='',flyT=0;
 function showFly(mod,btn){
  clearTimeout(flyT);if(mod===HELP){hideFly(true);return}
  flyMod=mod;fly.innerHTML='';fly.appendChild(titleBtn(mod));
  secs(mod).forEach(function(s){var x=secBlock(mod,s);if(x){if(x.classList.contains('lay-sec'))x.classList.add('open');fly.appendChild(x)}});
  var r=btn.getBoundingClientRect(),ar=aside.getBoundingClientRect();
  fly.style.left=(ar.right)+'px';fly.classList.add('on');
  var h=fly.offsetHeight,y=Math.max(ar.top,Math.min(r.top,window.innerHeight-h-8));fly.style.top=y+'px';
  aside.querySelectorAll('.lay-rb').forEach(function(x){x.classList.toggle('hot',x===btn)});
 }
 function hideFly(now){clearTimeout(flyT);var f=function(){fly.classList.remove('on');flyMod='';aside.querySelectorAll('.lay-rb.hot').forEach(function(x){x.classList.remove('hot')})};if(now)f();else flyT=setTimeout(f,260)}
 fly.onmouseenter=function(){clearTimeout(flyT)};fly.onmouseleave=function(){hideFly()};
 document.addEventListener('click',function(e){if(!e.target.closest('.lay-fly')&&!e.target.closest('.lay-rb'))hideFly(true)});
 function renderRail(sc){
  visibleModules().forEach(function(mod){
   var b=el('button','lay-rb'+(activeModule===mod?' on':''),'<span class="ic">'+(MOD_ICON[mod]||'▣')+'</span><span class="tx">'+esc(mod)+'</span>');
   b.title=mod;
   b.onclick=function(e){e.stopPropagation();if(mod===HELP){openModule(mod);return}if(flyMod===mod&&fly.classList.contains('on'))openModule(mod),hideFly(true);else showFly(mod,b)};
   b.onmouseenter=function(){showFly(mod,b)};b.onmouseleave=function(){hideFly()};
   sc.appendChild(b);
  });
 }
 function render(){
  var old=aside.querySelector('.lay-scroll'),y=old?old.scrollTop:0;
  aside.innerHTML='';var sc=el('div','lay-scroll');aside.appendChild(sc);
  if(railMode())renderRail(sc);
  else if(L==='topside'&&!mobile()){
   var m=activeModule&&activeModule!==HELP&&visibleModules().indexOf(activeModule)>=0?activeModule:'';
   if(m){sc.appendChild(titleBtn(m));secs(m).forEach(function(s){var x=secBlock(m,s);if(x){if(x.classList.contains('lay-sec')&&st.open[m+'/'+s.name]==null)x.classList.add('open');sc.appendChild(x)}})}
   else{sc.appendChild(el('div','lay-hint','상단에서 대분류를 고르면 여기에 중분류·화면이 나옵니다.'));visibleModules().forEach(function(x){sc.appendChild(modBlock(x))})}
  }
  else visibleModules().forEach(function(x){sc.appendChild(modBlock(x))});
  if(L==='side'){
   var f=el('div','lay-foot'),t=el('button','',B.classList.contains('lay-mini')?'»':'« 메뉴 접기');
   t.title=B.classList.contains('lay-mini')?'메뉴 펼치기':'아이콘만 남기고 접기';
   t.onclick=function(){B.classList.toggle('lay-mini');st.mini=B.classList.contains('lay-mini');sv();hideFly(true);render()};
   f.appendChild(t);aside.appendChild(f);
  }
  sc.scrollTop=y;
  if(flyMod&&fly.classList.contains('on')){var bb=[].slice.call(aside.querySelectorAll('.lay-rb')).find(function(x){return x.title===flyMod});if(bb)showFly(flyMod,bb)}
 }
 var _bt=buildTop;buildTop=function(){_bt.apply(this,arguments);render()};
 var _tf=toggleFav;toggleFav=function(n){_tf(n);render()};
 var wm=mobile();window.addEventListener('resize',function(){var m=mobile();if(m!==wm){wm=m;closeMobile();hideFly(true);render()}});
 render();
}
function applyLayout(html,id){
 id=LAYOUT[id]?id:'top';if(id==='top')return html;
 html=html.replace('</head>',`<style>/* 메인 레이아웃: ${LAYOUT[id].name} */\n${LAYOUT_CSS}</style>\n</head>`);
 const js=`<script>/* 메인 레이아웃 테마 — 시스템 설계도 생성 */\n(${LAYOUT_RUNTIME.toString()})();<\/script>\n`;
 const i=html.lastIndexOf('</body>');
 return i<0?html+js:html.slice(0,i)+js+html.slice(i);
}
/* 생성 결과를 새 창에서 바로 실행해 보기 (단일 index.html 과 같은 내용) */
function previewSystem(){
 const html=buildSingleHtml();if(!html)return alert('먼저 [▶ 시스템 생성] 을 실행하세요.');
 const w=window.open(URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),'_blank');
 if(!w)alert('팝업이 막혔습니다. 브라우저에서 팝업을 허용해 주세요.');
}

/* ═══ 미리보기에 앱 프레임(레이아웃+테마) 씌우기 ═══
   대메뉴·중분류·화면 미리보기를 실제 생성될 index.html 셸 모양(선택한 🧭 레이아웃 + 🎨 테마) 안에 넣어 보여준다.
   셸 CSS 는 생성기 런타임(RT['index.html'])의 것을 그대로 쓰므로 생성 결과와 모양이 같다. */
let PV_FRAME=(()=>{try{return localStorage.getItem('sysdesign.pvFrame')!=='0'}catch(e){return true}})();
function pvFrameToggle(){
 PV_FRAME=!PV_FRAME;try{localStorage.setItem('sysdesign.pvFrame',PV_FRAME?'1':'0')}catch(e){}
 pvFrameBtn();if(pvNode)previewNode(pvNode.id);
}
function pvFrameBtn(){const b=$('pv_frameBtn');if(b)b.textContent=PV_FRAME?'▣ 앱 프레임 ON':'▢ 앱 프레임 OFF'}
let _shellCss=null;
function shellCssOnly(){
 if(_shellCss==null){const m=/<style>([\s\S]*?)<\/style>/.exec(RT['index.html']||'');_shellCss=m?m[1]:''}
 return _shellCss;
}
function pvCtxOf(n){
 if(n.type==='module')return{mod:n,sec:null};
 if(n.type==='section')return{mod:parentModuleOfSection(n),sec:n};
 const p=parentPathOfScreen(n);return{mod:p.module,sec:p.section};
}
function pvTree(){
 const sortY=a=>a.slice().sort((p,q)=>p.y-q.y||p.x-q.x);
 return sortY(D.nodes.filter(n=>n.type==='module')).map(m=>{
  const secs=containsKidsOf(m.id,'section').map(s=>({node:s,items:containsKidsOf(s.id,'screen')}));
  const direct=containsKidsOf(m.id,'screen');
  return{node:m,secs,direct};
 });
}
function pvWrap(inner,n){
 if(!PV_FRAME)return inner;
 const L=layoutId(),ctx=pvCtxOf(n),tree=pvTree();
 const modId=ctx.mod&&ctx.mod.id,secId=ctx.sec&&ctx.sec.id,curId=n.id;
 const appName=($('sysName')&&$('sysName').value.trim())||'SAMPLE MES';
 const I=x=>esc(x.meta&&x.meta.icon||'▣');
 const link=(x,pad)=>`<a href="#" data-id="${x.id}" class="${x.id===curId?'active':''}"><span>${esc(x.name)}</span><span class="star">★</span></a>`;
 /* 상단 메가메뉴 */
 const topMenu=tree.map(t=>`<li class="${t.node.id===modId?'on':''}"><button data-id="${t.node.id}">${esc(t.node.name)}</button>${(t.secs.length||t.direct.length)?`<div class="mega">${t.secs.map(s=>`<div class="col"><button class="sec-head" data-id="${s.node.id}"><span>${I(s.node)} ${esc(s.node.name)}</span><small>중분류 열기 ›</small></button>${s.items.map(link).join('')}</div>`).join('')}${t.direct.length?`<div class="col"><button class="sec-head" data-id="${t.node.id}"><span>${I(t.node)} ${esc(t.node.name)}</span><small>대분류 홈 ›</small></button>${t.direct.map(link).join('')}</div>`:''}</div>`:''}</li>`).join('')
  +'<li><button>사용메뉴얼</button></li>';
 /* 사이드 트리 */
 const secBlock=(s)=>{const on=s.node.id===secId||s.items.some(x=>x.id===curId);
  return `<div class="lay-sec${on?' on open':''}"><button class="lay-sec-h" data-tog="1"><span class="car">▶</span><span class="ic">${I(s.node)}</span><span class="tx">${esc(s.node.name)}</span><span class="go" data-id="${s.node.id}" title="중분류 홈">›</span></button><div class="lay-items">${s.items.map(link).join('')}</div></div>`};
 const secsOf=t=>t.secs.map(secBlock).join('')+(t.direct.length?`<div class="lay-items flat">${t.direct.map(link).join('')}</div>`:'');
 const modBlock=t=>{const on=t.node.id===modId;
  return `<div class="lay-mod${on?' on open':''}"><button class="lay-mod-h" data-tog="1"><span class="car">▶</span><span class="ic">${I(t.node)}</span><span class="tx">${esc(t.node.name)}</span><span class="go" data-id="${t.node.id}" title="대분류 홈">⌂</span></button><div class="lay-mod-b">${secsOf(t)}</div></div>`};
 const help='<div class="lay-mod"><button class="lay-mod-h"><span class="car"></span><span class="ic">📖</span><span class="tx">사용메뉴얼</span></button></div>';
 const title=t=>`<button class="lay-title" data-id="${t.node.id}"><span>${I(t.node)}</span><span>${esc(t.node.name)}</span><small>대분류 홈 ›</small></button>`;
 let aside='',fly='';
 if(L==='side')aside=`<aside class="lay-aside"><div class="lay-scroll">${tree.map(modBlock).join('')}${help}</div><div class="lay-foot"><button>« 메뉴 접기</button></div></aside>`;
 else if(L==='topside'){const t=tree.find(x=>x.node.id===modId);
  aside=`<aside class="lay-aside"><div class="lay-scroll">${t?title(t)+t.secs.map(s=>secBlock(s).replace('class="lay-sec','class="lay-sec open').replace(' open open',' open')).join('')+(t.direct.length?`<div class="lay-items flat">${t.direct.map(link).join('')}</div>`:''):'<div class="lay-hint">상단에서 대분류를 고르면 여기에 중분류·화면이 나옵니다.</div>'+tree.map(modBlock).join('')}</div></aside>`}
 else if(L==='rail'){
  aside=`<aside class="lay-aside"><div class="lay-scroll">${tree.map(t=>`<button class="lay-rb${t.node.id===modId?' on':''}" data-fly="${t.node.id}" title="${esc(t.node.name)}"><span class="ic">${I(t.node)}</span><span class="tx">${esc(t.node.name)}</span></button>`).join('')}<button class="lay-rb"><span class="ic">📖</span><span class="tx">사용메뉴얼</span></button></div></aside>`;
  fly=tree.map(t=>`<div class="lay-fly" data-mod="${t.node.id}">${title(t)}${t.secs.map(s=>secBlock(s).replace('class="lay-sec','class="lay-sec open').replace(' open open',' open')).join('')}${t.direct.length?`<div class="lay-items flat">${t.direct.map(link).join('')}</div>`:''}</div>`).join('');
 }
 const tabTitle=n.name;
 const crumb=`<span>${esc(appName)}</span>${ctx.mod&&n.type!=='module'?`<span>›</span><span>${esc(ctx.mod.name)}</span>`:''}${ctx.sec&&n.type==='screen'?`<span>›</span><span>${esc(ctx.sec.name)}</span>`:''}<span>›</span><b>${esc(n.name)}</b><span class="right"><span>${n.type==='module'?'대분류 홈':n.type==='section'?'중분류':esc(n.meta.file||'')}</span></span>`;
 const innerDoc=inner.replace(/<\/head>/i,'<style>.pv-crumb{display:none!important}</style></head>');
 const skin=SKIN[skinId()]||{};
 const script=`<script>(function(){
 window.previewNode=function(id){parent.previewNode(id)};
 window.addEventListener('message',function(e){if(e.source!==parent)try{parent.postMessage(e.data,'*')}catch(_){}});
 var B=document.body,t=0;
 document.addEventListener('click',function(e){
  var hb=e.target.closest('.lay-hb');if(hb){B.classList.toggle('lay-open');return}
  if(e.target.closest('.lay-dim')){B.classList.remove('lay-open');return}
  var g=e.target.closest('[data-id]');if(g){e.preventDefault();e.stopPropagation();parent.previewNode(g.getAttribute('data-id'));return}
  var tg=e.target.closest('[data-tog]');if(tg){tg.parentNode.classList.toggle('open');return}
  var f=e.target.closest('[data-fly]');if(f)show(f);
 },true);
 function hideAll(){document.querySelectorAll('.lay-fly.on').forEach(function(x){x.classList.remove('on')})}
 function show(b){clearTimeout(t);hideAll();var p=document.querySelector('.lay-fly[data-mod="'+b.getAttribute('data-fly')+'"]');if(!p)return;
  var r=b.getBoundingClientRect(),a=document.querySelector('.lay-aside').getBoundingClientRect();p.style.left=a.right+'px';p.classList.add('on');
  p.style.top=Math.max(a.top,Math.min(r.top,innerHeight-p.offsetHeight-8))+'px'}
 document.querySelectorAll('[data-fly]').forEach(function(b){b.onmouseenter=function(){show(b)};b.onmouseleave=function(){t=setTimeout(hideAll,260)}});
 document.querySelectorAll('.lay-fly').forEach(function(p){p.onmouseenter=function(){clearTimeout(t)};p.onmouseleave=function(){t=setTimeout(hideAll,260)}});
})();<\/script>`;
 return `<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>${shellCssOnly()}</style>${skin.shell?`<style>${skin.shell}</style>`:''}<style>${LAYOUT_CSS}
.stage iframe{visibility:visible;pointer-events:auto}.top-menu>li>button{cursor:pointer}</style></head>
<body class="${L==='top'?'':'lay-'+L}"><div class="app" id="app">
 <header class="top">${L==='top'?'':'<button class="lay-hb" title="메뉴">☰</button>'}
  <div class="brand"><div class="mark">${esc((appName[0]||'M').toUpperCase())}</div><div class="name"><span class="home-lbl">⌂ 홈</span><small>${esc(appName)}</small></div></div>
  <ul class="top-menu">${topMenu}</ul>
  <div class="search"><span class="ico">⌕</span><input placeholder="메뉴 검색" autocomplete="off"><kbd>Ctrl K</kbd></div>
  <div class="top-actions"><div class="dd"><button class="icon-btn" title="즐겨찾기">★</button></div><div class="dd"><button class="ubtn"><span class="avatar">미</span><span class="txt"><b>미리보기</b><span>master</span></span></button></div></div>
 </header>
 ${aside}
 <section class="main">
  <div class="tabs"><div class="tabs-scroll"><div class="tab"><span>📌 홈</span></div><div class="tab active"><span>${esc(tabTitle)}</span><span class="x">×</span></div></div><div class="tabs-act"><button>‹</button><button>›</button><button>×</button></div></div>
  <div class="crumb">${crumb}</div>
  <div class="stage"><iframe class="on" id="pvInner" srcdoc="${innerDoc.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe></div>
  <div class="status"><span><span class="dot"></span>미리보기 — ${esc(LAYOUT[L].name)} · ${esc(skin.name||'')}</span><span class="r"></span></div>
 </section>
</div>${fly}<div class="lay-dim"></div>${script}</body></html>`;
}
