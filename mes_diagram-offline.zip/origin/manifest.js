/* sync_origin.py 가 만든 파일 — 직접 고치지 마세요 */
window.ORIGIN_MANIFEST={
 "generated_at": "2026-09-20T15:07:37+09:00",
 "repos": {
  "mm_main": {
   "upstream": "https://github.com/KnagByeongju-123/mm_main",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/mm_main/main/",
   "branch": "main",
   "commit": "0d451b11c497b38be9b1da0b86c63e5441670dd4",
   "commit_date": "2026-08-26T19:18:49+09:00",
   "synced_at": "2026-09-20T11:17:25+09:00",
   "files": 34,
   "bytes": 1688789
  },
  "smtec_main2": {
   "upstream": "https://github.com/KnagByeongju-123/smtec_main2",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/smtec_main2/main/",
   "branch": "main",
   "commit": "5b5cd8f29896279ed6ba5dd8cb59cd74d98946b1",
   "commit_date": "2026-09-17T10:14:29+09:00",
   "synced_at": "2026-09-20T11:17:26+09:00",
   "files": 108,
   "bytes": 8539676
  },
  "Gyeongil": {
   "upstream": "https://github.com/KnagByeongju-123/Gyeongil",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/Gyeongil/main/",
   "branch": "main",
   "commit": "a5bd18357228acd6e90eb4500d3d3884d022ad8a",
   "commit_date": "2026-09-03T10:41:19+09:00",
   "synced_at": "2026-09-20T11:17:27+09:00",
   "files": 98,
   "bytes": 1277197
  },
  "ESG_Smart_Factory_Mold": {
   "upstream": "https://github.com/KnagByeongju-123/ESG_Smart_Factory_Mold",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/ESG_Smart_Factory_Mold/main/",
   "branch": "main",
   "commit": "2c2f7cab33781986fe6c6def91a702a4af9b1ef1",
   "commit_date": "2026-09-19T14:24:42+09:00",
   "synced_at": "2026-09-20T11:17:28+09:00",
   "files": 141,
   "bytes": 2727371
  },
  "iptk_1": {
   "upstream": "https://github.com/KnagByeongju-123/iptk_1",
   "raw": "https://raw.githubusercontent.com/KnagByeongju-123/iptk_1/main/",
   "branch": "main",
   "commit": "2c6075877fd6fe39364f565385084e5adb0fc42b",
   "commit_date": "2026-09-19T15:03:52+09:00",
   "synced_at": "2026-09-20T15:07:37+09:00",
   "files": 140,
   "bytes": 2737794
  }
 }
};
