"""원본 저장소 4개를 origin/ 폴더에 포크(사본)로 저장·갱신한다.

사용:  python sync_origin.py            # 전체 갱신
       python sync_origin.py mm_main    # 일부만 갱신
"""
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

OWNER = "KnagByeongju-123"
REPOS = ["mm_main", "smtec_main2", "Gyeongil", "ESG_Smart_Factory_Mold", "iptk_1"]
BRANCH = "main"
SKIP = {".git", ".github"}

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "origin"
MANIFEST_JS = DEST / "manifest.js"
KST = timezone(timedelta(hours=9))


def run(*args, cwd=None):
    return subprocess.run(args, cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()


def load_manifest():
    if not MANIFEST_JS.exists():
        return {}
    txt = MANIFEST_JS.read_text(encoding="utf-8")
    try:
        return json.loads(txt[txt.index("{"): txt.rindex("}") + 1]).get("repos", {})
    except Exception:
        return {}


def copy_tree(src: Path, dst: Path):
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, ignore=lambda d, names: [n for n in names if n in SKIP])


def sync(repo, tmp: Path):
    url = f"https://github.com/{OWNER}/{repo}.git"
    work = tmp / repo
    run("git", "clone", "--depth", "1", "-b", BRANCH, url, str(work))
    commit = run("git", "rev-parse", "HEAD", cwd=work)
    cdate = run("git", "log", "-1", "--format=%cI", cwd=work)
    copy_tree(work, DEST / repo)
    files = [p for p in (DEST / repo).rglob("*") if p.is_file()]
    return {
        "upstream": f"https://github.com/{OWNER}/{repo}",
        "raw": f"https://raw.githubusercontent.com/{OWNER}/{repo}/{BRANCH}/",
        "branch": BRANCH,
        "commit": commit,
        "commit_date": cdate,
        "synced_at": datetime.now(KST).isoformat(timespec="seconds"),
        "files": len(files),
        "bytes": sum(p.stat().st_size for p in files),
    }


def main():
    targets = [r for r in sys.argv[1:] if r in REPOS] or REPOS
    DEST.mkdir(exist_ok=True)
    repos = load_manifest()
    with tempfile.TemporaryDirectory() as t:
        for r in targets:
            try:
                repos[r] = sync(r, Path(t))
                m = repos[r]
                print(f"✔ {r:<24} {m['commit'][:7]}  {m['files']:>4} files  {m['bytes'] / 1e6:6.1f} MB")
            except subprocess.CalledProcessError as e:
                print(f"✘ {r}: {e.stderr.strip()[:200]}")
    data = {"generated_at": datetime.now(KST).isoformat(timespec="seconds"), "repos": repos}
    MANIFEST_JS.write_text(
        "/* sync_origin.py 가 만든 파일 — 직접 고치지 마세요 */\n"
        "window.ORIGIN_MANIFEST=" + json.dumps(data, ensure_ascii=False, indent=1) + ";\n",
        encoding="utf-8",
    )
    print(f"→ {MANIFEST_JS.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
